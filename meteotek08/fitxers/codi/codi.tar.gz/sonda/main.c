/*  Meteotek08 - Sonda meteorològica dels tecnòlegs de l'IES Bisbal [ http://teslabs.com/meteotek08 ]
    Copyright (C) 2009  Tecnòlegs de l'IES Bisbal - <meteotek08[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/sleep.h>
#include <avr/wdt.h>
#include <avr/eeprom.h>
#include <stdio.h>
#include <string.h>
#include "mtkos.h"
#include "mtk.h"
#include <util/delay.h>

int main(void)
{

	/* Critical initializations */
	cutdown_disable();

	/* Load defaults */
	mtk_load_defaults();

	/* Initialize system basic units: SPI bus and radio */
	spi_init();

	radio_init();

	/* Initialize operating system */
	mtkos_init(task_idle, MTKOS_MIN_STACK_SIZE);

	mtk.mutex.spi = mtkos_mutex_create();
	mtk.mutex.radio = mtkos_mutex_create();
	mtk.mutex.data = mtkos_mutex_create();

	/* Make sure stack sizes are big enough or system crashes will occur */
	/* Note: We have 8Kb of SRAM under Atmega1281 (~1.5Kb are used by static vars) */
	mtkos_task_create(TASK_INIT, task_meteotek_init, 350, 100);
	mtkos_task_create(TASK_NOTIFIER, task_notifier, 850, 100);
	mtkos_task_create(TASK_DAT_MANAGER, task_data_manager, 1000, 100);
	mtkos_task_create(TASK_PET_MANAGER, task_petition_manager, 1000, 100);
	mtkos_task_create(TASK_CAM_MANAGER, task_camera_manager, 650, 100);


	mtkos_run();

}

void task_meteotek_init()
{

	radio_printf(" \n\n -- Meteotek --\n\n");
	radio_printf(" Inicialitzant tasques...\n");

	/* Wait for initializations */
	while((mtk.status & STAT_INIT_DONE_ALL) != STAT_INIT_DONE_ALL) mtkos_sleep(time_ms(100));

	/* Show status var and give time to enter to config console */
	radio_printf(" Inicialitzacio finalitzada. Indicador d'estat: %04X\n", mtk.status);
	radio_printf(" Envia la comanda de bloqueig per parar l'execucio\n");

	mtkos_sleep(time_s(CONF_INIT_WAIT));

	/* Check for system lock */
	if(mtkos_event_check(EVENT_SYS_INIT_LOCK, TASK_ME)){
		radio_printf(" -- Bloqueig actiu --\n");
		mtkos_event_wait(EVENT_SYS_INIT_UNLOCK);
	}

	/* Setup system and set system init event to start */
	mtkos_event_set(EVENT_SYS_INIT, NULL);

	/* END */
	mtkos_task_stop(TASK_ME, TRUE);
}


void task_camera_manager()
{

	mtk_data data;
	uint8_t pos_shots = 0, servo_chg_shots = 0;

	/* Initialize servo and camera */
	if(cam.power == FALSE){
		/* Avoid task reset to turn off the camera */
		cam_init();
		cam_power();
	}

	cam_servo_init();

	/* Task init done, wait for system init event */
	mtk_stat_set(STAT_INIT_DONE_CAM);
	mtkos_event_wait(EVENT_SYS_INIT);

	/* Handle camera shots and servo position */
	while(!mtkos_event_check(EVENT_TASK_EXIT, TASK_ME)){

		if(mtk.conf.cam.servo_act == TRUE){

			if(pos_shots >= servo_chg_shots){

				mtk_get_data(&data);

				/* Check if we should stop servo */
				if(data.gps.alt >= CONF_SERVO_STOP_ALT){

					cam_servo_set_pos(SERVO_POS_MID);
					mtk.conf.cam.servo_act = FALSE;

				/* If not just change to next position */
				}else{

					switch(cam.servo_pos){

					case SERVO_POS_MID:
						cam_servo_set_pos(SERVO_POS_UP);
						servo_chg_shots = mtk.conf.cam.servo_chg_up;
						break;

					case SERVO_POS_UP:
						cam_servo_set_pos(SERVO_POS_DOWN);
						servo_chg_shots = mtk.conf.cam.servo_chg_down;
						break;

					case SERVO_POS_DOWN:
					default:
						cam_servo_set_pos(SERVO_POS_MID);
						servo_chg_shots = mtk.conf.cam.servo_chg_mid;
						break;
					}

				}

				pos_shots = 0;
				mtkos_sleep(time_s(1));
			}
		}

		/* Shot and wait */
		cam_shot();
		pos_shots++;
		mtkos_sleep(time_s(mtk.conf.cam.shot_interval));

	}

	if(cam.power) cam_power();

	/* END */
	mtkos_task_stop(TASK_ME, TRUE);
}



/* Description: Kepps control of all flight data (even logs) */
void task_data_manager()
{

	uint8_t buffer[GPS_BUFFER_SIZE];
	uint8_t buffer_index = 0, ret;
	bool_t gga = FALSE;
	mtk_data data;

	if(press_init() != S_OK){
		mtk_stat_set(STAT_REPORT_PRESS);
		mtk.conf.sen.press_act = FALSE;
	}

	temp_get(TEMP_EXT);
	temp_get(TEMP_INT);

	gps_init();

	/* Task init done, wait for system init event */
	mtk_stat_set(STAT_INIT_DONE_DATA);
	mtkos_event_wait(EVENT_SYS_INIT);

	gps_enable_reception();
	while(!mtkos_event_check(EVENT_TASK_EXIT, TASK_ME)){

		if(gps_get_byte(&buffer[buffer_index]) == TRUE)
		{
			if(buffer[buffer_index] == LF){

				/* End and parse */
				buffer[buffer_index + 1] = '\0';

				/* If bridge mode is configured, just send raw data */
				if(mtk.conf.flight.bridged_gps == TRUE){

					radio_printf(" %s", &buffer[0]);

				/* If not, parse data */
				}else{

					ret = gps_nmea_parse((char*)&buffer[0], &data);

					if(ret == GPS_PROC_GGA){
						gga = TRUE;
					}else if((ret == GPS_PROC_VTG) && (gga == TRUE)){

						gga = FALSE;

						/* Update sensors after VTG package and update */

						data.sen.press = (mtk.conf.sen.press_act == TRUE) ? press_get() : 0;

						if(mtk.conf.sen.t_ext_act == TRUE){
							data.sen.t_ext = temp_get(TEMP_EXT);
						}else{
							data.sen.t_ext.dec = 0;
							data.sen.t_ext.frac = 0;
						}

						if(mtk.conf.sen.t_int_act == TRUE){
							data.sen.t_int = temp_get(TEMP_INT);
						}else{
							data.sen.t_int.dec = 0;
							data.sen.t_int.frac = 0;
						}

						mtk_update_data(&data);

					}
				}

				/* Reset buffer */
				buffer_index = 0;

			}else if(++buffer_index == GPS_BUFFER_SIZE){
				/* Avoid overflows... */
				buffer_index = 0;
			}

		}

	}

	/* END */
	mtkos_task_stop(TASK_ME, TRUE);

}

/* Description: Sends flight information */
void task_notifier()
{

	mtk_data data;

	/* Task init done, wait for system init event */
	mtk_stat_set(STAT_INIT_DONE_NOTIF);
	mtkos_event_wait(EVENT_SYS_INIT);

	while(!mtkos_event_check(EVENT_TASK_EXIT, TASK_ME)){

		mtk_get_data(&data);

		switch(mtk.conf.flight.mode){
		case MODE_LANDED:
			radio_printf("$MTKP,%s,%s,%d,%c*", data.gps.lat, data.gps.lon, data.gps.alt, (data.gps.valid == TRUE) ? 'V' : 'I');
			break;
		case MODE_FLIGHT:
		default:
			radio_printf("$MTKG,%s,%s,%ld,%s,%02u%02u%02u,%u,%c,%lu,%+d.%04d,%+d.%04d,%d*", data.gps.lat, data.gps.lon, data.gps.alt, data.gps.speed, data.gps.utc.h, data.gps.utc.m, data.gps.utc.s, data.gps.sats, (data.gps.valid == TRUE) ? 'V' : 'I', data.sen.press, data.sen.t_ext.dec, data.sen.t_ext.frac, data.sen.t_int.dec, data.sen.t_int.frac, cam.shots);
			break;
		}

		mtkos_sleep(time_s(mtk.conf.flight.notif_interval));
	}

	/* END */
	mtkos_task_stop(TASK_ME, TRUE);
}

void task_petition_manager()
{
	uint8_t buffer[RADIO_BUFFER_SIZE];
	uint8_t buffer_index = 0;

	/* Task init done, wait for system init event */
	mtk_stat_set(STAT_INIT_DONE_PET);

	while(!mtkos_event_check(EVENT_TASK_EXIT, TASK_ME)){

		if(radio_get_byte(&buffer[buffer_index]) == TRUE){

			if(buffer[buffer_index] == LF){

				/* End and parse */
				buffer[buffer_index + 1] = '\0';

				if(radio_proc_pkt((char*)&buffer[0]) == RADIO_PROC_ERR){
					radio_printf("$MTKN*");
				}else{
					radio_printf("$MTKR*");
				}

				/* Reset buffer */
				buffer_index = 0;

			}else if(++buffer_index == RADIO_BUFFER_SIZE){
				/* Avoid overflows... */
				buffer_index = 0;
			}

		}
	}

	/* END */
	mtkos_task_stop(TASK_ME, TRUE);
}

/* Description: The MTKOS idle task (will run when there are no more tasks ready to run) */
void task_idle()
{
	while(1) asm volatile ("nop");
}
