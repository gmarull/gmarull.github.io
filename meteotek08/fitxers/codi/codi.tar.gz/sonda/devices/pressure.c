/*  Meteotek08 - Sonda meteorològica dels tecnòlegs de l'IES Bisbal [ http://teslabs.com/meteotek08 ]
    Copyright (C) 2009  Tecnòlegs de l'IES Bisbal - <meteotek08[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/* NOTES: A cada operació d'escriptura/lectura s'envia un byte al principi i
 * al final (valor 0). Sense això i amb la SD connectada, sembla no funcionar. ¿? */

#include <avr/io.h>
#include "mtk.h"
#include "mtkos.h"
#include <util/delay.h>


uint8_t press_init()
{

	uint16_t data;
	uint8_t i;

	/* Pin CSB com a sortida i amb nivell alt */
	PRESS_PORT |= (1<<PRESS_CSB);
	PRESS_DDR |= (1<<PRESS_CSB);

	/* Pin DRDY com a entrada i amb el pull-up habilitat */
	PRESS_DDR &= ~(1<<PRESS_DRDY);
	PRESS_PORT |= (1<<PRESS_DRDY);

	_delay_ms(1);

	for(i=0; i<6; i++){

		data = press_read_direct_access(0x07, 1);

		if(!(data & 0x0001)) break;

		_delay_ms(10);

	}
	if(i==6) return S_ERR;

	press_write_indirect_access(0x2d, 0x03);
	_delay_ms(100);
	press_write_direct_access(0x03, 0x00);
	_delay_ms(10);
	press_write_direct_access(0x03, 0x0a);

	_delay_ms(10);

	return S_OK;

}

void press_write_direct_access(uint8_t address, uint8_t data)
{

	address = (address << 2);
	address |= 0x02;

	spi_speed_low();
	press_select();

	SPDR = address;

	while(!(SPSR & (1<<SPIF))) asm volatile ("nop");

	SPDR = data;

	while(!(SPSR & (1<<SPIF))) asm volatile ("nop");

	press_deselect();
	spi_speed_high();


}

uint16_t press_read_direct_access(uint8_t address, uint8_t num_of_bytes)
{

	uint16_t value = 0;

	address = (address << 2);

	spi_speed_low();
	press_select();

	SPDR = address;

	while(!(SPSR & (1<<SPIF))) asm volatile ("nop");

	while(num_of_bytes-- > 0){

		value <<= 8;

		SPDR = 0;

		while(!(SPSR & (1<<SPIF))) asm volatile ("nop");

		value |= SPDR;

	}

	press_deselect();
	spi_speed_high();

	return value;

}

uint16_t press_read_indirect_access(uint8_t address)
{

	uint16_t value;

	press_write_direct_access(0x02, address);
	press_write_direct_access(0x03, 0x01);
	_delay_ms(10);
	value = press_read_direct_access(0x20, 0x02);

	return value;

}


void press_write_indirect_access(uint8_t address, uint8_t data)
{

	press_write_direct_access(0x02, address);
	press_write_direct_access(0x01, data);
	press_write_direct_access(0x03, 0x02);

	_delay_ms(50);

}

uint32_t press_get()
{

	uint32_t pressure;
	uint16_t max_delay = 0;

	press_read_direct_access(0,1);

	while(!(PRESS_PIN & (1<<PRESS_DRDY))){
		_delay_ms(1);
		if(max_delay++ == 1000) return 0;
	}

	pressure = (uint32_t)((0x0007) & press_read_direct_access(0x1f, 1));
	pressure = (pressure << 16);
	pressure |= (uint32_t)(press_read_direct_access(0x20, 2));
	pressure >>= 2;


	return pressure;

}

