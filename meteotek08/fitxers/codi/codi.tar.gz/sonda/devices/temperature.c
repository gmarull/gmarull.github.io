/*  Meteotek08 - Sonda meteorològica dels tecnòlegs de l'IES Bisbal [ http://teslabs.com/meteotek08 ]
    Copyright (C) 2009  Tecnòlegs de l'IES Bisbal - <meteotek08[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    Algunes parts pertanyen al codi de l'openplayer
*/


#include <avr/io.h>
#include <stdlib.h>
#include "mtkos.h"
#include "mtk.h"
#include <util/delay.h>

/* Selector (ext/int) */
uint8_t temp_selector;

/* Envia una seqüència de reset al termòmetre */
uint8_t temp_reset()
{

	uint8_t i;

	//Posar el bus a nivell baix i esperar 480uS
	TEMP_LOW();
	TEMP_OUTPUT_MODE();
	_delay_us(480);

	//Alliberar el bus i esperar 60uS
	TEMP_INPUT_MODE();
	_delay_us(60);

	//Llegir i desar l'estat del bus i esperar 420uS
	i=(TEMP_PIN & (1<<temp_selector));

	_delay_us(420);

	return i;

}


/* Envia 1 bit a través del bus del termòmetre */
void temp_write_bit(uint8_t bit)
{

	//Posar el bus a nivell baix durant 1uS
	TEMP_LOW();
	TEMP_OUTPUT_MODE();
	_delay_us(1);

	//Si es vol transmetre 1, alliberar el bus (sinó es mantindrà a nivell baix)
	if(bit) TEMP_INPUT_MODE();

	//Esperar 60uS i alliberar el bus
	_delay_us(60);
	TEMP_INPUT_MODE();

}

/* Llegeix 1 bit del bus del termòmetre */
uint8_t temp_read_bit()
{

	uint8_t bit=0;

	//Posar el bus a nivell baix durant 1uS
	TEMP_LOW();
	TEMP_OUTPUT_MODE();
	_delay_us(1);

	//Alliberar el bus i esperar 14uS
	TEMP_INPUT_MODE();
	_delay_us(14);

	//Llegir el nivell del bus
	if(TEMP_PIN&(1<<temp_selector)) bit=1;

	//Esperar 45uS per acabar i retornar el valor llegit
	_delay_us(45);
	return bit;

}

/* Llegeix un byte del bus del termòmetre */
uint8_t temp_read_byte()
{

	uint8_t i=8, n=0;

	while(i--){
		//Moure una posició a la dreta i desa el valor llegit
		n>>=1;
		n|=(temp_read_bit()<<7);
	}

	return n;

}

/* Envia un byte a través del bus del termòmetre */
void temp_write_byte(uint8_t byte)
{

	uint8_t i=8;

	while(i--){
		//Escriu el bit actual i mou una posició a la dreta per preparar el següent
		temp_write_bit(byte&1);
		byte>>=1;
	}

}


/* Llegeix la temperatura actual d'un dels termòmetres */
temperature_t temp_get(uint8_t selector)
{

	temperature_t temp = {0, 0};
	int8_t lsb, msb;
	uint8_t max_delay = 0;

	temp_selector = selector;

	//Enviar la petició d'iniciar la conversió de temperatura
	temp_reset();
	temp_write_byte(TEMP_CMD_SKIPROM);
	temp_write_byte(TEMP_CMD_CONVERTTEMP);

	//Esperar fins que la conversió hagi acabat
	while(!temp_read_bit()){
		_delay_ms(1);
		if(max_delay++ == 1000) return temp;
	}

	//Llegeix el registre on es troben els valors de la temperatura (2 primers bytes)
	temp_reset();
	temp_write_byte(TEMP_CMD_SKIPROM);
	temp_write_byte(TEMP_CMD_RSCRATCHPAD);

	lsb = temp_read_byte();
	msb = temp_read_byte();
	temp_reset();

	msb <<= 4;
	msb |= 0xf & (lsb >> 4);
	if(msb & (0x80)) msb = ((~(msb)) + 1)*(-1);
	temp.dec = abs(msb);
	temp.frac = (625*(lsb&0xf));
	if(msb & (0x80)) temp.dec = -temp.dec;

	return temp;

}
