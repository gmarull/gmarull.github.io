/*  Meteotek08 - Sonda meteorològica dels tecnòlegs de l'IES Bisbal [ http://teslabs.com/meteotek08 ]
    Copyright (C) 2009  Tecnòlegs de l'IES Bisbal - <meteotek08[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <avr/io.h>
#include "mtk.h"
#include "mtkos.h"
#include <util/delay.h>


void cam_init()
{

	CAM_PORT &= ~((1<<CAM_PWR) | (1<<CAM_SHOT));
	CAM_DDR	|= ((1<<CAM_PWR) | (1<<CAM_SHOT));

	/* We need a startup delay before being able to power-on */
	_delay_ms(3000);

	cam.shots = 0;
}

void cam_power()
{

	CAM_PORT |= (1<<CAM_PWR);
	_delay_ms(1500);
	CAM_PORT &= ~(1<<CAM_PWR);

	cam.power = ~(cam.power);

}

void cam_shot()
{

	CAM_PORT |= (1<<CAM_SHOT);
	_delay_ms(1500);
	CAM_PORT &= ~(1<<CAM_SHOT);

	cam.shots++;
}

void cam_servo_init()
{
	/* Configurar el port del servo com a sortida */
	SERVO_DDR |= (1<<SERVO_CTL);

	/* Configuració del Timer1 amb Fast PWM - Freq. = 50Hz */
	ICR1 = 20000;
	TCCR1A = (1<<COM1A1)|(1<<WGM11);
	TCCR1B = (1<<WGM13)|(1<<WGM12)|(1<<CS11);

}

void cam_servo_set_pos(uint8_t pos)
{

	if(pos > 180) return;

	OCR1A = (uint16_t)(600+(pos*10));

	cam.servo_pos = pos;

}
