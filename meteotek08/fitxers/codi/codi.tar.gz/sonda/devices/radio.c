/*  Meteotek08 - Sonda meteorològica dels tecnòlegs de l'IES Bisbal [ http://teslabs.com/meteotek08 ]
    Copyright (C) 2009  Tecnòlegs de l'IES Bisbal - <meteotek08[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/wdt.h>
#include <avr/eeprom.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include "mtk.h"
#include "mtkos.h"
#include <util/delay.h>

/* Radio out buffer */
static 			char radio_out_buffer[RADIO_BUFFER_SIZE];

/* Radio in circular buffer */
static          uint8_t radio_buffer[RADIO_BUFFER_SIZE];
static          uint8_t radio_out;
static volatile uint8_t radio_in;


/* Configure stdio output directly to radio */
static int radio_send(char byte, FILE *stream);
static FILE radio_stdout = FDEV_SETUP_STREAM(radio_send, NULL, _FDEV_SETUP_WRITE);

static int radio_send(char c, FILE *stream)
{

	while(!(UCSR0A & (1<<UDRE0)));

	UDR0 = c;

	return S_OK;

}

ISR(USART0_RX_vect)
{
    uint8_t data  = UDR0;
    uint8_t index = radio_in;

    /* Get next pointer position */
    RADIO_NEXT_INDEX(index, RADIO_BUFFER_SIZE);

    /* Check space... */
    if(index == radio_out) return;

    /* Add data and update index */
    radio_buffer[radio_in] = data;
    radio_in = index;
}

/* Check if Radio buffer is empty */
bool_t radio_buffer_is_empty(void)
{
    return ((radio_out == radio_in) ? TRUE : FALSE);
}

/* Get one byte from the buffer */
bool_t radio_get_byte(uint8_t* data)
{
    /* Check empty */
    if(radio_out == radio_in) return FALSE;

    /* Get data */
    *data = radio_buffer[radio_out];

    /* Advance */
    RADIO_NEXT_INDEX(radio_out, RADIO_BUFFER_SIZE);

    return TRUE;
}

/* Description: printf with direct output to radio, thread safe function
 * Flags:		format 	- format string
 * 				...		- list of arguments
 */
int radio_printf(const char *format, ...)
{
	va_list arg_ptr;
	int retval;
	char *buffer = &radio_out_buffer[0];

	mtkos_lock(mtk.mutex.radio);
	va_start(arg_ptr, format);

	retval = vsprintf(buffer, format, arg_ptr);

	/* Only add checksum if first character is not a space */
	if(*buffer != ' '){
		retval += sprintf(buffer + retval, "%02X\r\n", radio_calc_checksum(buffer));
	}

	/* Send message */
	while(*buffer){
		radio_send(*buffer++, NULL);
	}

	va_end(arg_ptr);
	mtkos_unlock(mtk.mutex.radio);

	return retval;
}


uint8_t radio_calc_checksum(char *message)
{
	uint8_t result=0;

	message++;

	while((*message != '*') && (*message)){
		result ^= *message++;
	}

	return result;
}

/* Description: Initializes radio USART bus and sets up output stdio */
void radio_init()
{

	UBRR0H = (uint8_t)(RADIO_UBRR>>8);
	UBRR0L = (uint8_t)RADIO_UBRR;

	//USART RX/TX 8N1 NOPAR & RX Int.
	UCSR0B = (1 << RXEN0) | (1 << TXEN0) | (1 << RXCIE0);
	UCSR0C = (1 << UCSZ01) | (1 << UCSZ00);

	stdout = &radio_stdout;

	radio_in = 0;
	radio_out = 0;

}

uint8_t radio_proc_pkt(char *buffer)
{
	char *token, *p = NULL;
	char pkt_id;
	/* Parsing needed vars */
	uint8_t id;
	mtk_data data;

	/* Replace * with , to 'help' strtok_re */
	token = strchr(buffer, '*');
	if(!token) return RADIO_PROC_ERR;
	*token = ',';

	/* Startup... */
	token = buffer + 1;

	/* Check header and then process message */
	if(strncmp(token, "MTK", 3) == 0){

		/* Save packet id and setup token at first field */
		pkt_id = *(token+3);
		token = strtok_re(token + 5, ',', &p);

		switch(pkt_id){

		/* Configuration packets */
		case PKT_CAM_CFG:
			radio_proc_pkt_cam_cfg(token, p);
			break;

		case PKT_SEN_CFG:
			radio_proc_pkt_sen_cfg(token, p);
			break;

		case PKT_FLI_CFG:
			radio_proc_pkt_fli_cfg(token, p);
			break;

		/* Data packets */
		case PKT_QUERY:

			mtk_get_data(&data);

			if(*token == 'P'){
				radio_printf("$MTKP,%s,%s,%ld,%c*", data.gps.lat, data.gps.lon, data.gps.alt, (data.gps.valid == TRUE) ? 'V' : 'I');
			}else if(*token == 'S'){
				radio_printf("$MTKS,%lu,%+d.%04d,%+d.%04d*", data.sen.press, data.sen.t_ext.dec, data.sen.t_ext.frac, data.sen.t_int.dec, data.sen.t_ext.frac);
			}

			break;

		/* Critical packets */
		case PKT_TASK_RST:
			/* Reset the requested task. Cannot reset: Idle, init and petition manager */
			id = atoi(token);
			if((id == TASK_IDLE) || (id == TASK_INIT) || (id == TASK_PET_MANAGER)){
				return RADIO_PROC_ERR;
			}else{
				/* Reset the task setting init event */
				mtkos_task_reset(mtkos_task_find(id), EVENT_SYS_INIT, FALSE);
			}

			break;

		case PKT_WDT:
			if(*token == '1'){
				wdt_enable(CONF_WDTO);
			}else{
				wdt_disable();
			}

			break;

		case PKT_SYS_RST:
			/* Enable watchdog (may not be enabled) and disable interrupts */
			wdt_enable(CONF_WDTO);
			cli();
			while(1);

			break;

		case PKT_CUTDOWN:
			/* Activate cutdown (will stop the entire system for ~10s) */
			radio_printf("$MTKC,S*");

			wdt_disable();
			mtkos_enter_critical();

				cutdown_release();
				_delay_ms(5000);
				cutdown_disable();
				_delay_ms(5000);

			mtkos_exit_critical();
			wdt_enable(CONF_WDTO);

			radio_printf("$MTKC,E*");

			break;


		/* Other packets */
		case PKT_INIT_LOCK:
			mtkos_event_set(EVENT_SYS_INIT_LOCK, mtkos_task_find(TASK_INIT));
			break;

		case PKT_INIT_UNLOCK:
			mtkos_event_set(EVENT_SYS_INIT_UNLOCK, mtkos_task_find(TASK_INIT));
			break;

		case PKT_CAM_PWR_TOG:
			cam_power();
			break;

		case PKT_CAM_SHT_TOG:
			cam_shot();
			break;

		default: return RADIO_PROC_ERR;

		}

	}else{
		return RADIO_PROC_ERR;
	}

	return RADIO_PROC_OK;
}

void radio_proc_pkt_cam_cfg(char *token, char *p)
{
	uint8_t field_count = 0;
	task_t *task;

	while((token = strtok_re(NULL, ',', &p)) != NULL){

		if(*token != '\0'){

			switch(field_count){
			case PKT_CAM_CFG_ACT:
				/* Stop / reset camera task only if needed */
				task = mtkos_task_find(TASK_CAM_MANAGER);
				if((*token == '1') && (mtkos_task_get_state(task) == MTKOS_TASK_STATE_STOPPED)){
					mtkos_task_reset(task, EVENT_SYS_INIT, FALSE);
				}else if(*token == '0'){
					/* Make stop with an event (so camera will be stopped by the task) */
					mtkos_event_set(EVENT_TASK_EXIT, task);
				}
				break;

			case PKT_CAM_CFG_INTERVAL:
				mtk.conf.cam.shot_interval = atoi(token);
				break;

			case PKT_CAM_CFG_SER_ACT:
				mtk.conf.cam.servo_act = (*token == '1') ? TRUE : FALSE;
				break;

			case PKT_CAM_CFG_SER_POS:
				cam_servo_set_pos(atoi(token));
				break;

			case PKT_CAM_CFG_SER_CHG_D:
				mtk.conf.cam.servo_chg_down = atoi(token);
				break;

			case PKT_CAM_CFG_SER_CHG_M:
				mtk.conf.cam.servo_chg_mid = atoi(token);
				break;

			case PKT_CAM_CFG_SER_CHG_U:
				mtk.conf.cam.servo_chg_up = atoi(token);
				break;

			}
		}

		field_count++;
		if(field_count == PKT_CAM_CFG_FIELDS) return;
	}
}

void radio_proc_pkt_sen_cfg(char *token, char *p)
{
	uint8_t field_count = 0;

	while((token = strtok_re(NULL, ',', &p)) != NULL){

		if(*token != '\0'){

			switch(field_count){
			case PKT_SEN_CFG_PRESS_ACT:
				mtk.conf.sen.press_act = (*token == '1') ? TRUE : FALSE;
				break;

			case PKT_SEN_CFG_TEXT_ACT:
				mtk.conf.sen.t_ext_act = (*token == '1') ? TRUE : FALSE;
				break;

			case PKT_SEN_CFG_TINT_ACT:
				mtk.conf.sen.t_int_act = (*token == '1') ? TRUE : FALSE;
				break;

			}
		}

		field_count++;
		if(field_count == PKT_SEN_CFG_FIELDS) return;
	}
}

void radio_proc_pkt_fli_cfg(char *token, char *p)
{
	uint8_t field_count = 0;

	while((token = strtok_re(NULL, ',', &p)) != NULL){

		if(*token != '\0'){
			switch(field_count){
			case PKT_FLI_CFG_MODE:
				mtk.conf.flight.mode = atoi(token);
				break;

			case PKT_FLI_CFG_NOTIF_INTERVAL:
				mtk.conf.flight.notif_interval = atoi(token);
				break;

			case PKT_FLI_CFG_GPS_BRIDGE:
				mtk.conf.flight.bridged_gps = (*token == '1') ? TRUE : FALSE;
				break;

			}
		}

		field_count++;
		if(field_count == PKT_FLI_CFG_FIELDS) return;
	}
}
