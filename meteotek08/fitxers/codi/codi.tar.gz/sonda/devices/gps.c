/*  Meteotek08 - Sonda meteorològica dels tecnòlegs de l'IES Bisbal [ http://teslabs.com/meteotek08 ]
    Copyright (C) 2009  Tecnòlegs de l'IES Bisbal - <meteotek08[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    Notes: 	We use Copernicus Trimble (Firm 2.0.1) with some customized settings:
			Output interval is 1s, output message is GPGGA only, and operates in AIR mode

	Other notes: Circular buffer code taken from Piconomic Library, which is BSD Licensed.
		* See piconomic.txt for copyright and license things *
*/

#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "mtk.h"
#include "mtkos.h"
#include <util/delay.h>

/* GPS Circular buffer */
static          uint8_t gps_buffer[GPS_BUFFER_SIZE];
static          uint8_t gps_out;
static volatile uint8_t gps_in;


/* Description: Initialize GPS USART bus / set output parameters */
void gps_init()
{
	/* USART: Rx/Tx, 8N1, ASYN, NOPAR */
	UBRR1H = (uint8_t)(GPS_INIT_UBRR >> 8);
	UBRR1L = (uint8_t)(GPS_INIT_UBRR);
	UCSR1B = (1 << RXEN1);
	UCSR1C = (1 << UCSZ11) | (1 << UCSZ10);

	/* Initialize circular buffer */
	gps_out = 0;
	gps_in = 0;

}

ISR(USART1_RX_vect)
{
    uint8_t data  = UDR1;
    uint8_t index = gps_in;

    /* Get next pointer position */
    GPS_NEXT_INDEX(index, GPS_BUFFER_SIZE);

    /* Check space... */
    if(index == gps_out) return;

    /* Add data and update index */
    gps_buffer[gps_in] = data;
    gps_in = index;
}

/* Check if GPS buffer is empty */
bool_t gps_buffer_is_empty(void)
{
    return ((gps_out == gps_in) ? TRUE : FALSE);
}

/* Get one byte from the buffer */
bool_t gps_get_byte(uint8_t* data)
{
    /* Check empty */
    if(gps_out == gps_in) return FALSE;

    /* Get data */
    *data = gps_buffer[gps_out];

    /* Advance */
    GPS_NEXT_INDEX(gps_out, GPS_BUFFER_SIZE);

    return TRUE;
}



/* Calculate NMEA sentence checksum */
uint8_t gps_nmea_calc_checksum(const char *buffer)
{
    uint8_t checksum = 0;

    /* Jump '$' */
    buffer++;

    while((*buffer) && (*buffer != '*')){
        checksum ^= *buffer++;
    }

    return checksum;
}

uint8_t gps_nmea_parse(char *buffer, mtk_data *data)
{

	uint8_t parsed, field_count = 1;
	char *token, *p = NULL;

	token = strchr(buffer, '*');
	if(!token) return GPS_PROC_ERR;

	if(gps_nmea_calc_checksum(buffer) != (uint8_t)strtoul(token+1, NULL, 16))
		return GPS_PROC_ERR;

	/* Put last comma, goto start and jump '$' */
	*token = ',';
	token = buffer + 1;

	/* Handle GPGGA package */
	if(strncmp(token, "GPGGA", 5) == 0){

		token = strtok_re(token + 6, ',', &p);

		while(token != NULL){

			switch(field_count){

			case GPS_GGA_UTC:
				/* GPS data is not valid if UTC is not set! */
				if(*token == '\0'){
					data->gps.valid = FALSE;
					data->gps.utc.h = 0;
					data->gps.utc.m = 0;
					data->gps.utc.s = 0;
				}else{
					data->gps.valid = TRUE;
					strtotime(token, &data->gps.utc);
				}
				break;

			case GPS_GGA_LAT_1:
				strncpy(&data->gps.lat[0], token, 2);
				data->gps.lat[2] = ' ';
				strncpy(&data->gps.lat[3], token+2, 8);
				break;
			case GPS_GGA_LAT_2:
				data->gps.lat[11] = ' ';
				data->gps.lat[12] = *token;
				data->gps.lat[13] = '\0';
				break;
			case GPS_GGA_LONG_1:
				strncpy(&data->gps.lon[0], token, 3);
				data->gps.lon[3] = ' ';
				strncpy(&data->gps.lon[4], token+3, 8);
				break;
			case GPS_GGA_LONG_2:
				data->gps.lon[12] = ' ';
				data->gps.lon[13] = *token;
				data->gps.lon[14] = '\0';
				break;

			case GPS_GGA_SATELLITES:
				data->gps.sats = atoi(token);
				break;

			case GPS_GGA_ALTITUDE:
				data->gps.alt = atoi(token);
				break;

			}

			/* Increment field count and get next token */
			if(field_count++ == GPS_GGA_ALTITUDE) break;
			token = strtok_re(NULL, ',', &p);

		}

		parsed = GPS_PROC_GGA;

	}else if(strncmp(token, "GPVTG", 5) == 0){

		token = strtok_re(token + 6, ',', &p);

		while(token != NULL){

		switch(field_count){

		case GPS_VTG_SPEED_KM_1:
			if(*token == '\0'){
				data->gps.speed[0] = '\0';
			}else{
				strncpy(&data->gps.speed[0], token, 5);
				data->gps.speed[5] = '\0';
			}

			break;

		}

		if(field_count++ == GPS_VTG_SPEED_KM_1) break;
		token = strtok_re(NULL, ',', &p);

		}

		parsed = GPS_PROC_VTG;

	}else{
		return GPS_PROC_ERR;
	}

	return parsed;
}
