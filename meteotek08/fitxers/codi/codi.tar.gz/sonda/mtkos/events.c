/*  MTKOS - MeTeoteK Operating System (Parts taken from YAVRTOS and aOS)
    Sonda meteorològica dels tecnòlegs de l'IES Bisbal [ http://teslabs.com/meteotek08 ]
    Copyright (C) 2009  Tecnòlegs de l'IES Bisbal - <meteotek08[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <avr/io.h>
#include "mtkos.h"

/* Description: Puts a task in wait event mode for events
 * Flags:		event - the event you want to wait for
 */
void mtkos_event_wait(uint8_t event)
{
	mtkos_enter_critical();

	if(!mtkos_event_check(event, mtkos.tasks.current)){
		mtkos_task_set_state(mtkos.tasks.current, MTKOS_TASK_STATE_WAITING_EVENT);
		mtkos.tasks.current->events_wait |= (event);

		mtkos_yield();
	}

	mtkos_exit_critical();
}

/* Description: Sets an event to one/all task/s and wakes up if waiting for it
 * Flags:		event - the event you want to set
 * 				task - the task, if NULL event will be set up to ALL used tasks
 */
void mtkos_event_set(uint8_t event, task_t *task)
{
	bool_t only_once = TRUE;

	if(!task){
		task = mtkos.tasks.used;
		only_once = FALSE;
	}

	while(task){
		task->events |= (event);
		/* If one task is waiting for this event make it runnable for next schedule */
		if((mtkos_event_wait_check(event, task)) && (mtkos_task_get_state(task) == MTKOS_TASK_STATE_WAITING_EVENT)){
			mtkos_event_clear(event, task);
			mtkos_task_set_state(task, MTKOS_TASK_STATE_RUNNING);
		}

		if(only_once == TRUE) break;

		task = task->next;
	}
}

