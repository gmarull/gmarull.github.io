/*  MTKOS - MeTeoteK Operating System (Parts taken from YAVRTOS and aOS)
    Sonda meteorològica dels tecnòlegs de l'IES Bisbal [ http://teslabs.com/meteotek08 ]
    Copyright (C) 2009  Tecnòlegs de l'IES Bisbal - <meteotek08[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef EVENTS_H_
#define EVENTS_H_


/* Types and defs */
#define mtkos_event_clear(event, task)		(task)->events &= ~(event); (task)->events_wait &= (event)
#define mtkos_event_check(event, task)		((task)->events & (event))
#define mtkos_event_wait_check(event, task)	((task)->events_wait & (event))

/* Functions */
void mtkos_event_wait(uint8_t event);
void mtkos_event_set(uint8_t event, task_t *task);

#endif /* EVENTS_H_ */
