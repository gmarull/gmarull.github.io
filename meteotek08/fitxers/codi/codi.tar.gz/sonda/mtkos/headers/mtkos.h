/*  MTKOS - MeTeoteK Operating System (Parts taken from YAVRTOS and aOS)
    Sonda meteorològica dels tecnòlegs de l'IES Bisbal [ http://teslabs.com/meteotek08 ]
    Copyright (C) 2009  Tecnòlegs de l'IES Bisbal - <meteotek08[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef MTKOS_H_
#define MTKOS_H_

#include "types.h"
#include "tasks.h"
#include "mutex.h"
#include "events.h"
#include "defaults.h"


/* General types and defs */
#define MTKOS_MAX_TASKS			10		// Max number of tasks
#define MTKOS_MAX_MUTEX			8		// Max number of mutexes
#define MTKOS_MAX_EVENTS		8		// Max number of events (note that increasing requires changing system var size!)
#define MTKOS_TICK_INTERVAL		10000	// Tick interval (1ms = 1000)
#define MTKOS_SYS_STACK_SIZE	400		// System Stack size
#define MTKOS_MIN_STACK_SIZE	55		// Min stack for any task
#define MTKOS_MIN_PRIORITY		0		// Min priority
#define MTKOS_MAX_PRIORITY		255		// Max priority

#define F_CPU					8000000UL
#define	TICK_PRESCALER			8
// Use them with mtkos_sleep to make more accurated delays (minimum delay = system tick!)
#define time_s(sec)				(sec) * (( F_CPU / TICK_PRESCALER ) / MTKOS_TICK_INTERVAL)
#define time_ms(ms)				(((ms)  * ( F_CPU / (TICK_PRESCALER * 1000))) / MTKOS_TICK_INTERVAL)

#define mtkos_enter_critical()	asm volatile ("cli")
#define mtkos_exit_critical()	asm volatile ("sei")

#define mtkos_tick_enable()		TIMSK3 |= (1<<OCIE3A)
#define mtkos_tick_disable()	TIMSK3 &= ~(1<<OCIE3A)

/* Global system vars */
struct {
	char *heap_start;
	char *heap_end;
	uint8_t *stack;
	struct {
		task_t *current;
		task_t *used;
		task_t *free;
		task_t list[MTKOS_MAX_TASKS];
	}tasks;
	struct {
		mutex_t *used;
		mutex_t *free;
		mutex_t list[MTKOS_MAX_MUTEX];
	}mutex;
}mtkos;


/* Functions */
void mtkos_init(void (*idle)(void), uint16_t idle_stack);
void mtkos_run(void) __attribute__ ((naked));
void mtkos_sleep(uint32_t ticks);
uint8_t mtkos_disable_interrupts(void);
void mtkos_restore_interrupts(uint8_t interrupts);
void *mtkos_alloc_stack(uint16_t size);

#endif /* MTKOS_H_ */
