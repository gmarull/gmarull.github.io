/*  MTKOS - MeTeoteK Operating System (Parts taken from YAVRTOS and aOS)
    Sonda meteorològica dels tecnòlegs de l'IES Bisbal [ http://teslabs.com/meteotek08 ]
    Copyright (C) 2009  Tecnòlegs de l'IES Bisbal - <meteotek08[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef TASKS_H_
#define TASKS_H_

/* Types and defs */
#define TASK_ME							mtkos.tasks.current
#define TASK_IDLE						0

#define MTKOS_TASK_STATE_RUNNING	 	0
#define MTKOS_TASK_STATE_SLEEPING		1
#define MTKOS_TASK_STATE_WAITING		2
#define MTKOS_TASK_STATE_WAITING_EVENT	3
#define MTKOS_TASK_STATE_SUSPENDED		4
#define MTKOS_TASK_STATE_STOPPED		5

#define mtkos_task_set_state(task, stat)	(task)->state = (stat)
#define mtkos_task_get_state(task)			(task)->state

typedef struct task{

	uint8_t id;

	uint16_t stack_size;
	uint8_t *stack_top;
	uint8_t *sp;

	uint8_t priority;
	volatile uint8_t state;
	volatile uint32_t sleep;

	volatile uint8_t events;
	volatile uint8_t events_wait;

	void (*proc)(void);

	struct task *next;
	struct task *mutex_queue;

}task_t;

/* Functions */
void mtkos_schedule(void);
task_t *mtkos_task_create(uint8_t id, void (*proc)(void), uint16_t stack_size, uint8_t priority);
task_t *mtkos_task_find(uint8_t id);
void mtkos_task_stop(task_t *task, bool_t yield);
void mtkos_task_reset(task_t *task, uint8_t init_events, bool_t yield);
void mtkos_yield(void) __attribute__ ((naked));

/* Others */
#define save_cpu_context() __asm__ volatile( \
		"push  r0\n in r0, __SREG__\n cli\n" \
		"push  r1\n push  r2\n push  r3\n push  r4\n push  r5\n push  r6\n push  r7\n" \
		"push  r8\n push  r9\n push r10\n push r11\n push r12\n push r13\n push r14\n push r15\n" \
		"push r16\n push r17\n push r18\n push r19\n push r20\n push r21\n push r22\n push r23\n" \
		"push r24\n push r25\n push r26\n push r27\n push r28\n push r29\n push r30\n push r31\n" \
		"push  r0\n" ::)

#define restore_cpu_context() __asm__ volatile ( \
		"pop r0\n" \
		"pop r31\n pop r30\n pop r29\n pop r28\n pop r27\n pop r26\n pop r25\n pop r24\n" \
		"pop r23\n pop r22\n pop r21\n pop r20\n pop r19\n pop r18\n pop r17\n pop r16\n" \
		"pop r15\n pop r14\n pop r13\n pop r12\n pop r11\n pop r10\n pop  r9\n pop  r8\n" \
		"pop  r7\n pop  r6\n pop  r5\n pop  r4\n pop  r3\n pop  r2\n pop  r1\n out __SREG__, r0\n pop  r0\n" ::)

#endif /* TASKS_H_ */
