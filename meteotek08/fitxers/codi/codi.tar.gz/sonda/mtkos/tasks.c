/*  MTKOS - MeTeoteK Operating System (Parts taken from YAVRTOS and aOS)
    Sonda meteorològica dels tecnòlegs de l'IES Bisbal [ http://teslabs.com/meteotek08 ]
    Copyright (C) 2009  Tecnòlegs de l'IES Bisbal - <meteotek08[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mtkos.h"


/* Description: Creates a task
 * Flags:		proc - pointer to the task function (must be of this type: void func(void))
 * 				stack_size - stack that will be allocated for this task
 * 				priority - priority of this task (0..255)
 * Returns:		A pointer to the task created (NULL if no more task places are available)
 */
task_t *mtkos_task_create(uint8_t id, void (*proc)(void), uint16_t stack_size, uint8_t priority)
{
	task_t *task;

	/* Take next free task in the list */
	task = mtkos.tasks.free;
	if(!task) return NULL;

	/* Allocate stack */
	task->stack_top = (uint8_t*)mtkos_alloc_stack(stack_size);
	if(!task->stack_top) return NULL;

	/* Arrange lists */
	mtkos.tasks.free = task->next;
	task->next = mtkos.tasks.used;
	mtkos.tasks.used = task;

	/* Set task vars */
	task->id = id;
	task->sp = task->stack_top;
	task->stack_size = stack_size;
	task->proc = proc;
	task->priority = priority;
	task->mutex_queue = NULL;
	task->sleep = 0;
	task->events = 0;
	task->events_wait = 0;
	mtkos_task_set_state(task, MTKOS_TASK_STATE_RUNNING);

	/* Create a valid stack: The function pointer, the 32 registers and SREG (with interrupts enabled) */
 	*((task->sp)--) = ((uint16_t)proc);
	*((task->sp)--) = ((uint16_t)proc) >> 8;

	for(uint8_t i=0; i<32; i++){
		*((task->sp)--) = 0;
	}
	*((task->sp)--) = (1 << SREG_I);

	return task;
}


/* Description: Stops a task (takes care of mutexes)
 * Flags:		task - the task you want to stop
 * 				yield - TRUE if you want to yield after stopping this task, FALSE if not.
 * */
void mtkos_task_stop(task_t *task, bool_t yield)
{
	mutex_t *mutex;

	/* Do not stop stopped tasks! */
	if(mtkos_task_get_state(task) == MTKOS_TASK_STATE_STOPPED) return;

	mtkos_enter_critical();

	/* Take care of mutexes owned by this task */
	mutex = mtkos.mutex.used;
	while(mutex){
		if(mutex->owner == task){
			if(mutex->queue != NULL){
				mutex->owner = mutex->queue;
				mutex->queue = mutex->queue->mutex_queue;
				mtkos_task_set_state(mutex->owner, MTKOS_TASK_STATE_RUNNING);
			}else{
				mutex->locked = FALSE;
			}
		}

		mutex = mutex->next;
	}

	/* Stop task and schedule */
	mtkos_task_set_state(task, MTKOS_TASK_STATE_STOPPED);

	/* Yield only if wanted */
	if(yield == TRUE){
		mtkos_yield();
	}

	mtkos_exit_critical();
}

/* Description: Will reset a task (as if it was going to run for first time)
 * Notes:		Task state must NOT have locked semaphores
 */
void mtkos_task_reset(task_t *task, uint8_t init_events, bool_t yield)
{
	/* First stop task without yielding */
	mtkos_task_stop(task, FALSE);

	mtkos_enter_critical();

	task->sp = task->stack_top;
	task->mutex_queue = NULL;
	task->sleep = 0;
	task->events = init_events;
	task->events_wait = init_events;
	mtkos_task_set_state(task, MTKOS_TASK_STATE_RUNNING);

	/* Reset the stack */
 	*((task->sp)--) = ((uint16_t)task->proc);
	*((task->sp)--) = ((uint16_t)task->proc) >> 8;

	for(uint8_t i=0; i<32; i++){
		*((task->sp)--) = 0;
	}
	*((task->sp)--) = (1 << SREG_I);

	/* Yield only if wanted */
	if(yield == TRUE){
		mtkos_yield();
	}

	mtkos_exit_critical();
}

/* Description: Will try to find a task with the given name
 * Flags:		The name of the task (max 3char.)
 */
task_t *mtkos_task_find(uint8_t id)
{
	task_t *task;

	task = mtkos.tasks.used;

	while(task){
		if(task->id == id) return task;
		task = task->next;
	}

	return NULL;
}

/* Description: Stores current context, schedules and switch to new context
 * Notes:		Be careful on where your current task will continue later
 * 				- Naked function -
 */
void mtkos_yield()
{

	mtkos_enter_critical();

	/* Save current context */
	save_cpu_context();
	mtkos.tasks.current->sp = (uint8_t *)SP;

	/* Setup system stack and schedule */
	SP = (uint16_t) mtkos.stack;
	mtkos_schedule();

	/* Restore context */
	SP = (uint16_t) mtkos.tasks.current->sp;
	restore_cpu_context();

	mtkos_exit_critical();

	asm volatile ("ret");
}

/* Description: Scheduler - Will look trough running tasks to select the one which is ready to run
 * Notes:		This is a pre-emptive scheduler, it will NOT make a yield, this has to be done by
 * 				the user/sys, it will just put the current task pointer to the "best" one, handle
 * 				sleeping tasks, etc.
 */
void mtkos_schedule()
{

	task_t *task, *run;

	task = mtkos.tasks.current;
	run = mtkos.tasks.current;
	do {

		/* Handle delayed tasks counter */
		if(mtkos_task_get_state(task) == MTKOS_TASK_STATE_SLEEPING){
			task->sleep--;
			if(task->sleep == 0) mtkos_task_set_state(task, MTKOS_TASK_STATE_RUNNING);
		}

		/* Look for the task that should run */
		if ((task->priority >= run->priority) && (mtkos_task_get_state(task) == MTKOS_TASK_STATE_RUNNING)) {
			run = task;
		}

		task = task->next;
		if (!task) task = mtkos.tasks.used;

	} while (task != mtkos.tasks.current);

	/* Setup new current task */
	mtkos.tasks.current = run;

}
