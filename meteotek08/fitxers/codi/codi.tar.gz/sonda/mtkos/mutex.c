/*  MTKOS - MeTeoteK Operating System (Parts taken from YAVRTOS and aOS)
    Sonda meteorològica dels tecnòlegs de l'IES Bisbal [ http://teslabs.com/meteotek08 ]
    Copyright (C) 2009  Tecnòlegs de l'IES Bisbal - <meteotek08[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <stdlib.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/sleep.h>
#include "mtkos.h"


/* Description: Creates a mutex
 * Returns:		The created mutex
 */
mutex_t *mtkos_mutex_create()
{
	mutex_t *mutex;

	mutex = mtkos.mutex.free;
	if(!mutex) return NULL;

	mtkos.mutex.free = mutex->next;
	mutex->next = mtkos.mutex.used;
	mtkos.mutex.used = mutex;

	mutex->locked = FALSE;
	mutex->queue = NULL;
	mutex->owner = NULL;

	return mutex;
}

/* Description: Mutex Lock
 * Flags:		mutex - the mutex you want to use
 */
void mtkos_lock(mutex_t *mutex)
{
	task_t *task;

	mtkos_enter_critical();

	/* If available places just decrease */
	if(mutex->locked == FALSE){
		mutex->locked = TRUE;
		mutex->owner = mtkos.tasks.current;
	/* If not enqueue task and yield */
	}else{
		task = mutex->queue;
		if(task){
			while(task->mutex_queue) task = task->mutex_queue;
			task->mutex_queue = mtkos.tasks.current;
		}else{
			mutex->queue = mtkos.tasks.current;
		}
		mtkos.tasks.current->mutex_queue = NULL;
		mtkos_task_set_state(mtkos.tasks.current, MTKOS_TASK_STATE_WAITING);
		mtkos_yield();
	}

	mtkos_exit_critical();

}

/* Description: Unlock mutex
 * Flags:		mutex - the mutex you want to use
 */
void mtkos_unlock(mutex_t *mutex)
{
	task_t *task;

	mtkos_enter_critical();

	task = mutex->queue;
	/* If there's any task in queue re-arrange the queue (yield) */
	if(task){
		mutex->queue = task->mutex_queue;
		mutex->owner = task;
		mtkos_task_set_state(task, MTKOS_TASK_STATE_RUNNING);
		mtkos_yield();
	/* If not just unlock */
	}else{
		mutex->locked = FALSE;
		mutex->owner = NULL;
	}

	mtkos_exit_critical();
}
