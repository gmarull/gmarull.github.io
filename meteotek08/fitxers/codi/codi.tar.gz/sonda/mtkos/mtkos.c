/*  MTKOS - MeTeoteK Operating System (Parts taken from YAVRTOS and aOS)
    Sonda meteorològica dels tecnòlegs de l'IES Bisbal [ http://teslabs.com/meteotek08 ]
    Copyright (C) 2009  Tecnòlegs de l'IES Bisbal - <meteotek08[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/sleep.h>
#include <avr/wdt.h>
#include <stdio.h>
#include <stdlib.h>
#include "mtkos.h"

/* Description: Tick interrupt - Stores current context, runs the scheduler and restores the
 * 				context to the enqueued task (may have been changed or not by the scheduler)
 * Notes:		NAKED Interrupt (must care about machine state and reti)
 */
ISR(TIMER3_COMPA_vect, ISR_NAKED)
{
	/* Save context and enable interrupts in that SREG for next restore */
	save_cpu_context();
	mtkos.tasks.current->sp = (uint8_t *)SP;

	/* Switch to MTKOS stack and reset wdt + run scheduler */
	SP = (uint16_t) mtkos.stack;
	wdt_reset();
	mtkos_schedule();

	/* Context will be restored to enqueued task (may have been changed by the scheduler) */
	SP = (uint16_t) mtkos.tasks.current->sp;
	restore_cpu_context();

	sei();
	asm volatile ("reti");
}

/* Description: Initializes MTKOS (timer, system stack, idle task...)
 * Notes:		Must be called before using any other MTKOS functions!
 */
void mtkos_init(void (*idle)(void), uint16_t idle_stack)
{
	uint8_t i;

	/* Setup tick timer */
	TCCR3B = (1<<CS31) | (1<<WGM32);
	OCR3A = MTKOS_TICK_INTERVAL;
	TIFR3 = (1<<OCF3A);
	mtkos_tick_enable();

	/* Setup mtkos system stack */
	mtkos.heap_start = __malloc_heap_start;
	mtkos.stack = (uint8_t*)mtkos_alloc_stack(MTKOS_SYS_STACK_SIZE);

	/* Initialize task list */
	mtkos.tasks.free = &mtkos.tasks.list[0];
	for(i=0; i < (MTKOS_MAX_TASKS - 1); i++){
		mtkos.tasks.list[i].next = &mtkos.tasks.list[i+1];
	}
	mtkos.tasks.list[i].next = NULL;

	/* Initialize semaphore list */
	mtkos.mutex.free = &mtkos.mutex.list[0];
	for(i=0; i < (MTKOS_MAX_MUTEX - 1); i++){
		mtkos.mutex.list[i].next = &mtkos.mutex.list[i+1];
	}
	mtkos.mutex.list[i].next = NULL;

	/* Setup idle task */
	mtkos_task_create(TASK_IDLE, idle, idle_stack, MTKOS_MIN_PRIORITY);
	mtkos.tasks.current = &mtkos.tasks.list[0];

}

/* Description:	Starts multitasking and enables Watchdog
 * Notes:		Note that this function will never return to its calling point!
 */
void mtkos_run()
{
	wdt_enable(CONF_WDTO);

	SP = (uint16_t) mtkos.stack;

	mtkos_schedule();

	SP = (uint16_t) mtkos.tasks.current->sp;
	restore_cpu_context();

	asm volatile ("ret");
}

/* Description: Sleeps a task for X ticks
 * Flags:		ticks - number of ticks that task will be kept slept
 * Notes:		While a task is sleeping other tasks will keep running (obviously)
 * 				See time_s and time_ms to make "accurate delays" (mtkos.h)
 */
void mtkos_sleep(uint32_t ticks)
{
	mtkos_enter_critical();

	mtkos.tasks.current->sleep = ticks;
	mtkos_task_set_state(mtkos.tasks.current, MTKOS_TASK_STATE_SLEEPING);

	mtkos_yield();

	mtkos_exit_critical();
}

/* Description: Disables interrupts
 * Returns:		Value of SREG_I (0/1)
 * Notes:		Use it only in case you need to keep old interrupts state
 */
uint8_t mtkos_disable_interrupts()
{
	uint8_t ans = (SREG & (1 << SREG_I));
	cli();
	return ans;
}

/* Description: Restores interrupts only if needed
 * Flags:		interrupts - SREG_I (returned by disable_interrupts)
 * Notes:		Use it only in case you need to keep old interrupts state
 */
void mtkos_restore_interrupts(uint8_t interrupts)
{
	if (interrupts)
		sei();
	else
		cli();
}

/* Description: MTKOS Memory allocator */
void *mtkos_alloc_stack(uint16_t size)
{
	if((uint16_t)(mtkos.heap_start + size) >= RAMEND) return NULL;

	mtkos.heap_start += size;

	return (void*)(mtkos.heap_start - 1);
}
