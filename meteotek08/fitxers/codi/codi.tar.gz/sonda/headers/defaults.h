/*  Meteotek08 - Sonda meteorològica dels tecnòlegs de l'IES Bisbal [ http://teslabs.com/meteotek08 ]
    Copyright (C) 2009  Tecnòlegs de l'IES Bisbal - <meteotek08[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef DEFAULTS_H_
#define DEFAULTS_H_


/* Valors per defecte i paràmetres configurables en temps de compilació */
// Varis //
#define CONF_WDTO					WDTO_2S		// Temp màxim d'espera pel watchdog
#define CONF_INIT_WAIT				5			// Segons d'espera a l'arrancar el sistema (pel lock)

// Vol: General //
#define CONF_FLIGHT_MODE			MODE_FLIGHT	// Mode de vol per defecte
// Vol: Notifier //
#define CONF_FLIGHT_NOTIF_INTERVAL	10			// Interval d'enviament de missatges per ràdio

// Càmera i servo //
#define CONF_CAM_INTERVAL			25			// Interval entre cada fotografia
#define CONF_CAM_SERVO_ACT			TRUE		// Activar/des el servo per defecte
#define CONF_CAM_SERVO_CHG_DOWN		2			// Fotografies seguides amb el servo avall
#define CONF_CAM_SERVO_CHG_MID		2			// Fotografies seguides amb el servo horitzontal
#define CONF_CAM_SERVO_CHG_UP		1			// Fotografies seguides amb el servo amunt
#define CONF_SERVO_STOP_ALT			10000		// Altura a la que el servo quedarà fixat

// Sensors //
#define CONF_SENS_PRESS_ACT			TRUE		// Activar/des el sensor de pressió per defecte
#define CONF_SENS_TEXT_ACT			TRUE		// Activar/des el sensor de temp. extern per defecte
#define CONF_SENS_TINT_ACT			TRUE		// Activar/des el sensor de temp. intern per defecte

// GPS //
#define CONF_GPS_BRIDGED			FALSE		// Activar/des el GPS amb bridge mode per defecte

/* Funcio que carregara els valors per defecte en començar */
void mtk_load_defaults(void);

#endif /* DEFAULTS_H_ */
