/*  Meteotek08 - Sonda meteorològica dels tecnòlegs de l'IES Bisbal [ http://teslabs.com/meteotek08 ]
    Copyright (C) 2009  Tecnòlegs de l'IES Bisbal - <meteotek08[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef METEOTEK_H_
#define METEOTEK_H_


/* Include all headers */
#include "types.h"
#include "ports.h"
#include "defaults.h"
#include "mtkos.h"
#include "others/utils.h"
#include "others/data.h"
#include "devices/radio.h"
#include "devices/gps.h"
#include "devices/camera.h"
#include "devices/pressure.h"
#include "devices/temperature.h"
#include "devices/cutdown.h"



/* System tasks functions */
void task_idle(void);
void task_meteotek_init(void);
void task_data_manager(void);
void task_petition_manager(void);
void task_camera_manager(void);
void task_notifier(void);


/* MTKOS related things */
// Tasks //
#define TASK_INIT				1
#define TASK_DAT_MANAGER		2
#define TASK_PET_MANAGER		3
#define TASK_CAM_MANAGER		4
#define TASK_NOTIFIER			5

// Events //
#define EVENT_SYS_INIT			(1<<0)
#define EVENT_SYS_INIT_LOCK		(1<<1)
#define EVENT_SYS_INIT_UNLOCK	(1<<2)
#define EVENT_TASK_EXIT			(1<<3)


/* Types and defs */
// Flight modes //
#define MODE_FLIGHT				0
#define MODE_LANDED				1

// Status //
#define mtk_stat_set(stat)	mtk.status |= (stat)
/// 0-7 - Initializations ///
#define STAT_INIT_DONE_DATA		(1<<0)
#define STAT_INIT_DONE_CAM		(1<<1)
#define STAT_INIT_DONE_NOTIF	(1<<2)
#define STAT_INIT_DONE_PET		(1<<3)

#define STAT_INIT_DONE_ALL		(STAT_INIT_DONE_DATA | STAT_INIT_DONE_CAM | STAT_INIT_DONE_NOTIF | STAT_INIT_DONE_PET)

/// 8-15 - Reports (indicators of device init failure) ///
#define STAT_REPORT_SD			(1<<8)
#define STAT_REPORT_PRESS		(1<<9)



// Meteotek global vars //
struct information {

	volatile uint16_t status;

	struct{
		mutex_t *spi;
		mutex_t *radio;
		mutex_t *data;
	}mutex;

	/* Data from GPS & sensors */
	mtk_data data;

	/* Configurable things */
	struct{
		/* Camera and servo */
		struct{
			uint8_t shot_interval;
			uint8_t servo_chg_down;
			uint8_t servo_chg_mid;
			uint8_t servo_chg_up;
			bool_t  servo_act;
		}cam;

		/* Flight */
		struct{
			uint8_t mode;
			uint8_t notif_interval;
			bool_t bridged_gps;
			bool_t radio_log_act;
		}flight;

		/* Sensors */
		struct{
			bool_t press_act;
			bool_t t_ext_act;
			bool_t t_int_act;
		}sen;

	}conf;

}mtk;


/* Others */
#define spi_init() 	SPI_DDR |= (1<<SPI_MOSI) | (1<<SPI_SCK) | (1<<SPI_SS);\
					SPCR = (1<<SPE) | (1<<MSTR) | (1<<SPR0)


#endif /* METEOTEK_H_ */
