/*  Meteotek08 - Sonda meteorològica dels tecnòlegs de l'IES Bisbal [ http://teslabs.com/meteotek08 ]
    Copyright (C) 2009  Tecnòlegs de l'IES Bisbal - <meteotek08[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef GPS_H_
#define GPS_H_


/* Types and defs */

/* Optimized macro that returns the next ring (circular) buffer index */
#define GPS_NEXT_INDEX(index, buffer_size) \
    { \
        uint8_t temp = index; \
        temp++; \
        /* See if buffer size is a power of two */ \
        if((buffer_size&(buffer_size-1)) == 0) \
        { \
            /* Use masking to optimize pointer wrapping to index 0 */ \
            temp &= buffer_size-1; \
        } \
        else \
        { \
            /* Wrap index to 0 if it has exceeded buffer boundary */ \
            if(temp == (uint8_t)buffer_size) temp = 0; \
        } \
        index = temp; \
    }

#define gps_enable_reception()		UCSR1B |= (1 << RXCIE1)
#define gps_disable_reception()		UCSR1B &= ~(1 << RXCIE1)

#define GPS_BUFFER_SIZE			83	// Default GPS buffer size
#define GPS_INIT_UBRR			103 // 4800baud @ 8Mhz

/* NMEA */
// Message output configuration (Copernicus Trimble specific) //
#define GPS_OUT_GGA	(1<<0)
#define GPS_OUT_GLL	(1<<1)
#define GPS_OUT_VTG	(1<<2)
#define GPS_OUT_GSV	(1<<3)
#define GPS_OUT_GSA	(1<<4)
#define GPS_OUT_ZDA	(1<<5)
#define GPS_OUT_RMC	(1<<8)
#define GPS_OUT_TF	(1<<9)
#define GPS_OUT_BA	(1<<13)

// Message processor codes //
#define GPS_PROC_ERR	0
#define GPS_PROC_GGA	1
#define GPS_PROC_GLL	2
#define GPS_PROC_GSA	3
#define GPS_PROC_GSV	4
#define GPS_PROC_RMC	5
#define GPS_PROC_VTG	6
#define GPS_PROC_ZDA	7

/* NMEA Messages fields */
// GGA Message fields //
#define GPS_GGA_UTC				1
#define GPS_GGA_LAT_1			2
#define GPS_GGA_LAT_2			3
#define GPS_GGA_LONG_1			4
#define GPS_GGA_LONG_2			5
#define GPS_GGA_QUALITY			6
#define GPS_GGA_SATELLITES		7
#define GPS_GGA_ALTITUDE		9
// VTG Message fields //
#define GPS_VTG_SPEED_KM_1		7


/* Functions */
void gps_init(void);
uint8_t gps_nmea_calc_checksum(const char *buffer);
uint8_t gps_nmea_parse(char *buffer, mtk_data *data);

bool_t gps_buffer_is_empty(void);
bool_t gps_get_byte(uint8_t* data);

#endif /*GPS_H_*/
