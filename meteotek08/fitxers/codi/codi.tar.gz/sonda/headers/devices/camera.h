/*  Meteotek08 - Sonda meteorològica dels tecnòlegs de l'IES Bisbal [ http://teslabs.com/meteotek08 ]
    Copyright (C) 2009  Tecnòlegs de l'IES Bisbal - <meteotek08[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef CAMERA_H_
#define CAMERA_H_

/* Module global vars */
struct{
	uint8_t  power;
	uint16_t shots;
	uint8_t  servo_pos;
}cam;

/* Types and defs */
#define SERVO_POS_DOWN	20
#define SERVO_POS_MID	110
#define SERVO_POS_UP	180

/* Functions */
void cam_init(void);
void cam_shot(void);
void cam_power(void);
void cam_servo_init(void);
void cam_servo_set_pos(uint8_t pos);

#endif /*CAMERA_H_*/
