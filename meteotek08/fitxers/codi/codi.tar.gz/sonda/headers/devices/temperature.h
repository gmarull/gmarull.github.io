/*  Meteotek08 - Sonda meteorològica dels tecnòlegs de l'IES Bisbal [ http://teslabs.com/meteotek08 ]
    Copyright (C) 2009  Tecnòlegs de l'IES Bisbal - <meteotek08[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef TEMPERATURE_H_
#define TEMPERATURE_H_

/* Types, defs and internal vars */

/* Used insted of floating point (crashes occur randomly using them?) */
typedef struct{
	int8_t dec;
	uint16_t frac;
}temperature_t;

#define TEMP_INPUT_MODE()		TEMP_DDR&=~(1<<temp_selector)
#define TEMP_OUTPUT_MODE()		TEMP_DDR|=(1<<temp_selector)
#define TEMP_LOW()				TEMP_PORT&=~(1<<temp_selector)
#define TEMP_HIGH()				TEMP_PORT|=(1<<temp_selector)

// Commands //
#define TEMP_CMD_CONVERTTEMP	0x44
#define TEMP_CMD_RSCRATCHPAD	0xbe
#define TEMP_CMD_WSCRATCHPAD	0x4e
#define TEMP_CMD_CPYSCRATCHPAD	0x48
#define TEMP_CMD_RECEEPROM		0xb8
#define TEMP_CMD_RPWRSUPPLY		0xb4
#define TEMP_CMD_SEARCHROM		0xf0
#define TEMP_CMD_READROM		0x33
#define TEMP_CMD_MATCHROM		0x55
#define TEMP_CMD_SKIPROM		0xcc
#define TEMP_CMD_ALARMSEARCH	0xec

/* Functions */
temperature_t temp_get(uint8_t selector);
uint8_t temp_reset(void);
void temp_write_bit(uint8_t bit);
void temp_write_byte(uint8_t byte);
uint8_t temp_read_bit(void);
uint8_t temp_read_byte(void);


#endif /*TEMPERATURE_H_*/
