/*  Meteotek08 - Sonda meteorològica dels tecnòlegs de l'IES Bisbal [ http://teslabs.com/meteotek08 ]
    Copyright (C) 2009  Tecnòlegs de l'IES Bisbal - <meteotek08[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef RADIO_H_
#define RADIO_H_

/* Optimized macro that returns the next ring (circular) buffer index */
#define RADIO_NEXT_INDEX(index, buffer_size) \
    { \
        uint8_t temp = index; \
        temp++; \
        /* See if buffer size is a power of two */ \
        if((buffer_size&(buffer_size-1)) == 0) \
        { \
            /* Use masking to optimize pointer wrapping to index 0 */ \
            temp &= buffer_size-1; \
        } \
        else \
        { \
            /* Wrap index to 0 if it has exceeded buffer boundary */ \
            if(temp == (uint8_t)buffer_size) temp = 0; \
        } \
        index = temp; \
    }

/* Types and defs */
#define RADIO_UBRR			51 // 9600baud @ 8Mhz
#define RADIO_BUFFER_SIZE	125

// Packet processor return codes //
#define RADIO_PROC_ERR	0
#define RADIO_PROC_OK	1

/* Radio Packets */
// Configurators (Note: E and F are available for CFG right now) //
#define PKT_CAM_CFG		'A'
#define PKT_SEN_CFG		'B'
#define PKT_FLI_CFG		'C'
// Data Messages //
#define PKT_GEN			'G'
#define PKT_QUERY		'Q'
// Others //
#define PKT_INIT_LOCK	'L'
#define PKT_INIT_UNLOCK	'U'
#define PKT_PET_OK		'O'
#define PKT_PET_ERR		'R'
#define PKT_CAM_PWR_TOG	'M'
#define PKT_CAM_SHT_TOG	'N'

// Critical messages (Note: V is available for CFG right now) //
#define PKT_WDT			'W'
#define PKT_TASK_RST	'X'
#define PKT_SYS_RST		'Y'
#define PKT_CUTDOWN		'Z'

/* Radio packets fields */
// Camera config //
#define PKT_CAM_CFG_FIELDS			7
#define PKT_CAM_CFG_ACT				0
#define PKT_CAM_CFG_INTERVAL		1
#define PKT_CAM_CFG_SER_ACT			2
#define PKT_CAM_CFG_SER_POS			3
#define PKT_CAM_CFG_SER_CHG_D		4
#define PKT_CAM_CFG_SER_CHG_M		5
#define PKT_CAM_CFG_SER_CHG_U		6
// Sensors config //
#define PKT_SEN_CFG_FIELDS			3
#define PKT_SEN_CFG_PRESS_ACT		0
#define PKT_SEN_CFG_TEXT_ACT		1
#define PKT_SEN_CFG_TINT_ACT		2
// Flight config //
#define PKT_FLI_CFG_FIELDS			3
#define PKT_FLI_CFG_MODE			0
#define PKT_FLI_CFG_NOTIF_INTERVAL	1
#define PKT_FLI_CFG_GPS_BRIDGE		2


/* Functions */
void radio_init(void);
bool_t radio_get_byte(uint8_t* data);
bool_t radio_buffer_is_empty(void);
int radio_printf(const char *format, ...);
uint8_t radio_calc_checksum(char *message);
uint8_t radio_proc_pkt(char *buffer);
void radio_proc_pkt_cam_cfg(char *token, char *p);
void radio_proc_pkt_sen_cfg(char *token, char *p);
void radio_proc_pkt_fli_cfg(char *token, char *p);

#endif /*RADIO_H_*/
