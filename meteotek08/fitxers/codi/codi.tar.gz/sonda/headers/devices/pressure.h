/*  Meteotek08 - Sonda meteorològica dels tecnòlegs de l'IES Bisbal [ http://teslabs.com/meteotek08 ]
    Copyright (C) 2009  Tecnòlegs de l'IES Bisbal - <meteotek08[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/


#ifndef PRESSURE_H_
#define PRESSURE_H_

/* Types and defs */
#define spi_speed_low()		SPCR |= (1<<SPR0); SPSR &= ~(1<<SPI2X)
#define spi_speed_high()	SPCR &= ~((1<<SPR0) | (1<<SPR1)); SPSR |= (1<<SPI2X)

#define press_select()		PRESS_PORT &= ~(1<<PRESS_CSB)
#define press_deselect()	PRESS_PORT |= (1<<PRESS_CSB)

// Command codes //
#define PRESS_REVID		0x00
#define PRESS_DATAWR	0x01
#define PRESS_ADDPTR	0x02
#define PRESS_OPERATION	0x03
#define PRESS_OPSTATUS	0x04
#define PRESS_RSTR		0x06
#define PRESS_STATUS	0x07
#define PRESS_DATARD8	0x1f
#define PRESS_DATARD16	0x20
#define PRESS_TEMPOUT	0x21
#define PRESS_CFG		0x00


/* Functions */
uint8_t press_init(void);
uint32_t press_get(void);
uint16_t press_read_direct_access(uint8_t address, uint8_t num_of_bytes);
uint16_t press_read_indirect_access(uint8_t address);
void press_write_direct_access(uint8_t address, uint8_t data);
void press_write_indirect_access(uint8_t address, uint8_t data);

#endif /*PRESSURE_H_*/
