/*  Meteotek08 - Sonda meteorològica dels tecnòlegs de l'IES Bisbal [ http://teslabs.com/meteotek08 ]
    Copyright (C) 2009  Tecnòlegs de l'IES Bisbal - <meteotek08[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#ifndef DATA_H_
#define DATA_H_

#include "devices/temperature.h"
#include "types.h"

/* Types and defs */
typedef struct{
	/* GPS data */
	struct{
		bool_t valid;
		time_t utc;
		char lat[15];
		char lon[15];
		int32_t alt;
		uint16_t sats;
		char speed[7];
	}gps;

	/* Sensors data */
	struct{
		uint32_t press;
		temperature_t t_ext;
		temperature_t t_int;
	}sen;

}mtk_data;

/* Functions */
void mtk_update_data(const mtk_data *data);
void mtk_get_data(mtk_data *data);


#endif /* DATA_H_ */
