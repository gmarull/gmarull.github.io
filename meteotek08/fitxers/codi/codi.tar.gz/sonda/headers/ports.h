/*  Meteotek08 - Sonda meteorològica dels tecnòlegs de l'IES Bisbal [ http://teslabs.com/meteotek08 ]
    Copyright (C) 2009  Tecnòlegs de l'IES Bisbal - <meteotek08[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef PORTS_H_
#define PORTS_H_

/* SPI */
#define SPI_PORT		PORTB
#define SPI_DDR			DDRB
#define SPI_PIN			PINB
#define SPI_MISO		PB3
#define SPI_MOSI		PB2
#define SPI_SCK			PB1
#define SPI_SS			PB0

/* Servo */
#define SERVO_PORT		PORTB
#define SERVO_DDR		DDRB
#define SERVO_PIN		PINB
#define SERVO_CTL		PB5

/* Camera */
#define CAM_PORT		PORTD
#define CAM_DDR			DDRD
#define CAM_PIN			PIND
#define CAM_PWR			PD4
#define CAM_SHOT		PD5

/* Presssure sensor */
#define PRESS_PORT		PORTE
#define PRESS_DDR		DDRE
#define PRESS_PIN		PINE
#define PRESS_DRDY		PE6
#define PRESS_CSB		PE7

/* Temperature sensor */
#define TEMP_PORT		PORTB
#define TEMP_DDR		DDRB
#define TEMP_PIN		PINB
#define TEMP_INT		PB7
#define TEMP_EXT		PB6

/* SD Card */
#define SD_PORT      	PORTE
#define SD_DDR       	DDRE
#define SD_PIN      	PINE
#define SD_CS			PE5

/* Cutdown */
#define CUTDOWN_PORT	PORTB
#define CUTDOWN_DDR		DDRB
#define CUTDOWN_PIN		PINB
#define CUTDOWN_CTL		PB4


#endif /*PORTS_H_*/
