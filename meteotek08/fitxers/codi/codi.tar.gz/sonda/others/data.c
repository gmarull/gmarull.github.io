/*  Meteotek08 - Sonda meteorològica dels tecnòlegs de l'IES Bisbal [ http://teslabs.com/meteotek08 ]
    Copyright (C) 2009  Tecnòlegs de l'IES Bisbal - <meteotek08[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <avr/io.h>
#include "mtk.h"

/* Updates system data */
void mtk_update_data(const mtk_data *data)
{
	mtkos_lock(mtk.mutex.data);

	mtk.data = *data;

	mtkos_unlock(mtk.mutex.data);
}

/* Gets a copy of system data */
void mtk_get_data(mtk_data *data)
{
	mtkos_lock(mtk.mutex.data);

	*data = mtk.data;

	mtkos_unlock(mtk.mutex.data);
}

