/*  Meteotek08 - Sonda meteorològica dels tecnòlegs de l'IES Bisbal [ http://teslabs.com/meteotek08 ]
    Copyright (C) 2009  Tecnòlegs de l'IES Bisbal - <meteotek08[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <avr/io.h>
#include <string.h>
#include <stdbool.h>
#include "mtk.h"
#include "mtkos.h"

/* Description: strtok reentrant version that will not ignore 'null space' between 2 delimiters (ex. ,, or ||)
 * Returns:		Token
 * Notes:		Use always reentrant versions as they are thread-safe
 */
char *strtok_re(char *source, const char delim, char **p)
{
	char *s, *t;

	s = t = source ? source : *p;

	while((*t != delim) && (*t)) t++;

	*p = t;
	if(!*(*p)) return NULL;
	*(*p)++ = '\0';

	return s;
}

/* Description:	Converts a string to a time_t type
 * Example:		String "090102" in the time_t would be (h=09, m=01, s=02)
 */
void strtotime(char *str, time_t *time)
{
	time->h = (*(str++) - '0') * 10;
	time->h += *(str++) - '0';
	time->m = (*(str++) - '0') * 10;
	time->m += *(str++) - '0';
	time->s = (*(str++) - '0') * 10;
	time->s += *(str) - '0';
}
