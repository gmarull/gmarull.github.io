/*  Meteotek08 - Sonda meteorològica dels tecnòlegs de l'IES Bisbal [ http://teslabs.com/meteotek08 ]
    Copyright (C) 2009  Tecnòlegs de l'IES Bisbal - <meteotek08[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <avr/io.h>
#include <avr/eeprom.h>
#include "mtk.h"
#include "mtkos.h"

/* Description: Will load default values to variable settings */
void mtk_load_defaults()
{

	/* Sensors */
	mtk.conf.sen.press_act = CONF_SENS_PRESS_ACT;
	mtk.conf.sen.t_ext_act = CONF_SENS_TEXT_ACT;
	mtk.conf.sen.t_int_act = CONF_SENS_TINT_ACT;

	/* Camera and servo */
	cam.power = FALSE;
	mtk.conf.cam.shot_interval = CONF_CAM_INTERVAL;
	mtk.conf.cam.servo_chg_down = CONF_CAM_SERVO_CHG_DOWN;
	mtk.conf.cam.servo_chg_mid = CONF_CAM_SERVO_CHG_MID;
	mtk.conf.cam.servo_chg_up = CONF_CAM_SERVO_CHG_UP;
	mtk.conf.cam.servo_act = CONF_CAM_SERVO_ACT;

	/* Flight */
	mtk.conf.flight.mode = CONF_FLIGHT_MODE;
	mtk.conf.flight.notif_interval = CONF_FLIGHT_NOTIF_INTERVAL;

	/* GPS */
	mtk.data.gps.valid = FALSE;
	mtk.conf.flight.bridged_gps = CONF_GPS_BRIDGED;

}

