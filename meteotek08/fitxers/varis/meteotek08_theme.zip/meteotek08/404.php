<?php get_header(); ?>

		<h2 class="center"><?php _e('Error 404 - Not Found', 'meteotek08'); ?></h2>

<?php get_footer(); ?>