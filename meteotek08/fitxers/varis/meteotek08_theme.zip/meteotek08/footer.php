</div>
	<div id="page-footer">
		<div id="footer-content">
			<hr align="center" style="width: 850px;"/>
			
			<a href="http://gplv3.fsf.org"><img src="<?php bloginfo('template_directory'); ?>/images/banners/gnugplv3.png" alt="El nostre programari es troba sota llic&egrave;ncia GPLv3"/></a>
			&nbsp;&nbsp;
			<a href="http://www.gnu.org/licenses/fdl.html"><img src="<?php bloginfo('template_directory'); ?>/images/banners/gnufdl.png" alt="El contingut d'aquesta p&agrave;gina es troba sota llic&egrave;ncia GFDL"/></a>
			&nbsp;&nbsp;
			<a href="http://www.getfirefox.com"><img alt="Firefox 2" src="<?php bloginfo('template_directory'); ?>/images/banners/firefox.gif"/></a>
			
			<p class="footer-text">
			Projecte realitzat pels membres del cr&egrave;dit de taller del 2n de batxillerat tecnol&ograve;gic de l'IES Bisbal.<br/>
			<a href="http://ieslabisbal.xtec.cat"><img src="<?php bloginfo('template_directory'); ?>/images/banners/iesbisbal.jpg" alt="P&agrave;gina web de l'IES Bisbal"/></a>
			 <br/>Curs 2007-08<br/>
			</p>
			<p class="footer-text">
			Si ets v&iacute;ctima del navegador Internet Explorer, si us plau, canvia't a <a href="http://getfirefox.com">Mozilla Firefox</a>.
			</p>
			
			<p>
				<a href="http://validator.w3.org/check?uri=referer">
					<img src="<?php bloginfo('template_directory'); ?>/images/banners/xhtml.jpg" alt="Valid XHTML 1.0 Transitional"/>
				</a>
        		&nbsp;&nbsp;&nbsp;
			 	<a href="http://jigsaw.w3.org/css-validator/">
			  		<img src="<?php bloginfo('template_directory'); ?>/images/banners/css.jpg" alt="Valid CSS!" />
			 	</a>
			</p>
			<div style="background-image: url('<?php bloginfo('template_directory'); ?>/images/page/bottom-bg.png'); height: 25px; width: 100%"></div>
		</div>
	</div>

</div>

<?php wp_footer(); ?>
<!-- Google Analytics -->
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-3555511-1");
pageTracker._initData();
pageTracker._trackPageview();
</script>
</body>
</html>