<div id="body-right-column">
	<div id="sidebar">
		
		<!-- MENU -->
		<div class="sidebar-box" id="menu">
			<div class="sidebar-item-hover"><img alt="" src="<?php bloginfo('template_directory'); ?>/images/icons/inici.png" style="margin-right: 5px;"/><a href="<?php bloginfo('siteurl'); ?>">Inici</a></div>
			<div class="sidebar-item-hover"><img alt="" src="<?php bloginfo('template_directory'); ?>/images/icons/fotos.png" style="margin-right: 5px;"/><a href="<?php bloginfo('siteurl'); ?>/fotografies">Fotografies</a></div>
			<div class="sidebar-item-hover"><img alt="" src="<?php bloginfo('template_directory'); ?>/images/icons/docs.png" style="margin-right: 5px;"/><a href="<?php bloginfo('siteurl'); ?>/documents">Documents</a></div>
			<div class="sidebar-item-hover"><img alt="" src="<?php bloginfo('template_directory'); ?>/images/icons/links.png" style="margin-right: 5px;"/><a href="<?php bloginfo('siteurl'); ?>/enllacos">Enlla&ccedil;os</a></div>
			<div class="sidebar-item-hover"><img alt="" src="<?php bloginfo('template_directory'); ?>/images/icons/membres.png" style="margin-right: 5px;"/><a href="<?php bloginfo('siteurl'); ?>/membres">Membres</a></div>
			
		<div class="sidebar-box-bot"></div>
		</div>
		
		<!-- ARCHIVES -->
		<div class="sidebar-box" id="arxius">
			<div class="sidebar-item"><img alt="" src="<?php bloginfo('template_directory'); ?>/images/icons/arxius.png" style="margin-right: 5px;"/><?php _e('Archives', 'meteotek08'); ?></div>
			<hr class="sidebar-line"/>
			<ul class="sidebar-list">
				<?php wp_get_archives('type=monthly'); ?>
			</ul>
		<div class="sidebar-box-bot"></div>
		</div>
		
		<!-- PHOTOS -->
		<div class="sidebar-box" id="fotografies">
			<div class="sidebar-item"><img alt="" src="<?php bloginfo('template_directory'); ?>/images/icons/fotos.png" style="margin-right: 5px;"/>Resum fotogr&agrave;fic</div>
			<hr class="sidebar-line"/>
			<!-- Start of Flickr Badge -->
			
			<table id="flickr_badge_uber_wrapper" align="center" cellpadding="0" cellspacing="10" border="0"><tr><td>
			
			<script type="text/javascript" src="http://www.flickr.com/badge_code_v2.gne?count=3&amp;display=latest&amp;size=t&amp;layout=v&amp;source=user&amp;user=23468143%40N08"></script>
	
			</td></tr></table>
			<!-- End of Flickr Badge -->
			
						
		<div class="sidebar-box-bot"></div>
		</div>
		
		<!-- LOGIN -->
		<p style="text-align: right;">
			<?php wp_register('',''); ?><br/>
			<?php wp_loginout(); ?>
		</p>
	</div>
</div>