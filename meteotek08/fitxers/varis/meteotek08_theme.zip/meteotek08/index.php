<?php get_header(); ?>

	<div id="body-left-column">

	<?php if (have_posts()) : ?>

		<?php while (have_posts()) : the_post(); ?>

			<div class="post" id="post-<?php the_ID(); ?>">
				<h2 class="post-title"><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php printf(__('Permanent Link to %s', 'meteotek08'), the_title_attribute('echo=0')); ?>"><?php the_title(); ?></a></h2>
				<small class="post-date"><?php the_time(__('F jS, Y', 'meteotek08')) ?></small>
				<div class="post-text">
					<?php the_content(__('Read the rest of this entry &raquo;', 'meteotek08')); ?>
				</div>
				<p class="post-info">
					<?php printf(__('Published in %s', 'meteotek08'), get_the_category_list(', ')); _e(' by ', 'meteotek08'); ?> <span class="author"><?php the_author() ?></span>
					| <?php edit_post_link(__('Edit', 'meteotek08'), '', ' | '); ?>
					<?php _e('Comments: ', 'meteotek08');?> <a href="<?php comments_link(); ?>"><?php comments_number('0','1', '%'); ?></a>
				</p>
			</div>

		<?php endwhile; ?>

		<div class="navigation">
			<div class="align-left"><?php next_posts_link(__('&laquo; Older Entries', 'meteotek08')) ?></div>
			<div class="align-right"><?php previous_posts_link(__('Newer Entries &raquo;', 'meteotek08')) ?></div>
		</div>

	<?php else : ?>

		<h2><?php _e('Not Found', 'meteotek08'); ?></h2>
		<p><?php _e('Sorry, but you are looking for something that isn&#8217;t here.', 'meteotek08'); ?></p>

	<?php endif; ?>

	</div>

<?php get_sidebar(); ?>

<?php get_footer(); ?>
