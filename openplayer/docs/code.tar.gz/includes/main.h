/*  openplayer firmware - openplayer, an open source portable music player
    Copyright (C) 2008  Gerard Marull Paretas - <gerardmarull[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/**************************************************************************
 * 
 * Main.c header file - Version 1.0 (Prototyping)
 * 
 * File type: Header
 * File name: main.h
 * 
 **************************************************************************/

#ifndef MAIN_H_
#define MAIN_H_

#include "sys/fat.h"

/***************************/
/***   General Values    ***/
/***************************/
#define KEYS_DELAY 16

/***************************/
/*** Function prototypes ***/
/***************************/
void spi_init(void);
uint8_t check_keys(void);
void die(char* message);
void hardware_init(void);
void software_init(void);
inline void change_task(void *newtask);
inline void set_current_language(void *languagep);
void device_sleep(void);
void continuous_tasks(void);
uint16_t device_get_batt_level(void);
void go_sleep(void);

#endif /*MAIN_H_*/


