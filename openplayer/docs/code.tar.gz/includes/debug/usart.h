/*  openplayer firmware - openplayer, an open source portable music player
    Copyright (C) 2008  Gerard Marull Paretas - <gerardmarull[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/**************************************************************************
 * 
 * Module to communicate via USART - Version 1.0
 * 
 * File type: Header
 * File name: usart.h
 * 
 **************************************************************************/

#ifndef USART_H_
#define USART_H_

/* UNCOMMENT THIS LINE IF YOU WANT TO ENABLE USART DEBUG! */
#define OP_DEBUG

/***********************/
/* Function prototypes */
/***********************/

void usart_init(uint16_t ubrr);
void usart_send(char data);
void usart_sendstring(char *data);
void usart_sendstring_P(char *data);
void usart_sendhex(uint8_t hexnumber);
void usart_sendbin(uint8_t binnumber);
void usart_senddec(uint32_t decnumber);

#endif /*USART_H_*/
