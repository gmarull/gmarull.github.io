/*  openplayer firmware - openplayer, an open source portable music player
    Copyright (C) 2008  Gerard Marull Paretas - <gerardmarull[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/**************************************************************************
 * 
 * Picture browser program - Version 1.0
 * 
 * File type: Header
 * File name: picbrowser.h
 * 
 **************************************************************************/

#ifndef PICBROWSER_H_
#define PICBROWSER_H_

#include "sys/fat.h"

/***************************/
/*** Function prototypes ***/
/***************************/
void picb_load(void);
void picb_handler(void);
void picb_exit(void);
void picb_load_bmp_centered(struct fat_fileentry *file);

#endif /*PICBROWSER_H_*/
