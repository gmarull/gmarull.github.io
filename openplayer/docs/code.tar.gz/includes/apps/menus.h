/*  openplayer firmware - openplayer, an open source portable music player
    Copyright (C) 2008  Gerard Marull Paretas - <gerardmarull[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/**************************************************************************
 * 
 * Interface menus module -> Version 1.0
 * 
 * File type: Header
 * File name: menus.h
 * 
 **************************************************************************/


#ifndef MENUS_H_
#define MENUS_H_


/*******************/
/* Data structures */
/*******************/
/* Menu entries, Size = 8bytes */
typedef struct{
	
	const uint8_t *icon;					// Menu entry icon
	uint8_t text;							// Menu entry text num
	void (*actionfunction)(void *flags);	// Pointer to function activated when clicking
	void *flags;							// Flags passed to function
			
}menu_entry;

/* Active menu information */
struct{
	const menu_entry *menu;
	uint8_t items;
	uint8_t selected;
	uint8_t reference;
}current_menu;


/*******************/
/* Available menus */
/*******************/
extern const menu_entry PROGMEM mainmenu[];
extern const menu_entry PROGMEM extrasmenu[];
extern const menu_entry PROGMEM settingsmenu[];
extern const menu_entry PROGMEM languagesmenu[];
extern const menu_entry PROGMEM skinsmenu[];
extern const menu_entry PROGMEM quitmenu[];


/***********************/
/* Function prototypes */
/***********************/
inline void menus_load_click(void *menu);
void menus_load(const menu_entry *menu, uint8_t selected);
void menus_move(int8_t movement);
void menus_refresh(void);
void menus_handler(void);


#endif /*MENUS_H_*/
