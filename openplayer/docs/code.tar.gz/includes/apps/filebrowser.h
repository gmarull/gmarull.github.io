/*  openplayer firmware - openplayer, an open source portable music player
    Copyright (C) 2008  Gerard Marull Paretas - <gerardmarull[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/**************************************************************************
 * 
 * File browser program - Version 1.0
 * 
 * File type: Header
 * File name: filebrowser.h
 * 
 **************************************************************************/

#ifndef FILEBROWSER_H_
#define FILEBROWSER_H_

/***************************/
/*** Function prototypes ***/
/***************************/
void filebrowser_init(const uint8_t *topicon, const uint8_t *fileicon, void (*fileaction)(void));
void filebrowser_handler(void);
void musicbrowser_load(void);
void musicbrowser_play(void);
void filebrowser_load(uint8_t selected);
void filebrowser_move(int8_t movement);
void filebrowser_refresh(void);
void filebrowser_exit(void);

/***********************/
/*** Data Structures ***/
/***********************/

struct {
	uint8_t folders;
	uint8_t items;
	uint8_t selected;
	uint8_t reference;
	uint8_t deeplevel;
	uint8_t attr_filter;
	struct file_formats formats;
	void (*fileaction)(void);
	const uint8_t *fileicon;
}filebrowser;

struct {
	char label[14];
	struct fat_fileentry fentry;
}browseritems[5];


#endif /*FILEBROWSER_H_*/
