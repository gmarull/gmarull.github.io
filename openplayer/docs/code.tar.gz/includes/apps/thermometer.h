/*  openplayer firmware - openplayer, an open source portable music player
    Copyright (C) 2008  Gerard Marull Paretas - <gerardmarull[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/**************************************************************************
 * 
 * Thermometer module, using DS18B20 - Version 1.0
 * 
 * File type: Header
 * File name: thermometer.h
 * 
 **************************************************************************/

#ifndef THERMOMETER_H_
#define THERMOMETER_H_

#include <stdbool.h>

/* Information of thermometer */
struct{
	uint8_t running;			//Running mode
	uint8_t currentres;			//Current resolution
	uint8_t currentunit;		//Current unit (C/F)
	uint8_t currentselector;	//Current selector (Units or resolution)
}thermometer;

/*********/
/* Utils */
/*********/
#define THERM_INPUT_MODE()		THERM_DDR&=~(1<<THERM_DQ)
#define THERM_OUTPUT_MODE()		THERM_DDR|=(1<<THERM_DQ)
#define THERM_LOW()				THERM_PORT&=~(1<<THERM_DQ)
#define THERM_HIGH()			THERM_PORT|=(1<<THERM_DQ)

//Available resolutions
#define THERM_RES_12BIT					3
#define THERM_RES_11BIT					2
#define THERM_RES_10BIT					1
#define THERM_RES_9BIT					0

//Available units
#define THERM_UNITS_F					1
#define THERM_UNITS_C					0

//Thermometer states
#define THERM_NOTRUNNING				0
#define THERM_RUNNING					1
#define THERM_NEEDTEMP					2

//Available selectors
#define THERM_CURSELECTOR_UNITS			0
#define THERM_CURSELECTOR_RES			1

/************/
/* Commands */
/************/
#define THERM_CMD_CONVERTTEMP	0x44
#define THERM_CMD_RSCRATCHPAD	0xbe
#define THERM_CMD_WSCRATCHPAD	0x4e
#define THERM_CMD_CPYSCRATCHPAD	0x48
#define THERM_CMD_RECEEPROM		0xb8
#define THERM_CMD_RPWRSUPPLY	0xb4
#define THERM_CMD_SEARCHROM		0xf0
#define THERM_CMD_READROM		0x33
#define THERM_CMD_MATCHROM		0x55
#define THERM_CMD_SKIPROM		0xcc
#define THERM_CMD_ALARMSEARCH	0xec

/***********************/
/* Function prototypes */
/***********************/
inline void therm_delay(uint16_t delay);
uint8_t therm_reset(void);
void therm_write_bit(uint8_t bit);
uint8_t therm_read_bit(void);
void therm_write_byte(uint8_t byte);
uint8_t therm_read_byte(void);
void therm_read_temperature(char *buffer, bool need_conversion);
void therm_change_resolution(uint8_t resolution);
void therm_load(void);
void therm_handler(void);

#endif /*THERMOMETER_H_*/
