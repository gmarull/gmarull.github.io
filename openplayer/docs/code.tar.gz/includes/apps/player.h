/*  openplayer firmware - openplayer, an open source portable music player
    Copyright (C) 2008  Gerard Marull Paretas - <gerardmarull[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/**************************************************************************
 * 
 * Music browser/player module - Version 1.0
 * 
 * File type: Header
 * File name: music.h
 * 
 **************************************************************************/

#ifndef MUSIC_H_
#define MUSIC_H_

#include "sys/fat.h"

/*****************************/
/*** Structs and variables ***/
/*****************************/

struct id3tags{
	char album[17];
	char trackname[17];
	char artist[17];
};

/* Current track information */
struct trackinfo{
	/* Decoding times */
	int16_t time_decoded;
	int16_t time_remaining;
	/* track information */
	uint16_t length;
	uint16_t bitrate;
	uint16_t frames;
	uint16_t samples_per_sec;
	uint16_t samples_per_frame;
	uint8_t mpeg;
	uint8_t layer;
	uint8_t channel;
	/* ID3 tags */
	struct id3tags id3;
};

/* Player global variables */
struct{
	uint8_t numoftracks;
	uint8_t currenttracknum;
	uint8_t trackposcount;
	uint8_t currentvol;
	uint8_t progbar_size;
	struct fat_fileentry currenttrack;
	struct trackinfo currenttrackinfo;
}player;




extern struct splayer layer;

/***************************/
/*** Function prototypes ***/
/***************************/

void player_load(void);
void player_play(void);
void player_handler(void);
void player_exit(void);
void player_send_audio(void);
void player_change_track(uint8_t track);
void player_get_track_info(struct fat_fileentry *file, struct trackinfo *trackinfo_p);
void player_update_screen_times(void);
void get_id3_tags(struct fat_fileentry *file,  uint8_t cpylength, char *trackname, char *artist, char *album);

#endif /*MUSIC_H_*/
