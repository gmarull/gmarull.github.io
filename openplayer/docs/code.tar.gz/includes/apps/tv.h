/*  openplayer firmware - openplayer, an open source portable music player
    Copyright (C) 2008  Gerard Marull Paretas - <gerardmarull[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/**************************************************************************
 * 
 * TV Remote module - Version 1.0
 * 
 * File type: Header
 * File name: tv.h
 * 
 **************************************************************************/

#ifndef TV_H_
#define TV_H_

/*********/
/* Utils */
/*********/
#define TV_LOW()	TV_DDR&=~(1<<TV_DATA)
#define TV_HIGH()	TV_DDR|=(1<<TV_DATA)

/***********************/
/* Available protocols */
/***********************/
#define TV_PROTOCOL_RC5				0

/****************/
/* RC5 Commands */
/****************/
#define TV_RC5_CMD_STANDBY			0x0c
#define TV_RC5_CMD_VOLPLUS			0x10
#define TV_RC5_CMD_VOLMIN			0x11
#define TV_RC5_CMD_PROGPLUS			0x20
#define TV_RC5_CMD_PROGMIN			0x21
#define TV_RC5_CMD_MUTE				0x0d

/*************************************/
/******** Function prototypes ********/
/*************************************/
void tv_load(void);
void tv_handler(void);
void tv_init_timer(void);
void tv_exit(void);
void tv_rc5_send_command(uint8_t command);

#endif /*TV_H_*/
