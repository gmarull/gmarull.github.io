/*  openplayer firmware - openplayer, an open source portable music player
    Copyright (C) 2008  Gerard Marull Paretas - <gerardmarull[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/**************************************************************************
 * 
 * Module to manage player interface - Version 1.0
 * 
 * File type: Header
 * File name: interface.h
 * 
 **************************************************************************/
#ifndef INTERFACE_H_
#define INTERFACE_H_

#include <avr/io.h>
#include <avr/pgmspace.h>
#include "sys/settings.h"
#include "sys/util.h"

/********/
/* Misc */
/********/
/* Transparency key for icons (Magenta) */
#define TRANSP_KEY		0xE3
/* Flags for intf_message function */
#define MSG_ERROR		0
#define MSG_WARNING		1
#define MSG_INFO		2


/**********************/
/* Language Utilities */
/**********************/
#define LANG const char PROGMEM

/* Macro to put language strings easily */
#define lang(a) (char*)pgm_read_word(openplayer.current_language+a)

//Only used in sprintf() function, which requires wchar_t (int) pointers
#define wlang(a) (int*)pgm_read_word(openplayer.current_language+a)


/***************************/
/*** Function prototypes ***/
/***************************/
void intf_load(void);
void intf_message(char *message, uint8_t msgtype);
void intf_refresh_header(void);
void intf_refresh_clock(void);
inline void intf_topicon_draw(const uint8_t *icon);
void intf_redraw_batt_level(void);
inline void intf_set_current_language(void *languagep);

/****************************/
/****   Icon access vars  ***/
/****************************/

extern const uint8_t PROGMEM icon_home[258];
extern const uint8_t PROGMEM icon_music[258];
extern const uint8_t PROGMEM icon_pictures[258];
extern const uint8_t PROGMEM icon_extras[258];
extern const uint8_t PROGMEM icon_settings[258];
extern const uint8_t PROGMEM icon_quit[258];
extern const uint8_t PROGMEM icon_warning[258];
extern const uint8_t PROGMEM icon_error[258];
extern const uint8_t PROGMEM icon_info[258];
extern const uint8_t PROGMEM icon_clock[258];
extern const uint8_t PROGMEM icon_games[258];
extern const uint8_t PROGMEM icon_thermometer[258];
extern const uint8_t PROGMEM icon_reboot[258];
extern const uint8_t PROGMEM icon_sleep[258];
extern const uint8_t PROGMEM icon_lang_en[178];
extern const uint8_t PROGMEM icon_lang_ca[146];
extern const uint8_t PROGMEM icon_folder[258];
extern const uint8_t PROGMEM icon_filemusic[258];
extern const uint8_t PROGMEM icon_computer[258];
extern const uint8_t PROGMEM icon_blackdot[38];
extern const uint8_t PROGMEM icon_tv[258];
extern const uint8_t PROGMEM icon_tv_waves[554];
extern const uint8_t PROGMEM icon_tv_off[258];
extern const uint8_t PROGMEM icon_tv_progmin[258];
extern const uint8_t PROGMEM icon_tv_progplus[258];
extern const uint8_t PROGMEM icon_tv_volmin[258];
extern const uint8_t PROGMEM icon_tv_volplus[258];
extern const uint8_t PROGMEM icon_tv_mute[258];
extern const uint8_t PROGMEM icon_languages[258];
extern const uint8_t PROGMEM icon_backlight[258];
extern const uint8_t PROGMEM icon_contrast[258];
extern const uint8_t PROGMEM icon_lock[258];
extern const uint8_t PROGMEM icon_fileskin[258];
extern const uint8_t PROGMEM icon_skins[258];
extern const uint8_t PROGMEM icon_skins_select[258];
extern const uint8_t PROGMEM icon_skins_add[258];
extern const uint8_t PROGMEM icon_batgreen[38];
extern const uint8_t PROGMEM icon_batyellow[38];
extern const uint8_t PROGMEM icon_batred[38];

extern const uint8_t PROGMEM splash_logo[2642];

/*****************/
/****   Fonts  ***/
/*****************/
extern const char PROGMEM flash_font[1372];

/****************************/
/*** Available languages  ***/
/****************************/
extern PGM_P PROGMEM lang_ca[];
extern PGM_P PROGMEM lang_en[];

#endif /*INTERFACE_H_*/
