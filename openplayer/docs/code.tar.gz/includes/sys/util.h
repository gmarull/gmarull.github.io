/*  openplayer firmware - openplayer, an open source portable music player
    Copyright (C) 2008  Gerard Marull Paretas - <gerardmarull[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/**************************************************************************
 * 
 * Module with util functions - Version 1.0
 * 
 * File type: Header
 * File name: util.h
 * 
 **************************************************************************/
 
#ifndef UTIL_H_
#define UTIL_H_

/*********/
/* UTILS */
/*********/

//Inline functions attribute abbreviation (just use "inline")
#define inline inline __attribute__((gnu_inline))

//Use it when you need to reset
#define device_reset()	asm volatile("jmp 0x00");

#define low(a)	(a&0xff)
#define high(a)	(a>>8)
#define lesser_of(a,b)	((a<=b)?a:b)

//Number of cycles that the delay loop takes (delay_us)
#define LOOP_CYCLES     				 8
/* Macro to convert uS to the equivalent loops for your clock (define F_CPU!) */
#define us(num) (num/(LOOP_CYCLES*(1/(F_CPU/1000000.0))))

/*************************************/
/******** Function prototypes ********/
/*************************************/

//MISC
inline void delay_us(uint16_t delay);
//MATHS-NUMBERING
uint8_t absolute(int8_t number);
uint32_t power(uint8_t a, int8_t b);
uint8_t countdigits(uint32_t value);
//STRINGS
uint8_t strcmpnocase(char *string1, char *string2, uint8_t num);
uint8_t strcmpcase(char *string1, char *string2, uint8_t num);
void strlcpy_u(char *destination, uint8_t *source, uint16_t length);
uint8_t strcmp_ign_length(char *string1, char *string2, uint8_t minlength);
void strncpy_unol(char *destination, char *source, uint16_t length);
void inttostr(uint32_t number, char *destination, uint8_t fixlength);

#endif /*UTIL_H_*/
