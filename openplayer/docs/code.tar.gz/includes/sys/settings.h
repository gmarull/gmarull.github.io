/*  openplayer firmware - openplayer, an open source portable music player
    Copyright (C) 2008  Gerard Marull Paretas - <gerardmarull[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/**************************************************************************
 * 
 * Settings module -> Version 1.0
 * 
 * File type: Source
 * File name: settings.c
 * 
 **************************************************************************/

#ifndef SETTINGS_H_
#define SETTINGS_H_

#include <avr/eeprom.h>
#include <avr/pgmspace.h>
#include <stdbool.h>
#include "sys/efs.h"
//All settings modules
#include "apps/sett/backlight.h"
#include "apps/sett/skins.h"

/*********/
/* Utils */
/*********/

#define sett_efs_first	&openplayer.current_skin_number
#define sett_efs_last	&openplayer.current_language+sizeof(openplayer.current_language)
#define sett_efs_length	((uint16_t)sett_efs_last-((uint16_t)sett_efs_first))

#define SETT_EFS_FILE_FORMAT	0x01

/**********************/
/* Settings structure */
/**********************/
struct{
	void (*currenttask)(void);
	struct efs_file config_file;
	bool locked;
	bool idle;
	uint16_t idle_time;
	uint16_t batt_level;
	uint32_t counter;
	struct{
		uint8_t hour;
		uint8_t minute;
		uint8_t second;
		uint32_t counter;
	}time;
	/***************************/
	/* Values stored in EEPROM */
	/***************************/
	uint8_t current_skin_number;
	uint8_t backlight;
	PGM_P* current_language;
	// Skin
	struct{
		//General
		uint8_t bg;
		uint8_t txt;
		//Header
		uint8_t header_bg;
		uint8_t header_txt;
		//Buttons
		uint8_t btn_bg;
		uint8_t btn_txt;
		uint8_t btn_active;
		uint8_t btn_dis;
		//Lists
		uint8_t ls_bg;
		uint8_t ls_txt;
		uint8_t ls_sel_bg;
		uint8_t ls_sel_txt;
		uint8_t ls_scroll_top;
		uint8_t ls_scroll_bg;
		//Progress bars
		uint8_t prog_bg;
		//Tabs/Windows
		uint8_t tab_bg;
		uint8_t tab_txt;
	}skin;
	
}openplayer;

/***********************/
/* Function prototypes */
/***********************/
void sett_init(void);
inline void sett_save_all(void);
inline void sett_save_value(void *address, uint8_t length);

#endif /*SETTINGS_H_*/
