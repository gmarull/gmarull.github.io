/*  openplayer firmware - openplayer, an open source portable music player
    Copyright (C) 2008  Gerard Marull Paretas - <gerardmarull[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/**************************************************************************
 * 
 * LCD driver module - Version 1.0
 * 
 * File type: Header
 * File name: lcd.h
 * 
 **************************************************************************/

#ifndef LCD_H_
#define LCD_H_

#include <stdbool.h>
#include "sys/fat.h"

/*******************/
/* Data structures */
/*******************/
struct{
	bool busy;
}lcd;

/***************************/
/***        Utils        ***/
/***************************/
#define act_lcd()	LCD_PORT &= ~(1<<LCD_CS);
#define dis_lcd()	LCD_PORT |= (1<<LCD_CS);
#define spi_on()	SPCR |= (1<<SPE);
#define spi_off()	SPCR &= ~(1<<SPE);

//Macro to transform RGB color to 8bit LCD colors
#define RGB8BIT(a,b,c) ((uint8_t)(a&0xe0) | (uint8_t)((b&0xe0)>>3) | (uint8_t)((c&0xc0)>>6))

/***************************/
/***    General values   ***/
/***************************/
//Font size
#define FONT_WIDTH			8
#define FONT_HEIGHT			14

//Flags for lcd_puttext function (bitmap)
#define TEXT_DOTS  			0
#define TEXT_MLINE 			1
#define TEXT_TRANSP			2
#define TEXT_SOURCE			3

//Bitmap formats (color bits)
#define BITMAP_2COLORS	 	1
#define BITMAP_256COLORS	8
#define BITMAP_16MCOLORS	24

//Contrast
#define LCD_DEFAULT_CONTRAST	50

/***************************/
/***     LCD COMMANDS    ***/
/***************************/

#define LCD_NOP 		0x00	//NOP, command with no effect
#define LCD_SWRESET 	0x01	//Software reset
#define LCD_BSTRON		0x03	//Booster on
#define LCD_SLPOUT		0x11	//Sleep-out
#define LCD_NORON		0x13	//Normal mode on
#define LCD_DISPON		0x29	//Display on
#define LCD_CASET		0x2a	//Set column address (x-start and x-end)
#define LCD_RASET		0x2b	//Set row address (y-start and y-end)
#define LCD_RAMWR		0x2c	//Ram write
#define LCD_RGBSET		0x2d	//Color look up table for 8bit mode
#define LCD_MADCTR		0x36	//Memory Data Access Control
#define LCD_COLMOD		0x3a	//Color mode
#define LCD_WRCNTR		0x25	//Write contrast
#define LCD_SLPIN		0x95	//Enter sleep mode
#define LCD_DISPOFF		0xae	//Turn display off

//LCD_COLMOD Command parameters
#define LCD_COLMOD_DEFAULT LCD_COLMOD_8BIT
#define LCD_COLMOD_8BIT		0x02
#define LCD_COLMOD_12BIT	0x03
#define LCD_COLMOD_16BIT	0x05


/***************************/
/*** Function prototypes ***/
/***************************/

uint8_t lcd_sendbyte(uint8_t byte);
void lcd_init(void);
void lcd_send_cmd(uint8_t command);
void lcd_send_data(uint8_t data);
void lcd_set_window(uint8_t xs, uint8_t xe, uint8_t ys, uint8_t ye);
void lcd_put_char(char character, uint8_t x0, uint8_t y0, uint8_t textcolor, uint8_t bgcolor, uint8_t params);
void lcd_put_string(char *text, uint8_t x0, uint8_t y0, uint8_t textcolor, uint8_t bgcolor, uint8_t params);
void lcd_clear(uint8_t bgcolor);
void lcd_draw_rectangle(uint8_t x_origin, uint8_t y_origin, uint8_t width, uint8_t height, uint8_t bgcolor);
void lcd_set_pixel(uint8_t x, uint8_t y, uint8_t color);
void lcd_loadbitmap(struct fat_fileentry *bmpfile, int offsetx, int offsety);
void lcd_drawicon(const uint8_t *iconarray, uint8_t offsetx, uint8_t offsety, bool transp);
void lcd_adjust_backlight(uint8_t level);
void lcd_sleep(void);

#endif /*LCD_H_*/
