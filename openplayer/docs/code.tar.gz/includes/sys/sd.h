/*  openplayer firmware - openplayer, an open source portable music player
    Copyright (C) 2008  Gerard Marull Paretas - <gerardmarull[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/**************************************************************************
 * 
 * Module for managing SecureDigital Cards - Version 1.0
 * 
 * File type: Header
 * File name: sd.h
 * 
 **************************************************************************/
 
#ifndef SD_H_
#define SD_H_

/* Utils */
#define SD_DESELECT()		SD_PORT |= (1<<SD_CS)
#define SD_SELECT()			SD_PORT &= ~(1<<SD_CS)
#define SD_SEND_8_CLOCKS()	sd_send_byte(0xff)

/* SD module global variables & defines */
struct{
	uint8_t version;
	uint8_t addressing_mode;
	uint32_t capacity;
	uint8_t command_crc;
}sd;

#define SD_SECTOR_SIZE			512
#define SD_VERSION_1			0
#define SD_VERSION_2			1
#define SD_BYTE_ADDRESSING		0
#define SD_BLOCK_ADDRESSING		1


/***************************/
/*** Function prototypes ***/
/***************************/

uint8_t sd_send_byte(uint8_t byte);
void sd_send_command(uint8_t command, uint32_t arg);
uint8_t sd_init(void);
uint8_t sd_get_response(uint8_t response, uint16_t timeout);
uint8_t sd_read(uint32_t sector, uint16_t firstbyte, uint16_t lastbyte, uint8_t *buffer);
uint8_t sd_write(uint32_t sector, uint8_t *buffer);
//uint8_t sd_getsizeinfo(sd_size_info *sinfo);


/* ******************************************************************************
 * ***************************** SD Command set *********************************
 * ******************************************************************************
 * 
 * This information can be found on:
 * SD Specifications Part 1 Physical Layer Simplified Specification Version 2.00
 * 
 ********************************************************************************/

#define SD_CMD_GO_IDLE_STATE			    (0x40+0)	
#define SD_CMD_SEND_OP_COND			    	(0x40+1)
#define SD_CMD_SEND_IF_COND					(0x40+8)
#define SD_CMD_SEND_CSD				    	(0x40+9)	
#define SD_CMD_SEND_CID				    	(0x40+10)
#define SD_CMD_STOP_MULTI_TRANS            	(0x40+12)
#define SD_CMD_SEND_STATUS				    (0x40+13)
#define SD_CMD_SET_BLOCKLEN			    	(0x40+16)
#define SD_CMD_READ_SINGLE_BLOCK			(0x40+17)
#define SD_CMD_READ_MULTI_BLOCK            	(0x40+18)
#define SD_CMD_WRITE_BLOCK				    (0x40+24)
#define SD_CMD_WRITE_MULTI_BLOCK           	(0x40+25)
#define SD_CMD_PROGRAM_CSD				    (0x40+27)
#define SD_CMD_SET_WRITE_PROT			    (0x40+28)
#define SD_CMD_CLR_WRITE_PROT			    (0x40+29)
#define SD_CMD_SEND_WRITE_PROT			    (0x40+30)
#define SD_CMD_ERASE_WR_BLK_START			(0x40+32)
#define SD_CMD_ERASE_WR_BLK_END             (0x40+33)
#define SD_CMD_ERASE						(0x40+38)
#define SD_CMD_LOCK_UNLOCK					(0x40+42)
#define SD_CMD_APP_CMD						(0x40+55)
#define SD_CMD_GEN_CMD						(0x40+56)
#define SD_CMD_READ_OCR                    	(0x40+58)
#define SD_CMD_CRC_ON_OFF				    (0x40+59)

/* Application specific commands */
#define SD_ACMD_SD_STATUS					(0x40+13)
#define SD_ACMD_SEND_NUM_WR_BLOCKS			(0x40+22)
#define SD_ACMD_SET_WR_BLK_ERASE_COUNT		(0x40+23)
#define SD_ACMD_SD_SEND_OP_COND				(0x40+41)
#define SD_ACMD_SET_CLR_CARD_DETECT			(0x40+42)
#define SD_ACMD_SEND_SCR					(0x40+51)


/* R1 Responses */
#define SD_R1_BUSY				    	(1<<7)
#define SD_R1_PARAMETER					(1<<6)
#define SD_R1_ADDRESS					(1<<5)
#define SD_R1_ERASE_SEQ					(1<<4)
#define SD_R1_COM_CRC					(1<<3)
#define SD_R1_ILLEGAL_COM		    	(1<<2)
#define SD_R1_ERASE_RESET		    	(1<<1)
#define SD_R1_IDLE_STATE				(1<<0)
#define SD_R1_SUCCESS					0

/* R7 Responses */
#define SD_R7_OP_VOLTAGE					0x01
#define SD_R7_PATTERN						0xaa

#endif /*SD_H_*/
