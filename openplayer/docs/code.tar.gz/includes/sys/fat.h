/*  openplayer firmware - openplayer, an open source portable music player
    Copyright (C) 2008  Gerard Marull Paretas - <gerardmarull[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/**************************************************************************
 * 
 * Module for managing FAT16 & FAT32 partitions - Version 1.0
 * 
 * File type: Header
 * File name: fat.h
 * 
 **************************************************************************/
 
#ifndef FAT_H_
#define FAT_H_

extern uint8_t global_buffer[512];
extern struct fat_fileentry fileinfo;

#define TYPEFOLDER 0
#define TYPEFILE 1

/* File attributes */
#define ATTR_READONLY (1<<0)
#define ATTR_HIDDEN   (1<<1)
#define ATTR_SYS      (1<<2)
#define ATTR_VOLUME   (1<<3)
#define ATTR_DIR	  (1<<4)
#define ATTR_CACHE    (1<<5)

/* Options for fat_get_file_info function (Bitmap) */
#define FAT_GET_MODE			(1<<7)
#define FAT_SAVE_FILE_NAME		(1<<6)
//Values for FAT_GET_MODE
#define FAT_GET_BY_NAME			0x80
#define FAT_GET_BY_ENTRY_NUM	0


/* Partition information entry */
struct {
    uint8_t format;                 // Format of the partition (Fat16 or Fat32)
    uint16_t firstsector;           // First sector of the partition
    uint8_t secsperclus;            // Mumber of sectors per cluster
    uint16_t reservedsecs;			// Number of reserved sectors
    uint32_t currentfolder;		  	// Current working folder (cluster)
    uint16_t firstdatasector;       // Sector where data starts
	uint16_t fat_root;	      		// In FAT16 it will be a sector, but a cluster for FAT32
}partition;

/* Structure to store file information */
struct fat_fileentry{
	uint32_t currentcluster;	 // Current File cluster
	uint32_t size;           	 // File size in bytes
    uint32_t pointer;            // Actual location in file
    uint32_t firstcluster;       // First cluster of file
    uint8_t type;                // Type of file (folder OR file)
};

//File accessing structures
struct file_format{
	char format[4];
	struct file_format *next;
};

struct file_formats{
	struct file_format *first;	//First element of formats list
	struct file_format *last;	//Last element of formats list
};


/*************************************************/
/**************** Function Prototypes ************/
/*************************************************/
uint32_t fat_get_next_cluster(uint32_t cluster);
uint32_t fat_cluster_to_sector(uint32_t cluster);
uint8_t fat_init(void);
uint8_t fat_get_file_info(int16_t entrynumber, char *filename, struct file_formats *formats, uint8_t filter, struct fat_fileentry *file, uint8_t params);
uint16_t fat_count_files(struct file_formats *formats, uint8_t filter);
uint16_t fat_read_file(struct fat_fileentry *file, uint8_t *buffer, uint16_t length);
void fat_seek(struct fat_fileentry *file, uint32_t point);
uint8_t fat_cd_dir(char *name);
void fat_formats_add(struct file_formats *formatsp, char *format);
void fat_formats_delete(struct file_formats *formatsp, char *format);
void fat_formats_clear(struct file_formats *formatsp);

#endif /*FAT_H_*/
