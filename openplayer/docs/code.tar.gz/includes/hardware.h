/*  openplayer firmware - openplayer, an open source portable music player
    Copyright (C) 2008  Gerard Marull Paretas - <gerardmarull[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/**************************************************************************
 * 
 * Hardware pin connections - Version 1.0
 * 
 * File type: Header
 * File name: hardware.h
 * 
 **************************************************************************/

#ifndef HARDWARE_H_
#define HARDWARE_H_

/* Battery levels (V) */
#define BATT_GREEN		(3.8*1024)/4.15
#define BATT_YELLOW		(3.5*1024)/4.15
#define BATT_RED		(3.3*1024)/4.15
#define BATT_OFF		(3.0*1024)/4.15

/* CPU Clock speed (Hz) */
#define F_CPU 8000000

/**************************/
/*     SPI Connections    */
/**************************/
#define SPI_PORT	   	PORTB
#define SPI_DDR		  	DDRB
#define SPI_PIN 	   	PINB
#define SPI_MISO	    PB3
#define SPI_MOSI	   	PB2
#define SPI_SCK		  	PB1
#define SPI_SS		  	PB0

/**************************/
/*   Decoder Connections  */
/**************************/
#define DEC_PORT   		PORTA
#define DEC_DDR    		DDRA
#define DEC_PIN    		PINA
#define DEC_DREQ   		PA7
#define DEC_XRESET 		PA6
#define DEC_XDCS   		PA5
#define DEC_XCS    		PA4

/***************************/
/*   SD Card Connections   */
/***************************/
#define SD_PORT      	PORTG
#define SD_DDR       	DDRG
#define SD_PIN      	PING
#define SD_CS			PG5

/***************************/
/*     LCD Connections     */
/***************************/
#define LCD_PORT		PORTE
#define LCD_DDR			DDRE
#define	LCD_PIN			PINE
#define	LCD_CS			PE4
#define LCD_RESET		PE5
//Backlight
#define LCD_BACKLIGHT_PORT	PORTE
#define LCD_BACKLIGHT_DDR	DDRE
#define LCD_BACKLIGHT_PIN	PINE
#define LCD_BACKLIGHT_SHDN	PE2
#define LCD_BACKLIGHT_RSET	PE3

/***************************/
/* Thermometer Connections */
/***************************/
#define THERM_PORT		PORTC
#define THERM_DDR		DDRC
#define THERM_PIN		PINC
#define THERM_DQ		PC7

/***************************/
/*  TV Remote Connections  */
/***************************/
#define TV_PORT			PORTB
#define TV_DDR			DDRB
#define TV_PIN			PINB
#define TV_DATA			PB5

/***************************/
/*     KEYS Connections    */
/***************************/
#define KEYS_PORT		PORTC
#define KEYS_DDR		DDRC
#define KEYS_PIN		PINC

#define KEYS_ALL 		((1<<KEYS_UP) | (1<<KEYS_DOWN) | (1<<KEYS_LEFT) | (1<<KEYS_RIGHT) | (1<<KEYS_CENTER))
#define KEYS_UP			PC4
#define KEYS_DOWN		PC0
#define KEYS_LEFT		PC2
#define KEYS_RIGHT		PC3
#define KEYS_CENTER		PC1

//Lock key
#define LOCK_PORT		PORTB
#define LOCK_DDR		DDRB
#define LOCK_PIN		PINB

#define LOCK_KEY		PB7

/**************************/
/*        Battery         */
/**************************/
#define BATTC_PORT		PORTD
#define BATTC_DDR		DDRD
#define BATTC_PIN		PIND
#define BATTC_CHG		PD0


#endif /*HARDWARE_H_*/
