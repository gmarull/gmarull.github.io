/*  openplayer firmware - openplayer, an open source portable music player
    Copyright (C) 2008  Gerard Marull Paretas - <gerardmarull[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/**************************************************************************
 * 
 * Main player file - Version 1.0
 * 
 * File type: Source
 * File name: main.c
 * 
 **************************************************************************/

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <avr/sleep.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "hardware.h"
#include <util/delay.h>
#include "main.h"
#include "sys/sd.h"
#include "sys/fat.h"
#include "sys/util.h"
#include "sys/decoder.h"
#include "sys/lcd.h"
#include "sys/interface.h"
#include "sys/settings.h"
#include "sys/efs.h"
#include "debug/usart.h"
#include "apps/menus.h"
#include "apps/thermometer.h"


uint8_t keytime;
uint8_t global_buffer[512];

/* MAIN! */
int main(void){
	

	/* First check battery level, if critical do not init */
	device_get_batt_level();
	if(device_get_batt_level()<=BATT_OFF){
		device_sleep();
	}
	
	/* Initialize EEPROM File System & restore settings */
	efs_init();
	sett_init();

	hardware_init();
	software_init();
	
	/* Main Loop */
	while(1){

		if(openplayer.currenttask) openplayer.currenttask();
		continuous_tasks();
	
	}	
	
	return 1;
	
}

/* 
 * - Description: Tasks that are executed on every main loop. DO NOT OVERLOAD THE TASK LIST!
 */
void continuous_tasks(){
	
	uint16_t i=0;
	static uint32_t counter=0;
	
	/* Check Lock Key and update screen if necessary */
	if(PCIFR&(1<<PCIF0)){
		//Openplayer has been locked
		if(LOCK_PIN&(1<<LOCK_KEY)){
			lcd_drawicon(icon_lock, 20, 1, true);
			openplayer.locked=true;
		//Openplayer has been unlocked
		}else{
			lcd_draw_rectangle( 20, 1, 16, 16, openplayer.skin.header_bg);
			openplayer.locked=false;
		}
		//Clear interrupt flag
		PCIFR|=(1<<PCIF0);
	}
	
	/* Monitor battery status, check each minute */
	if((openplayer.counter-counter)>60000){
		counter=openplayer.counter;
		i=device_get_batt_level();
		// First, check for critical battery level
		if(i<=BATT_OFF){
			openplayer.batt_level=i;
			/* Show message and wait until user locks openplayer */
			lcd_clear(0xff);
			intf_message(lang(32), MSG_WARNING);
			while(!(LOCK_PIN&(1<<LOCK_KEY)));
			/* Sleep */
			device_sleep();
			// Wake-up 
			hardware_init();
			software_init();
		// If voltage measured has changed, just update the screen 
		}else if(i!=openplayer.batt_level){
			openplayer.batt_level=i;
			intf_redraw_batt_level();
		}
	}
	
	/* Auto-off for lcd light */
	if(((~KEYS_PIN)&0x1f)){
		if(openplayer.idle==true){
			//TODO -> Why not storing lcd level directly :S?
			lcd_adjust_backlight(LCD_BACKLIGHT_MIN+openplayer.backlight*((255-LCD_BACKLIGHT_MIN)/8));
			openplayer.idle_time=0;
			openplayer.idle=false;
		}
	}else{
		if(openplayer.idle_time > 20000){
			openplayer.idle=true;
			lcd_adjust_backlight(0);
		}
	}

}

/* - Description: Initializes software units and shows the main menu
 * - Flags: 	None
 */
void software_init(){
	

	/* Initialize partition and switch to working dir */
	if(fat_init()) die(lang(2));
	if(fat_cd_dir("OPENPLAYER")) die(lang(3));
	/* Initialize interface */
	intf_refresh_header();
	menus_load(mainmenu, 0);
	
}

/* - Description: Initializes hardware units (timers, sd, decoder...)
 * - Flags: 	None
 */
void hardware_init(){
	
	/* Keyboard */
	KEYS_DDR &= ~KEYS_ALL; //All keys as inputs
	KEYS_PORT |= KEYS_ALL; //All keys with pull-up
	
	/* Internal units */
	//Initialize 8-bit Timer0
	TIMSK0 = (1<<TOIE0);
	TIFR0 = (1<<TOV0);
	TCNT0 = 0;
	TCCR0B = 0x5; //Enable prescaler (1024)
	/* Configure Timer2 (RTC source) */
	//CTC mode
	TCCR2A|=(1<<WGM21);
	//F_CPU/32 prescaler
	TCCR2B|=(0<<CS22)|(1<<CS21)|(1<<CS20);
	//Compare match
	OCR2A=250;
	//Enable OCR2A match interrupt
	TIMSK2|=(1<<OCIE2A);
	TIFR2|=(1<<OCF2A);
	
	//Initialize Lock key
	LOCK_DDR&=~(1<<LOCK_KEY);
	LOCK_PORT&=~(1<<LOCK_KEY);
	PCICR&=~(1<<PCIE0);
	PCIFR|=(1<<PCIF0);
	PCMSK0|=(1<<PCINT7);
	
	//Initialize battery charging pin
	BATTC_DDR&=~(1<<BATTC_CHG);
	BATTC_PORT|=(1<<BATTC_CHG);
	
	sei();
	//Initialize Serial Peripheral Interface
	spi_init();
	
	/* External units */
	/* Initialize LCD & display splash screen! */
	lcd_init();
	lcd_clear(0x00);
	lcd_drawicon(splash_logo, 6, 55, false);
	
	//Initialize decoder
	if(dec_init()) die(lang(0));
	
	//Initialize SD Card
	if(sd_init()) die(lang(1));
	
	//Check voltage (first time after initialization is always incorrect)
	device_get_batt_level();
	openplayer.batt_level=device_get_batt_level();
	

}

/* - Description: Changes the current task
 * - Flags: 	*newtask -> Pointer to the new task
 */
inline void change_task(void *newtask){
	
	openplayer.currenttask=newtask;
	
}


/* - Description: Handles thermometer application if it is being executed
				  Using timers makes possible to use keys at the same time.
 */
ISR(TIMER0_OVF_vect){
	
		char therm_buffer[13];

		/* If we are running thermometer... */
		if(thermometer.running==THERM_RUNNING){
			
			//Ask for a new conversion
			therm_reset();
			therm_write_byte(THERM_CMD_SKIPROM);
			therm_write_byte(THERM_CMD_CONVERTTEMP);
			
			//Set need temperature mode
			thermometer.running=THERM_NEEDTEMP;
			
		}else if(thermometer.running==THERM_NEEDTEMP){
			
			//Check if conversion has finished
			if(therm_read_bit()){
				therm_read_temperature(therm_buffer, false);
				lcd_put_string(therm_buffer, (131-strlen(therm_buffer)*FONT_WIDTH)/2, 68, 0x00,0xff, (1<<TEXT_SOURCE));
				thermometer.running=THERM_RUNNING;
			}
			
		}
		
}

/* - Description: Checks which keys are pressed. Handles time intervals for key pressing
 * - Flags: 	None
 */
uint8_t check_keys(){
	
	uint8_t tempkeys=0;
	static uint32_t counter;
	static uint8_t keyspressed=0;
	
	if(openplayer.locked==true) return 0;
	
	/* Check if some keys were pressed in the last read operation */
	if(keyspressed){
		if((KEYS_PIN&0x1f)==0x1f){
			//Not pressing right now
			if((openplayer.counter-counter)>300){
				counter=openplayer.counter;
				tempkeys = keyspressed;
			}
			keyspressed=0;
		}else{
			//Still pressed
			if((openplayer.counter-counter)>225){
				counter=openplayer.counter;
				tempkeys = keyspressed;
				keyspressed=0;
			}
		}
	/* Read keys input pins */
	}else{
		keyspressed=(~KEYS_PIN)&0x1f;
	}
	
	return tempkeys;
		
}

/* - Description: Initializes SPI
 * - Flags: 	None
 */
void spi_init(){
	
	//MOSI, Clock, CS and SS as outputs
	SPI_DDR |= (1<<SPI_MOSI) | (1<<SPI_SCK) | (1<<SPI_SS);
	SPCR = (1<<SPE) | (1<<MSTR); //Enable SPI, Master mode
	//Max speed for SPI
	SPCR &= ~((1<<SPR0) | (1<<SPR1));
	SPSR |= (1<<SPI2X);
		
}


/* - Description: Stops openplayer displaying a message on the screen. If any
 * 				  key is pressed, openplayer is restarted.
 * - Flags: 	None
 */
void die(char* message){
	
	lcd_clear(0xff);
	intf_message(message, MSG_ERROR);

	while(1){
		if(check_keys())
			device_reset();
	}
	
}

/* - Description: Puts the device into sleep mode
 * - Flags: 	None
 */
void device_sleep(){
	
	goto sleep;

sleep:
	/* Stop peripherals & units */
	lcd_sleep();
	dec_standby();
	
	/* Enable Interrupts (with interrupt vector enabled!) */
	PCICR|=(1<<PCIE0);
	PCIFR|=(1<<PCIF0);
	PCMSK0|=(1<<PCINT7);
	sei();
	
	/* Disable ADC */
	ADCSRA&=~(1<<ADEN);
	
	/* Enter sleep mode */
	set_sleep_mode(SLEEP_MODE_PWR_DOWN);
	sleep_mode();
	
	goto check_conditions;
	
check_conditions:
	/* It will wake-up only if voltage is OK and lock key is unlocked */
	device_get_batt_level();
	if((device_get_batt_level()<=BATT_OFF) || (LOCK_PIN&(1<<LOCK_KEY))){
		goto sleep;
	}

}


/* - Description: Asks to lock openplayer and then sleeps it
 * - Flags: 	None
 */
void go_sleep(){
	
	lcd_draw_rectangle(0,18,132,114,openplayer.skin.ls_bg); //Clear
	intf_message(lang(31),MSG_INFO);
	
	while(!(LOCK_PIN&(1<<LOCK_KEY))){
		if(check_keys()){
			menus_load(current_menu.menu, current_menu.selected);
			return;
		}
	}
	
	device_sleep();
	
	/* Wake up */
	hardware_init();
	software_init();
	
}

/* - Description: Gets battery level from ADC
 * - Flags: 	None
 */
uint16_t device_get_batt_level(){
	
	uint8_t i=0;

	/* Start the new conversion */	
	//Wait to end a current conversion
	while(ADCSRA&(1<<ADSC)){
		if(i++>100) return openplayer.batt_level;
	}
	
	//Setup ADC [Internal ref (2.56V), channel 0]
	ADMUX|=(1<<REFS0)|(1<<REFS1);
	
	//Start conversion & wait until it ends
	ADCSRA|=(1<<ADEN)|(1<<ADSC);
	while(ADCSRA&(1<<ADSC));
	
	return ADCW;
	
}

/* 
 * - Description: nop for wake-up pin interrupt
 */
ISR(PCINT0_vect){
	asm volatile("nop");
}

/* 
 * - Description: Clock counter
 */
ISR(TIMER2_COMPA_vect){
	

	/* Increase counter (milliseconds counter) */
	openplayer.counter++;
	if(openplayer.idle==false){
		openplayer.idle_time++;
	}
	
	/* Update clock values */
	if((openplayer.counter-openplayer.time.counter)==1000){
		openplayer.time.counter=openplayer.counter;
		openplayer.time.second++;
		
		if(openplayer.time.second==60){
			openplayer.time.second=0;
			openplayer.time.minute++;
			
			if(openplayer.time.minute==60){
				openplayer.time.minute=0;
				openplayer.time.hour++;
				if(openplayer.time.hour==24){
					openplayer.time.hour=0;
				}
			}
			
		}
	}
}
