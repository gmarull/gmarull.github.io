/*  openplayer firmware - openplayer, an open source portable music player
    Copyright (C) 2008  Gerard Marull Paretas - <gerardmarull[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/**************************************************************************
 * 
 * Module for managing FAT16 & FAT32 partitions - Version 1.0
 * 
 * File type: Source
 * File name: fat.c
 * 
 **************************************************************************/

#include <avr/io.h>
#include <stdlib.h>
#include <string.h>
#include "sys/fat.h"
#include "sys/sd.h"
#include "sys/util.h"

//General purpose file entry (use where you want)
struct fat_fileentry fileinfo;

/* - Description: Gets the next cluster of the chain
 * - Flags: 	cluster		-> Current cluster
 * Developer notes: TODO-> Could save cluster table to avoid reading the entire SD when getting next cluster if it's near the last one
 */
uint32_t fat_get_next_cluster(uint32_t cluster){
    
    uint32_t offset, nextcluster, mask;
    uint8_t clustbuffer[4];
    
    if(partition.format == 0x06){
    	//Fat16 table entries = word
    	offset = cluster << 1;	
    	mask=0x0000ffff;
    }else{
    	//Fat32 table entries = dword
    	offset = cluster << 2;
    	mask=0x0fffffff;
    }
    
    sd_read(partition.firstsector + partition.reservedsecs + (offset/SD_SECTOR_SIZE), offset%SD_SECTOR_SIZE, (offset%SD_SECTOR_SIZE) + 4, clustbuffer);
	
    nextcluster=*(uint32_t*)&clustbuffer[0]&mask;
    
    if((nextcluster == 0xffff) | (nextcluster == 0xffffffff)) return 0; //End of chain
   
    return nextcluster;
    
}


/* - Description: Transforms a cluster into its corresponding sector
 * - Flags: 	cluster		-> Cluster to be transformed
 */
uint32_t fat_cluster_to_sector(uint32_t cluster){
	
	if(cluster==0) return partition.fat_root; //Only for FAT16
	return ((cluster-2)*partition.secsperclus+partition.firstdatasector);		
}

/* - Description: Initializes FAT File System
 * - Flags: None
 */
uint8_t fat_init(){

    uint32_t secsperfat;
    uint16_t maxfilesinroot;
    
    //Loads to buffer first unit sector
    sd_read(0, 446, 462, global_buffer);
    
    //Must exist MBR, sector 0 as partition root will not be supported.
    //Check if we have fat16 or fat32
    if(global_buffer[0x04] != 0x06 && global_buffer[0x04] != 0x0b && global_buffer[0x04] != 0x0c)
    	return 1; //Partition format is not supported
    
    //MBR Values
    partition.format = global_buffer[0x4];
    partition.firstsector = *(uint32_t*)&global_buffer[0x08];

	//Fat Table Common values   
	sd_read(partition.firstsector, 0, 90, global_buffer);
	partition.secsperclus = global_buffer[0x0d];
	partition.reservedsecs=*(uint16_t*)&global_buffer[0x0e];
	
	//Fat Table Format specific values
	if(partition.format == 0x06){
		//Fat16
		secsperfat=*(uint16_t*)&global_buffer[0x16];
		maxfilesinroot = *(uint16_t*)&global_buffer[0x11];
		partition.fat_root = (partition.firstsector+partition.reservedsecs+secsperfat*global_buffer[0x10]);
		partition.firstdatasector = partition.fat_root + ((maxfilesinroot * 32)/SD_SECTOR_SIZE);
		partition.currentfolder = 0; //FAT16 first cluster (Root directory)
	}else{
		//Fat32
		secsperfat=*(uint32_t*)&global_buffer[0x24];
		partition.firstdatasector = (partition.firstsector+partition.reservedsecs+secsperfat*global_buffer[0x10]);
		partition.fat_root = global_buffer[0x2c];	
		partition.currentfolder = global_buffer[0x2c]; //FAT32 first cluster
	}
    
    return 0;
}

/* - Description: Gets the number of entries in the current folder.
 * - Flags: 	*formats 	-> List of formats that you want to count
 * 				*filter		-> FAT attributes that you want to count (see fat.h)
 */
uint16_t fat_count_files(struct file_formats *formats, uint8_t filter){
		
		struct file_format *p;		
		uint8_t *bufferp=NULL;
		uint8_t sectorentry=16,sectorcount=0;
		uint16_t result=0;
		uint32_t sector, cluster;
		
		cluster=partition.currentfolder;
		sector=fat_cluster_to_sector(cluster);
		
		while(1){
			//Check if we have lasted the actual sector
			if(sectorentry >= 16){
				if(++sectorcount >= partition.secsperclus){
					//We have to get the next cluster
					cluster = fat_get_next_cluster(cluster);
					if(cluster==0) break; //End of folder
					sectorcount=0;
					sector=fat_cluster_to_sector(cluster);
				}
				
				sd_read(sector++ , 0, 512, global_buffer);
				bufferp=global_buffer;
				sectorentry=0;
			}
			
			//Check for files
			if(*bufferp==0) break; //No more files in the current directory.
			
			if((*bufferp != 0xe5) && ((*(bufferp+11) & 0xf) == 0)){
					//SFN entry found
					if(!formats->first && !filter){
						//If there are no formats and no filter everything is counted
						result++;
					}else if((*(bufferp+11) & filter)){
						//If filter parameters match with the current file, count it
						result++;
					}else{
						//Check if the current file has one of the given formats
						p=formats->first;
						while(p){
							if(strncmp(p->format,(char*)(bufferp+8),3)==0){
								result++;
								break;
							}
							p=p->next;
						}				
 					}		
			}
			
			bufferp+=32;
			sectorentry++;
		}
		
		return result;
}


/* - Description: Gets file information (starting cluster, size, etc.)
 * - Flags: 	entrynumber		-> File position (Look notes)
 * 				*format			-> Pointer to string containing format of the given file (Look notes)
 * 				*filename		-> Pointer to string containing complete file name, extension included (Look notes)
 * 				*file			-> Pointer to 'fat_fileentry' structure where to store file information
 * 
 * - Notes: To get gile information, you can choose beetween giving the entry number + its 
 * 			format OR the full file name.
 * 			--> If you choose the first method, give the *format and the entry number (related to this format) [starts with 1]
 * 				and give a NULL pointer to *filename flag
 * 			--> If you choose the second method, give the file name to *filename and 
 * 				give -1 to entrynumber and NULL to *format
 */
uint8_t fat_get_file_info(int16_t entrynumber, char *filename, struct file_formats *formats, uint8_t filter, struct fat_fileentry *file, uint8_t params){
    
	struct file_format *p;	
	char name[66]={ 0 };
	uint8_t sectorentry=16,sectorcount=0, i=0;
	int16_t entrycount=0;
	uint32_t sector, cluster;
	uint8_t *bufferp=NULL;
	
	//Avoid overflows...! -> Limited to 5 LFN entries
	if(params==FAT_GET_BY_NAME){
		if(strlen(filename)>64) return 1; //File name too long
	}
	cluster=partition.currentfolder;
	sector=fat_cluster_to_sector(cluster);
	
	
	while(1){
		
		/* Check if we have lasted the actual sector/cluster */
		if(sectorentry >= 16){
			if(++sectorcount >= partition.secsperclus){
				cluster = fat_get_next_cluster(cluster);
				if(cluster==0) break; //End of folder
				sectorcount=0;
				sector=fat_cluster_to_sector(cluster);
			}
			
			sd_read(sector++ , 0, 512, global_buffer);
			bufferp=global_buffer;
			sectorentry=0;
		}
		
		//No more files in this folder.
		if(*bufferp==0) break;
			
		if (*bufferp != 0xe5){
			//Check for LFN entry
			if(*(bufferp+11) == 0xf && (((params&FAT_GET_MODE)==FAT_GET_BY_NAME)||(params&FAT_SAVE_FILE_NAME))){

				i=(*(bufferp) & 0x3f)-1; //Get LFN chain number
				
				if(i<7 && filename){ 
					name[i*13+0] = *(bufferp+1);
					name[i*13+1] = *(bufferp+3);
					name[i*13+2] = *(bufferp+5);
					name[i*13+3] = *(bufferp+7);
					name[i*13+4] = *(bufferp+9);
					name[i*13+5] = *(bufferp+14);
					name[i*13+6] = *(bufferp+16);
					name[i*13+7] = *(bufferp+18);
					name[i*13+8] = *(bufferp+20);
					name[i*13+9] = *(bufferp+22);
					name[i*13+10] = *(bufferp+24);
					name[i*13+11] = *(bufferp+28);
					name[i*13+12] = *(bufferp+30);
					//Check if this entry is the last inside the chain
					if(*bufferp & 0x40){
						name[i*13+13] = 0; //Add null char.
					}
				}
			
			//Check for SFN/File entry
			}else if((*(bufferp+11) & 0xe)==0){
				
				if(name[0] == 0 && (((params&FAT_GET_MODE)==FAT_GET_BY_NAME)||(params&FAT_SAVE_FILE_NAME))){
					//Short file name entry
					name[0]=*bufferp;
					name[1]=*(bufferp+1);
					name[2]=*(bufferp+2);
					name[3]=*(bufferp+3);
					name[4]=*(bufferp+4);
					name[5]=*(bufferp+5);
					name[6]=*(bufferp+6);
					name[7]=*(bufferp+7);
					if(*(bufferp+8)!=0x20){
						//FOR FILES
						name[8]='.';
						name[9]=*(bufferp+8);
						name[10]=*(bufferp+9);
						name[11]=*(bufferp+10);
						name[12]=0;
						
						//Remove spaces of incomplete SFN
						uint8_t flen = strlen(filename)-4;
						for(i=0; i<5; i++){
							name[flen+i] = name[8+i];
						}
					}else{
						//FOR FOLDERS
						name[8]=0;
						uint8_t n=strlen(name);
						for(i=0;i<n;i++){
							if(name[i] == 0x20){
								name[i]=0;
								break;
							}
						}
					}
				}
				
				if((params&FAT_GET_MODE)==FAT_GET_BY_ENTRY_NUM){
					//First check for folder
					if(*(bufferp+11) & (filter&ATTR_DIR)){
						entrycount++;
					}else if(formats->first){
							p=formats->first;
							while(p){
								if(strncmp(p->format,(char*)(bufferp+8),3)==0){
									entrycount++;
									break;
								}
								p=p->next;
							}
					}
				}
		
				if((entrynumber == entrycount && ((params&FAT_GET_MODE)==FAT_GET_BY_ENTRY_NUM)) || (strcmp_ign_length(filename, name, 2) && ((params&FAT_GET_MODE)==FAT_GET_BY_NAME))){

					//Store file information
					if(partition.format == 0x06){
						file->firstcluster = *(uint16_t*)(bufferp+26);
						file->firstcluster &= 0x0000ffff;	
					}else{
						file->firstcluster = *(uint16_t*)(bufferp+20);
						file->firstcluster <<= 16;
						file->firstcluster |= *(uint16_t*)(bufferp+26);
						file->firstcluster &= 0x0fffffff;
					}
					if(*(bufferp+11) & ATTR_DIR)
						file->type = TYPEFOLDER;
					else
						file->type = TYPEFILE;
					file->size = *(uint32_t*)(bufferp+28);
					file->pointer=0;
					file->currentcluster=file->firstcluster;

					//Store filename if requested
					if(params&FAT_SAVE_FILE_NAME){
						strncpy_unol(filename,name,params&0x3f);
					}

					return 0;
				}
				
				name[0] = 0;
			}
		}
		bufferp+=32;
		sectorentry++;
	}
	
	return 1;
}


/* - Description: Reads the given length of bytes from the given file
 * - Flags: 	*file	-> Pointer to 'struct fat_fileentry' containing the file information loaded
 * 				*buffer	-> Pointer to buffer where to store retrieved data
 * 				length	-> Number of bytes to read
 * - Notes: Length cannot exceed 512bytes
 */
uint16_t fat_read_file(struct fat_fileentry *file, uint8_t *buffer, uint16_t length){
	
	uint32_t cursector;
	uint16_t i, sectorpos, read=0;
	
	if(file->size==0 || file->currentcluster==0 || length > SD_SECTOR_SIZE){
		return 0;
	}
	
	if(file->pointer+length > file->size){
		length = (uint16_t)(file->size-file->pointer);
	}
	
	do{
		//Calculate current sector & position inside of it
		cursector = fat_cluster_to_sector(file->currentcluster) + ((file->pointer/SD_SECTOR_SIZE)%partition.secsperclus);
		sectorpos=file->pointer%SD_SECTOR_SIZE;
		//Calculate the length we must read of this sector
		if(sectorpos+length > SD_SECTOR_SIZE){
			i=SD_SECTOR_SIZE-sectorpos;
		}else{
			i=length;	
		}
		
		//Read and increase file pointer & buffer
		sd_read(cursector, sectorpos, sectorpos+i, buffer);
		file->pointer+=i;
		buffer+=i;
		
		//TODO -> Any better way?
		//Have we lasted actual cluster?
		if((file->pointer%SD_SECTOR_SIZE == 0) && ((file->pointer/SD_SECTOR_SIZE)%partition.secsperclus) == 0){
			//We must get the next cluster
			file->currentcluster = fat_get_next_cluster(file->currentcluster);
		}
		
		length-=i;
		read+=i;
		
	}while(length);
	
	return read;
}

/* - Description: Changes the file pointer to the given one and handles whether cluster has to be changed or not
 * - Flags: 	*file	-> File where to change the pointer
 * 				point	-> New point
 */
void fat_seek(struct fat_fileentry *file, uint32_t point){
	
	uint32_t numclusters;
	
	//Check if we can avoid reading the entire chain
	if(file->pointer < point){
		file->pointer=point - file->pointer;
	}else{
		//Not lucky :(
		file->pointer=point;
		file->currentcluster=file->firstcluster;
	}

	//Calculate how many clusters we have to advance
	numclusters=file->pointer/(SD_SECTOR_SIZE*partition.secsperclus);
	
	while(numclusters){
		file->currentcluster=fat_get_next_cluster(file->currentcluster);
		numclusters--;
	}
	
	file->pointer=point;
	
}

/* - Description: Moves to the directory given
 * - Flags: 	*name	-> Pointer to a string containing the directory name where to change
 * - Developer notes: 	TODO-> Should we implement the hability of changing directory by providing
 * 						directory name or entrynumber+rules? (Second way is needed by filebrowser_handler
 * 						to avoid changing directory with an incomplete name. 
 */
uint8_t fat_cd_dir(char *name){
	
	struct fat_fileentry dir;

	if(fat_get_file_info(0, name, NULL, 0, &dir, FAT_GET_BY_NAME)==0){
		partition.currentfolder = dir.firstcluster;
		return 0;	
	}
	
	return 1;
	
}

/**************************************/
/* FAT FORMATS LIST FOR FILE BROWSING */
/**************************************/

/* - Description: Adds a format to the list
 * - Flags: 	*rulesp	-> Pointer to the list containing rules
 * 				*format	-> String containing the format to be added
 */
void fat_formats_add(struct file_formats *formatsp, char *format){
	
	struct file_format *tmp;
	
	if(!(tmp=(struct file_format*)malloc(sizeof(struct file_format)))){
		return; //Not enough memory to add new filter format
	}
	
	strcpy(tmp->format, format);
	
	tmp->next=NULL;
	
	if(!formatsp->first){
		formatsp->first=tmp;
		formatsp->last=tmp;
	}else{
		formatsp->last->next=tmp;
		formatsp->last=tmp;
	}
	
}

/* - Description: Deletes a format from the list
 * - Flags: 	*formatsp	-> Pointer to the list containing rules
 * 				*format	-> String containing the format to be deleted
 */
void fat_formats_delete(struct file_formats *formatsp, char *format){
	
	struct file_format *p, *prev;
	
	prev=NULL;
	p=formatsp->first;
	
	while(p){
		if(strcmp(p->format, format)==0){
			//Found the element to delete
			if(prev){
				prev->next=p->next;
			}else{
				//actualrules.last is not cleared if it's also the first, but it has no effect
				formatsp->first=formatsp->first->next;
			}
			free(p);
			break;
		}
		prev=p;
		p=p->next;
	}
	
}

/* - Description: Cleans all items in a filerules structure (memory free)
 * - Flags: 	*formatsp	-> Pointer to the list containing rules
 */
void fat_formats_clear(struct file_formats *formatsp){
	
	while(formatsp->first){
		formatsp->last=formatsp->first->next;
		free(formatsp->first);
		formatsp->first=formatsp->last;
	}
	
}
