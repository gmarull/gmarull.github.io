/*  openplayer firmware - openplayer, an open source portable music player
    Copyright (C) 2008  Gerard Marull Paretas - <gerardmarull[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/**************************************************************************
 * 
 * Module to manage player interface - Version 1.0 (Prototyping)
 * 
 * File type: Source
 * File name: interface.c
 * 
 **************************************************************************/

#include <avr/io.h>
#include <avr/pgmspace.h>
#include <stdio.h>
#include <stdlib.h>
#include "hardware.h"
#include "sys/interface.h"
#include "sys/lcd.h"
#include "sys/util.h"
#include "sys/settings.h"
#include "apps/menus.h"
#include "main.h"

/* - Description: Displays a message on the screen
 * 
 * - Flags:		*message	-> String to be displayed (PROGMEM string!)
 * 				msgtype		-> Type of message: MSG_INFO, MSG_WARNING or MSG_ERROR
 */
void intf_message(char *message, uint8_t msgtype){
	
	const uint8_t *icon;
	
	switch(msgtype){
		
		case MSG_INFO:
			icon=icon_info;
			break;
		case MSG_WARNING:
			icon=icon_warning;
			break;
		case MSG_ERROR:
			icon=icon_error;
			break;
		default:
			icon=icon_info;
			break;
	}
	
	lcd_drawicon(icon,58,22,true);
	lcd_put_string(message, 2, 42, openplayer.skin.txt, 0, (1<<TEXT_TRANSP) | (1<<TEXT_MLINE) | (1<<TEXT_DOTS));
		
}

/* - Description: Refreshed the header (even battery level)
 * 
 * - Flags:	none
 */
void intf_refresh_header(){
	
	//Draw header
	lcd_draw_rectangle(0, 0, 132, 19, openplayer.skin.header_bg);
	//Check battery level
	openplayer.batt_level=device_get_batt_level();
	intf_redraw_batt_level();
	
}


/* - Description: Redraws battery level
 * 
 * - Flags:		none
 */
void intf_redraw_batt_level(){
	
	if(openplayer.batt_level>=BATT_GREEN){
		lcd_draw_rectangle(107, 6, 22, 6, openplayer.skin.header_bg);
		lcd_drawicon(icon_batgreen,107,6,true);
		lcd_drawicon(icon_batgreen,115,6,true);
		lcd_drawicon(icon_batgreen,123,6,true);
	}else if(openplayer.batt_level>=BATT_YELLOW){
		lcd_draw_rectangle(107, 6, 22, 6, openplayer.skin.header_bg);
		lcd_drawicon(icon_batyellow,107,6,true);
		lcd_drawicon(icon_batyellow,115,6,true);
	}else{
		lcd_draw_rectangle(107, 6, 22, 6, openplayer.skin.header_bg);
		lcd_drawicon(icon_batred,107,6,true);
	}
	
}


/* - Description: Changes the current language to a new one and stores it to EEPROM
 * 
 * - Flags:		*language -> New language
 */
inline void intf_set_current_language(void *languagep){
	
	openplayer.current_language=(PGM_P*)languagep;
	sett_save_value(&openplayer.current_language, sizeof(openplayer.current_language));
	
}

/* - Description:  Draws a new icon placed on the header
 * 
 * - Flags:		*icon -> Icon to be drawn
 */
inline void intf_topicon_draw(const uint8_t *icon){
	
	lcd_draw_rectangle(2, 1, 16, 16, openplayer.skin.header_bg);
	lcd_drawicon(icon,2,1,true);
	
}
