/*  openplayer firmware - openplayer, an open source portable music player
    Copyright (C) 2008  Gerard Marull Paretas - <gerardmarull[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/**************************************************************************
 * 
 * LCD driver module - Version 1.0
 * 
 * File type: Source
 * File name: lcd.c
 * 
 **************************************************************************/
 
#include <avr/io.h>
#include <avr/pgmspace.h>
#include <stdbool.h>
#include <stdlib.h>
#include "hardware.h"
#include "sys/lcd.h"
#include "sys/fat.h"
#include "sys/util.h"
#include "sys/interface.h"
#include "sys/settings.h"


 /* - Description: Sends a byte through SPI
  * - Flags:	byte	-> byte that will be sent
  */
uint8_t lcd_send_byte(uint8_t byte){
	
	SPDR = byte;
	while (!(SPSR & (1 << SPIF)));
	return SPDR;	
}

/* - Description: Initializes the LCD
 * - Flags: None
 */
void lcd_init(){
	
		uint8_t n=0;
		//Configure needed ports as output
		LCD_DDR |= (1<<LCD_CS) | (1<<LCD_RESET);
		
		//Hardware reset
		LCD_PORT &= ~(1<<LCD_RESET);
		delay_us(10);
		LCD_PORT |= (1<<LCD_RESET);
		delay_us(10);
		//Software reset
		lcd_send_cmd(LCD_SWRESET);
		
		//Sleep mode out
		lcd_send_cmd(LCD_SLPOUT);
		//Turn booster on
		lcd_send_cmd(LCD_BSTRON);
		delay_us(10000);
		//Turn display on
		lcd_send_cmd(LCD_DISPON);
		//Set normal mode
		lcd_send_cmd(LCD_NORON);
		//Set color mode
		lcd_send_cmd(LCD_COLMOD);
		lcd_send_data(LCD_COLMOD_DEFAULT);
		//Adjust contrast
		lcd_send_cmd(LCD_WRCNTR);
		lcd_send_data(LCD_DEFAULT_CONTRAST);
		//Select memory access control
		lcd_send_cmd(LCD_MADCTR);
		lcd_send_data(0x88);
		//Set color look-up table (only for 256 color mode)
		if(LCD_COLMOD_DEFAULT == LCD_COLMOD_8BIT){
			lcd_send_cmd(LCD_RGBSET);
			
			for(n=0;n<=15;n+=2){
				if(n==8) n=9;
				lcd_send_data(n);
			}
			
			for(n=0;n<=15;n+=2){
				if(n==8) n=9;
				lcd_send_data(n);
			}
	
			lcd_send_data(0x00);
			lcd_send_data(0x04);
			lcd_send_data(0x0b);
			lcd_send_data(0x0f);
		}
		
		//Init & enable backlight
		/* Enable backlight, PWM port as output */
		LCD_BACKLIGHT_DDR|=(1<<LCD_BACKLIGHT_SHDN)|(1<<LCD_BACKLIGHT_RSET);
		LCD_BACKLIGHT_PORT|=(1<<LCD_BACKLIGHT_SHDN)|(1<<LCD_BACKLIGHT_RSET);
		/* Set up Timer3 to (FastPWM mode 8-bit) */
		TCCR3A |= (1<<COM3A1)|(1<<COM3A0)|(1<<WGM30)|(0<<WGM31);
		//Use system clock / 64
		TCCR3B |= (0<<CS32)|(1<<CS31)|(1<<CS30)|(0<<WGM33)|(1<<WGM32);
		//Setup Output Compare Register (up to 255, higher=backlight increases)
		OCR3AH=0;
		OCR3AL=LCD_BACKLIGHT_MIN+openplayer.backlight*((255-LCD_BACKLIGHT_MIN)/8);
}


/* - Description: Sends a command to the LCD
 * - Flags:	command	-> Command that will be sent. Open lcd.h to see available commands
 */
void lcd_send_cmd(uint8_t command){
	
	spi_off();
	act_lcd();

	//Send 1st bit, 0->Command
	SPI_PORT &= ~(1<<SPI_SCK);
	asm volatile ("nop");
	SPI_PORT &= ~(1<<SPI_MOSI);
	asm volatile ("nop");
	SPI_PORT |= (1<<SPI_SCK);
	asm volatile ("nop");
	spi_on();
	
	lcd_send_byte(command);
	dis_lcd();
	
}


/* - Description: Sends 8bits in data mode to the LCD
 * - Flags:	data	-> Byte that will be sent
 */
void lcd_send_data(uint8_t data){
	
	spi_off();
	act_lcd();
	
	//Send 1st bit, 1->Data
	SPI_PORT &= ~(1<<SPI_SCK);
	asm volatile ("nop");
	SPI_PORT |= (1<<SPI_MOSI);
	asm volatile ("nop");
	SPI_PORT |= (1<<SPI_SCK);
	asm volatile ("nop");
	spi_on();
	
	//Send the given byte
	lcd_send_byte(data);
	dis_lcd();
	
}


/* - Description: Sets the current active/working area of the LCD 
 * - Flags: 	xs			-> X coordinate (start)
 * 				xe			-> X coordinate (end)
 * 				ys			-> Y coordinate (start)
 * 				ye			-> Y coordinate (end)
 */
void lcd_set_window(uint8_t xs, uint8_t xe, uint8_t ys, uint8_t ye){
	
	lcd_send_cmd(LCD_CASET);
	lcd_send_data(xs);
	lcd_send_data(xe);
	
	lcd_send_cmd(LCD_RASET);
	lcd_send_data(ys);
	lcd_send_data(ye);
		
}


/* - Description: Clears the LCD with the given color
 * - Flags		bgcolor	-> Color used to clear
 */
void lcd_clear(uint8_t bgcolor){
	uint16_t i;
	lcd.busy=true;
	lcd_set_window(0,131,0,131);
	lcd_send_cmd(LCD_RAMWR);
	for(i=0;i<0x4401;i++){
		lcd_send_data(bgcolor);	
	}
	lcd.busy=false;
}


/* - Description: Writes a unique char into the LCD, stored in SRAM.
 * - Flags:  	character	-> Character that will be written
 * 				x0  		-> Position start (X)
 * 				y0			-> Position start (Y)
 * 				textcolor	-> Text color
 * 				bgcolor		-> Background color
 * 				params		-> Some parameters, used at bit level: (1 is set, 0 is clear) - #defines at lcd.h
 * 							Bit 2: Transparency - Text will not delete what's on its background. bgcolor flag will be ignored
 */
void lcd_put_char(char character, uint8_t x0, uint8_t y0, uint8_t textcolor, uint8_t bgcolor, uint8_t params){
		
		uint8_t i,n,x;
		uint16_t arraypos;
		
		lcd.busy=true;
		
		if(character>0x7f) character=0x3f; //If we are out of range, show '?'
		
		lcd_set_window(x0,x0+(FONT_WIDTH-1),y0,y0+(FONT_HEIGHT-1));

		arraypos = (character-30)*FONT_HEIGHT;
		
		lcd_send_cmd(LCD_RAMWR);
		for(i=0;i<FONT_HEIGHT;i++){
				x=pgm_read_byte(&flash_font[((character-30)*FONT_HEIGHT)+i]);
				for(n=0;n<FONT_WIDTH;n++){
					if(bit_is_set(x,7-n)){
						if(bit_is_set(params, TEXT_TRANSP)){
							lcd_set_pixel(x0+n,y0+i,textcolor); //Write specific pixel, transparency enabled	
						}else{
							lcd_send_data(textcolor); //Write font pixel
						}
					}else{
						if(bit_is_clear(params, TEXT_TRANSP))
							lcd_send_data(bgcolor);	 //Write bg pixel
					}
				}
		}
		
		lcd.busy=false;
	
}
 
/* - Description: Writes a string stored in progmem.
 * - Flags:  	*text 		-> Pointer to a char array stored in PROGMEM containing the text
 * 				x0  		-> Position start (X)
 * 				y0			-> Position start (Y)
 * 				textcolor	-> Text color
 * 				bgcolor		-> Background color
 * 				params		-> Some parameters, used at bit level: (1 is set, 0 is clear) - #defines at lcd.h
 * 							Bit 0: AutoDots (If the text doesn't fits on the screen will automatically write ... instead of cutting the text
 * 							Bit 1: Multiline - Text can be multiline if this bit is set
 * 							Bit 2: Transparency - Text will not delete what's on its background. bgcolor flag will be ignored
 * 							Bit 3: Source - Specify text location (0 is Flash and 1 is SRAM)
 */
void lcd_put_string(char *text, uint8_t x0, uint8_t y0, uint8_t textcolor, uint8_t bgcolor, uint8_t params){
	
	uint8_t x0save, character;
	
	x0save=x0;
	
	//Load first character to start loop
	if(bit_is_set(params,3)){
		//From SRAM
		character=*text++;
	}else{
		//From Flash
		character=pgm_read_byte(text++);
	}
	
	while(character){
		
		//Check if we have to jumpt to the next line
		if(131 - x0 < FONT_WIDTH){
			if(bit_is_set(params, TEXT_MLINE)){
				y0 += FONT_HEIGHT;
				x0=x0save;
			}else{
				return;	
			}
		//Check if dots have to be put
		}else if((131 - x0 < FONT_WIDTH*2) && (bit_is_set(params, TEXT_DOTS)) && (bit_is_clear(params,TEXT_MLINE) || (131-y0 < FONT_HEIGHT*2) )){
			lcd_put_char(0x7f,x0,y0,textcolor,bgcolor,params); //Print "..."
			return;
		}
		//Check if we have ended
		if(131 - y0 < FONT_HEIGHT) return;
		
		lcd_put_char(character,x0,y0,textcolor,bgcolor,params);
		
		x0+=FONT_WIDTH;
		
		//Read next character
		if(bit_is_set(params,3)){
			//From SRAM
			character=*text++;
		}else{
			//From Flash
			character=pgm_read_byte(text++);
		}
		
	}

}

/* - Description: Draws a filled rectangle of the given color
 * 
 * - Flags: 	xs			-> X coordinate of top-left corner (start)
 * 				xe			-> Y coordinate of bottom-right corner (end)
 * 				ys			-> X coordinate of top-left corner (start)
 * 				ye			-> Y coordinate of bottom-right corner (end)
 * 				bgcolor 	-> Rectangle color
 */
void lcd_draw_rectangle(uint8_t x_origin, uint8_t y_origin, uint8_t width, uint8_t height, uint8_t bgcolor){
	
	uint16_t i;
	
	lcd.busy=true;
	
	lcd_set_window(x_origin,x_origin+width-1,y_origin,y_origin+height-1);
	lcd_send_cmd(LCD_RAMWR);
	for(i=0;i<((width)*(height));i++){
		lcd_send_data(bgcolor);
	}
	
	lcd.busy=false;
	
}

/* - Description: Sets the indicated pixel of the given color
 * 
 * - Flags: 	x		-> X coordinate
 * 				y		-> Y coordinate
 * 				color 	-> Pixel color
 */
void lcd_set_pixel(uint8_t x, uint8_t y, uint8_t color){
	
	lcd_set_window(x,x+1,y,y+1);
	lcd_send_cmd(LCD_RAMWR);
	lcd_send_data(color);
		
}

/* - Description: Loads a bitmap file into the LCD. Color formats supported are Monochrome (1bit),
 * 256-Color (8bit) and 16M-Color (24bit). Compression is not supported.
 * 
 * - Flags:		*bmpfile	-> Pointer to a FAT file struct, containing file information loaded before.
 * 				offsetx		-> X position from the left (0). Can be negative.
 * 				offsety		-> Y position from the top  (0). Can be negative.
 * 
 * 
 * - Limitations: Bitmap width cannot exceed 170pixels in 24bit mode, 512pixels in 8bit mode
 * and 4096pixels in 1bit mode [due to buffer maximum size]. 
 */
void lcd_loadbitmap(struct fat_fileentry *bmpfile, int offsetx, int offsety){
	
	uint16_t sizex,sizey,rowsize=0;
	uint8_t i,j,bitscolor;
	uint8_t colors[256]; //Array that stores color table
	uint16_t dataoffset; //Never will use 32bits...
	
	lcd.busy=true;
	
	fat_read_file(bmpfile,global_buffer,0x36);
	if( !strcmpcase((char*)&global_buffer[0],"BM",2) || (global_buffer[30] != 0) || (*(uint8_t*)&global_buffer[28] == 4))
		return; //File is not BMP, is compressed or has 16colors.
	
	bitscolor=*(uint8_t*)&global_buffer[28];
	sizex=*(uint16_t*)&global_buffer[18];
	sizey=*(uint16_t*)&global_buffer[22];
	dataoffset=*(uint16_t*)&global_buffer[10];
	
	//Load color table and real length of each row in bytes
	switch(bitscolor){
		case BITMAP_2COLORS:
			//Could contain any 2 colors, not necessary have to be b/w.
			fat_read_file(bmpfile,global_buffer,8);
			colors[0] = RGB8BIT(global_buffer[2],global_buffer[1],global_buffer[0]);
			colors[1] = RGB8BIT(global_buffer[6],global_buffer[5],global_buffer[4]);
			rowsize=(sizex/8);
			rowsize+= 4 - (rowsize%4);
			break;
		case BITMAP_256COLORS:
			for(j=0;j<2;j++){
				fat_read_file(bmpfile,global_buffer,512);
				for(i=0;i<128;i++){
					colors[j*128+i]=RGB8BIT(global_buffer[i*4+2],global_buffer[i*4+1],global_buffer[i*4]);
				}	
			}
			rowsize=sizex;
			if(sizex%4)
				rowsize += 4-(sizex%4);
			break;
		case BITMAP_16MCOLORS:
			//Color table not needed
			rowsize=sizex*3+(sizex%4);
			break;

	}
	//Set picture position window
	lcd_set_window(offsetx,offsetx+(sizex-1),131-(sizey+offsety),131-(offsety-1));
	
	//Invert LCD Displaying mode (BMPs are saved reversed)
	lcd_send_cmd(LCD_MADCTR);
	lcd_send_data(0x8);
	
	//Draw pixels
	bmpfile->pointer=dataoffset;
	lcd_send_cmd(LCD_RAMWR);
	for(i=0;i<sizey;i++){
		fat_read_file(bmpfile,global_buffer, rowsize);
		switch(bitscolor){
			case BITMAP_2COLORS:
				for(j=0;j<rowsize;j++){
					for(dataoffset=0;dataoffset<8;dataoffset++){
						if((j*8 + dataoffset)<sizex){
							if(bit_is_set(global_buffer[j],7-dataoffset))
								lcd_send_data(colors[1]);
							else
								lcd_send_data(colors[0]);
						}
					}
				}
				break;
			case BITMAP_256COLORS:
				for(j=0;j<sizex;j++){
					lcd_send_data(colors[global_buffer[j]]);
				}
				break;
			case BITMAP_16MCOLORS:
				for(j=0;j<sizex;j++){
					lcd_send_data(RGB8BIT(global_buffer[j*3+2],global_buffer[j*3+1],global_buffer[j*3]));	
				}
				break;
		}
	}
	
	//Return to initial display mode
	lcd_send_cmd(LCD_MADCTR);
	lcd_send_data(0x88);
	
	lcd.busy=false;
	
}


/* - Description: Draws an icon stored in program memory (flash)
 * 
 * - Flags:		*iconarray	-> Pointer to the icon data array stored in PROGMEM
 * 				offsetx		-> X position from the left (0).
 * 				offsety		-> Y position from the top  (0).
 * 				transp		-> Transparency enabled (true/false)
 * 
 * - Notes: Transparency needs more instructions & lcd command to draw the icon. 
 */
void lcd_drawicon(const uint8_t *iconarray, uint8_t offsetx, uint8_t offsety, bool transp){
	
	uint8_t sizex, sizey, n, z;
	uint16_t i;
	
	lcd.busy=true;
	
	sizex=pgm_read_byte(iconarray++);
	sizey=pgm_read_byte(iconarray++);
	
	lcd_set_window(offsetx,offsetx+(sizex-1),offsety,offsety+(sizey-1));
	
	if(transp==true){
		//Slower drawing than not transparent icons
		for(i=0;i<sizey;i++){
			for(n=0;n<sizex;n++){
				z=pgm_read_byte(iconarray++);
				if(z!=TRANSP_KEY) lcd_set_pixel(offsetx+n,offsety+i,z);
			}
		}
	}else{
		lcd_send_cmd(LCD_RAMWR);
		for(i=0;i<sizex*sizey;i++){
			lcd_send_data(pgm_read_byte(iconarray++));
		}
	}
	
	lcd.busy=false;
	
}

void lcd_adjust_backlight(uint8_t level){
	
	if(level==0){
		//Turn off backlights
		TCCR3B&=~(1<<CS32)|(1<<CS31)|(1<<CS30);
		LCD_BACKLIGHT_PORT &= ~(1<<LCD_BACKLIGHT_SHDN);
	}else{
		//Turn backlight on (if not yet turned on)
		LCD_BACKLIGHT_PORT |= (1<<LCD_BACKLIGHT_SHDN);
		TCCR3B |= (0<<CS32)|(1<<CS31)|(1<<CS30);
		//Set level
		OCR3AH=0;
		OCR3AL=level;
	}
	
}

void lcd_sleep(){
	
	lcd_clear(0x00);
	
	lcd_send_cmd(LCD_DISPOFF);
	lcd_send_cmd(LCD_SLPIN);
	
	lcd_adjust_backlight(0);
	
}
