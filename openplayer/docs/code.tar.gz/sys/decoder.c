/*  openplayer firmware - openplayer, an open source portable music player
    Copyright (C) 2008  Gerard Marull Paretas - <gerardmarull[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/**************************************************************************
 * 
 * Module for MP3 decoder VS1011b - Version 1.0
 * 
 * File type: Source
 * File name: decoder.c
 * 
 **************************************************************************/
 
#include <avr/io.h> 
#include <avr/interrupt.h>
#include "hardware.h"
#include "sys/decoder.h"
#include "sys/util.h"


 /* - Description: Sends a byte through SPI
  * - Flags:	byte	-> byte that will be sent
  */
uint8_t dec_sendbyte(uint8_t byte){
	
	SPDR = byte;
	while (!(SPSR & (1 << SPIF)));
	return SPDR;
	
}

 /* - Description: Initializes decoder
  * - Flags: None
  */
uint8_t dec_init(){
	
	uint8_t retry=0;
	
	/* Set ports */
	DEC_DDR |= (1<<DEC_XCS) | (1<<DEC_XDCS) | (1<<DEC_XRESET);
	DEC_DDR &= ~(1<<DEC_DREQ);
	
	/* Hardware reset */
	DEC_PORT &= ~(1<<DEC_XRESET);
	delay_us(0xffff);
	DEC_PORT |= (1<<DEC_XRESET);
	
	/* SPI to low speed */
	SPCR |= (1<<SPR0) | (1<<SPR1);
	SPSR &= ~(1<<SPI2X);
	
	
	/* Wait until native serial mode becomes active */
	do{
		dec_write(DEC_MODE, 0x0800);
		if(retry++ > 10)
			goto error;
	}while(dec_read(DEC_MODE) != 0x0800);
	
	retry=0;
	
	/* Set clock speed value */
	do{
		dec_write(DEC_CLOCKF, 0x9000);
		if(retry++ > 10)
			goto error;
	}while(dec_read(DEC_CLOCKF) != 0x9000);
	

	/* Set default volume & decode time to 0 */
	dec_setvolume(VOL_DEFAULT, VOL_DEFAULT);
	dec_write(DEC_DECTIME, 0);
	
	
	/* Turn on SPI high speed again */
	SPCR &= ~((1<<SPR0)|(1<<SPR1));
	SPSR |= (1<<SPI2X);
	
	dec_nulls(2048);
	
	return 0;
	
error:
	
	/* Turn on SPI high speed again */
	SPCR &= ~((1<<SPR0)|(1<<SPR1));
	SPSR |= (1<<SPI2X);
	
	return 1;
}

 /* - Description: Reads the content of a decoder register
  * - Flags: 	address	-> Address of the register - See "decoder.h"
  */
uint16_t dec_read(uint8_t address){
	
	uint16_t value;
				
	act_decoder();
	dec_sendbyte(DEC_OP_READ);
	dec_sendbyte(address);
	value = dec_sendbyte(0xff);
	value = (value << 8) | dec_sendbyte(0xff);
	dis_decoder();
	
	return value;
		
}

 /* - Description: Writes the given value into the given register
  * - Flags: 	address -> Address of the register where to put data
  * 			val		-> Value stored
  */
void dec_write(uint8_t address, uint16_t val){
	
	act_decoder(); 
		
	dec_sendbyte(DEC_OP_WRITE);
	dec_sendbyte(address);
	dec_sendbyte(val >> 8);
	dec_sendbyte(val);
	
	dis_decoder(); 
	
	
}

 /* - Description: Resets the decoder (Software)
  * - Flags: None
  */
void dec_softreset(){
	
	dec_write(DEC_MODE, 0x02);
	delay_us(0xffff);
	while(bit_is_clear(DEC_PIN, DEC_DREQ));
		
}

 /* - Description: Changes the current volume
  * - Flags: 	right	-> Right chanel volume level
  * 			left	-> Left chanel volume level
  */
void dec_setvolume(uint8_t right, uint8_t left){
	
	dec_write(DEC_VOL, ((uint16_t)right<<8 | left));
	
}

 /* - Description: Sends data to decoder (music data)
  * - Flags: 	data	-> Byte of data that will be sent
  */
void dec_datawrite(uint8_t data){
		
		cli();
		xdcs_low();
		dec_sendbyte(data);
		xdcs_high();
		dis_decoder();
		sei();
}

 /* - Description: Send the given number of null bytes (used when current song ends)
  * - Flags: 	num	-> Number of null bytes that will be sent
  */
void dec_nulls(uint16_t num){
	
	while(num-- > 0){
		dec_datawrite(0);	
	}
		
}


/* - Description: Puts the decoder in standby mode
 * - Flags: 	None
 */
inline void dec_standby(){
	
	DEC_PORT &= ~(1<<DEC_XRESET);
	dis_decoder();
	
}

