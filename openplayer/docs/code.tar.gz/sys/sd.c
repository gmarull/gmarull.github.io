/*  openplayer firmware - openplayer, an open source portable music player
    Copyright (C) 2008  Gerard Marull Paretas - <gerardmarull[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/**************************************************************************
 * 
 * Module for managing SecureDigital Cards - Version 1.0
 * 
 * File type: Source
 * File name: sd.c
 * 
 **************************************************************************/

#include <avr/io.h>
#include "hardware.h"
#include "sys/sd.h"
#include "sys/util.h"

/***************************************/
/********** Internal functions *********/
/***************************************/

 /* - Description: Sends a byte through SPI
  * - Flags:	byte	-> byte that will be sent
  */
uint8_t sd_send_byte(uint8_t byte){
	
	uint16_t i=0;
	
	SPDR = byte;
	
	while (!(SPSR & (1 << SPIF))){
		if(i++==4000)
			break; //Timeout	
	}; 
	
	return SPDR;	
}

 /* - Description: Sends a command to the SD
  * - Flags:	command	-> command that will be sent - Open sd.h to see available commands
  * 			arg		-> Argument for the command
  */
void sd_send_command(uint8_t command, uint32_t arg){
		
		sd_send_byte(command);
		sd_send_byte(arg>>24);
		sd_send_byte(arg>>16);
		sd_send_byte(arg>>8);
		sd_send_byte(arg);
		sd_send_byte(sd.command_crc);
		
}

 /* - Description: Waits until the given response is received or timeout exceeds
  * - Flags:	response	-> Expected response
  * 			timeout		-> Maximum number of retries
  */
uint8_t sd_get_response(uint8_t response, uint16_t timeout){
	
	while(timeout-- > 0){
		if(sd_send_byte(0xff) == response) return 1;
	}
	return 0;
}

/******************************************/
/********** Common functions **************/
/******************************************/

 /* - Description: Reads data from SD
  * - Flags:	sector		-> Sector where to look for inside of SD card
  * 			firstbyte	-> The byte where start reading
  * 			lastbyte	-> The byte where to stop reading
  * 			*buffer		-> Pointer to the buffer where to store retrieved data
  * - Notes: Data retrieved will be lastbyte-firstbyte. Ex: to read 512 sectors, enter 0 and 512.
  */
uint8_t sd_read(uint32_t sector, uint16_t firstbyte, uint16_t lastbyte, uint8_t *buffer){
		
		uint16_t i;
		
		SD_SELECT();
		
		sd_send_command(SD_CMD_READ_SINGLE_BLOCK, (sd.addressing_mode==SD_BLOCK_ADDRESSING)?sector:sector<<9);

		/* Wait until success */
		if(sd_get_response(SD_R1_SUCCESS, 0xff)){
			/* Wait until data token is received */ 
			if(sd_get_response(0xfe, 0xff)){
				/* Save data received */
				for(i=0;i<firstbyte;i++){
					sd_send_byte(0xff);
				}
				for(i=i;i<lastbyte;i++){
					*buffer++=sd_send_byte(0xff);
				}
				for(i=i;i<SD_SECTOR_SIZE;i++){
					sd_send_byte(0xff);	
				}
			}else{	
				goto error;
			}
		}else{
			goto error;
		}
		
		/* Send dummy CRC */
		sd_send_byte(0xff);
		sd_send_byte(0xff);
		
		SD_SEND_8_CLOCKS();
			
		/* Success */
		SD_DESELECT();
		
		return 1;
		
	/* An error happened... */
	error:
		SD_DESELECT();
		return 0;
		
		
}


 /* - Description: Writes data into SD
  * - Flags:	sector		-> Sector where to store data
  * 			*buffer		-> Pointer to the buffer that contains data
  */
uint8_t sd_write(uint32_t sector, uint8_t *buffer){
	
	uint16_t i;
	
	SD_SELECT();
	
	sd_send_command(SD_CMD_WRITE_BLOCK, (sd.addressing_mode==SD_BLOCK_ADDRESSING)?sector:sector<<9);
	if(sd_get_response(SD_R1_SUCCESS, 0xff)){
		
		sd_send_byte(0xff);
		sd_send_byte(0xfe); //Data token
		
		/* Send sector data */
		for(i=0;i<SD_SECTOR_SIZE;i++){
			sd_send_byte(*buffer++);
		}
		
		/* Send 2 CRC null bytes */
		sd_send_byte(0xff);
		sd_send_byte(0xff);
		
		if(((sd_send_byte(0xff) & 0x1f) >> 1) != 0x02) goto error;
		
	}else goto error;
	
	SD_SEND_8_CLOCKS();
	
	SD_DESELECT();
	return 1;
	
error:
	SD_DESELECT();
	return 0;
		
}



 /* - Description: Initializes SD
  * - Flags: None
  */
uint8_t sd_init(){
	
	uint8_t i;
	uint8_t response;
	uint8_t buff[4];
	
	/* Pins initialization */
	//CS as output
	SD_DDR |= (1<<SD_CS);
	//MOSI & CS high when starting
	SPI_PORT |= (1<<SPI_MOSI);
	SD_DESELECT(); 
	
	/* Set SPI to low speed */
	SPCR |= (1<<SPR0) | (1<<SPR1);
	SPSR &= ~(1<<SPI2X);
	
	/* Send 80 dummy clock pulses */
	for(i=0;i<10;i++){
		sd_send_byte(0xff);
	}
	
	SD_SELECT();
	
	/* Reset / Put SD into Idle State */
	sd.command_crc=0x95;
	sd_send_command(SD_CMD_GO_IDLE_STATE, 0);
	if(!sd_get_response(SD_R1_IDLE_STATE, 0xfff)) goto error;
		
	SD_SEND_8_CLOCKS();
	
	/* Check if SD is v1 or v2 */
	sd.command_crc=0x87;
	sd_send_command(SD_CMD_SEND_IF_COND, 0x01aa);
	do{
		response=sd_send_byte(0xff);
	}while(response!=SD_R1_IDLE_STATE && response!=(SD_R1_IDLE_STATE|SD_R1_ILLEGAL_COM));
	
	SD_SEND_8_CLOCKS();
	
	sd.command_crc=0;
	/** Send initialization sequences **/
	/* Initialization for version 1 */
	if(response==(SD_R1_IDLE_STATE|SD_R1_ILLEGAL_COM)){
		
		do{

			/* Send Application Command */
			sd_send_command(SD_CMD_APP_CMD,0);
			if(!sd_get_response(SD_R1_IDLE_STATE, 0xff)) goto error;
			
			SD_SEND_8_CLOCKS();
			
			/* Complete initialization process */
			sd_send_command(SD_ACMD_SD_SEND_OP_COND,0);
			for(i=0;i<8;i++){
				response=sd_send_byte(0xff);
				if(response==SD_R1_SUCCESS) break;
			}
	
			SD_SEND_8_CLOCKS();
			
		}while(response!=SD_R1_SUCCESS);
			
		/* Disable CRC */
		sd_send_command(SD_CMD_CRC_ON_OFF,0);
		if(!sd_get_response(SD_R1_SUCCESS, 0xff)) goto error;
		
		SD_SEND_8_CLOCKS();
		
		/* Set sector size */
		sd_send_command(SD_CMD_SET_BLOCKLEN,512);
		if(!sd_get_response(SD_R1_SUCCESS, 0xff)) goto error;
		
		SD_SEND_8_CLOCKS();
		
		sd.version=SD_VERSION_1;
		sd.addressing_mode=SD_BYTE_ADDRESSING;
			
	/* Initialization for version 2 */
	}else if(response==SD_R1_IDLE_STATE){

			/* Store R7 response (from SD_CMD_SEND_IF_COND) */
			for(i=0;i<3;i++){
				buff[i]=sd_send_byte(0xff);
			}
			
			/* Check pattern & operating voltage */
			if(buff[2]!=SD_R7_PATTERN || ((buff[1]&0xf)!=SD_R7_OP_VOLTAGE)) goto error;
			
			SD_SEND_8_CLOCKS();
			
			do{
				
				/* Send Application Command */
				sd_send_command(SD_CMD_APP_CMD, 0);
				if(!sd_get_response(SD_R1_IDLE_STATE, 0xff)) goto error;
				
				SD_SEND_8_CLOCKS();
				
				/* Complete initialization process, HCS bit set */
				sd_send_command(SD_ACMD_SD_SEND_OP_COND, 0x40000000);
				for(i=0;i<8;i++){
					response=sd_send_byte(0xff);
					if(response==SD_R1_SUCCESS) break;
				}
				
				SD_SEND_8_CLOCKS();
				
			}while(response!=SD_R1_SUCCESS);
			
			
			/* Read OCR to check addressing mode */
			sd_send_command(SD_CMD_READ_OCR, 0);
			if(!sd_get_response(SD_R1_SUCCESS, 0xff)) goto error;
			
			//Store OCR
			for(i=0;i<4;i++){
				buff[i]=sd_send_byte(0xff);
			}
			
			//Check & store addressing mode
			if(buff[0]&(1<<6)){
				sd.addressing_mode=SD_BLOCK_ADDRESSING;
			}else{
				sd.addressing_mode=SD_BYTE_ADDRESSING;
			}
			
			SD_SEND_8_CLOCKS();
			
			sd.version=SD_VERSION_2;
	}
	
	/* Turn on SPI high speed again */
	SPCR &= ~((1<<SPR0)|(1<<SPR1));
	SPSR |= (1<<SPI2X);
	
	SD_DESELECT();
	return 0;
	
error:
	
	/* Turn on SPI high speed again */
	SPCR &= ~((1<<SPR0)|(1<<SPR1));
	SPSR |= (1<<SPI2X);
	
	SD_DESELECT();
	return 1;
	
}
