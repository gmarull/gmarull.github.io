/*  openplayer firmware - openplayer, an open source portable music player
    Copyright (C) 2008  Gerard Marull Paretas - <gerardmarull[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/**************************************************************************
 * 
 * Module with util functions - Version 1.0
 * 
 * File type: Source
 * File name: util.c
 * 
 **************************************************************************/
#include <avr/io.h>
#include "sys/util.h"

/********/
/* MISC */
/********/

/* - Description: Delay function (to make uS exact delays)
 * - Flags: delay	-> Number of uS to delay (0 to 65535).
 * - Notes: If your clock is not running at 8Mhz, use us(x) macro 
 * 			to put the number of uS when calling this function
 * 
 * -Developer notes:
 * Corresponging asm code:
 * #ASM
 * ; load delay value and jump to loop
 * ldi r24, lo8(delay)
 * ldi r25, hi8(delay)
 * rjmp loop
 * ; instructions inside the loop
 * inloop:
 * nop
 * ; sequence for each loop (substract and compare)
 * loop:
 * sbiw r24, 1
 * ldi r18,hi8(-1)
 * cpi r24,lo8(-1)
 * cpc r25,r18
 * brne inloop
 * #ENDASM
 * 
 * Number of instructions executed in each loop call: 4 + 8*delay - 2 = 8*delay + 2
 * Delay running at 8Mhz -> Each cycle: 0.125micro-seconds. 
 * 						 -> 8*delay*0.125 + 2*0.125 = 1*delay micro-seconds + 0.25 micro-seconds
 */
inline void delay_us(uint16_t delay){
	
	while(delay--) asm volatile("nop");
	
}

/*******************/
/* MATHS/NUMBERING */
/*******************/

/* - Description: Counts the digits that would have a number in base10
 * 
 * - Flags:		value		-> Number that will be analyzed.
 */
uint8_t countdigits(uint32_t value){
	
	uint8_t digits=0;
	if(value==0) return 1; //Number zero, has 1 digit...
	while(value>=1){
		digits++;
		value=value/10;
	}
	
	return digits;
	
}

/* - Description: Powers two numbers: a^b
 * 
 * - Flags:		a			-> Base
 * 				b			-> Exponent
 * 
 * - Notes: Limited to unsigned exponents and 0
 */
uint32_t power(uint8_t a, int8_t b){
	
	uint32_t z;
	if(b==0) return 1;
	z=a;
	for(b=b-1;b>0;b-=1){
		z=z*a;
	}

	return z;
		
}

/* - Description: Returns the absolute value of a number
 * 
 * - Flags:		number		-> Value analyzed
 */
uint8_t absolute(int8_t number){
	if(number<0){
		number=number*-1;
	}
	return number;
}


/********************/
/* STRING UTILITIES */
/********************/

/* - Description: Checks if two strings are equal. This version is NOT case sensitive
 * 
 * - Flags:		*string1	-> Pointer to the first string
 * 				*string2	-> Pointer to the second string
 * 				num			-> Length to compare
 * - Notes: Function deprecated. Use equivalent one from string.h (avr-libc)
 */
uint8_t strcmpnocase(char *string1, char *string2, uint8_t num){
    uint8_t count;
    for(count=0; count<num; count++){
         if(*string1 > 0x60 && *string1 < 0x7b){
         	if((*string1-0x20)!=*string2) return 0;
         }else if(*string1 < 0x5b && *string1 > 0x40){
         	if((*string1+0x20)!=*string2) return 0;
         }else{
         	if(*string1!=*string2) return 0;	
         }
         
         string1++; string2++;
    }
    return 1;
}

/* - Description: Checks if two strings are equal. This version IS case sensitive
 * 
 * - Flags:		*string1	-> Pointer to the first string
 * 				*string2	-> Pointer to the second string
 * 				num			-> Length to compare
 * - Notes: Function deprecated. Use equivalent one from string.h (avr-libc)
 */
uint8_t strcmpcase(char *string1, char *string2, uint8_t num){
	uint8_t count;
	for(count=0; count<num; count++){
		if(*string1++ != *string2++) return 0;	
	}
	return 1;
}

/* - Description: Compares if two strings are equal until one of them ends and length is >= than minlength
 * 
 * - Flags:		*string1	-> Pointer to the first string
 * 				*string2	-> Pointer to the second string
 * 				minlength	-> Minimum length to consider comparison true
 */
uint8_t strcmp_ign_length(char *string1, char *string2, uint8_t minlength){
	
	uint8_t i=0;
	while(*string1 && *string2){
		if(*string1++ != *string2++) return 0;
		i++;
	}
	
	if(i>=minlength) return 1;
	
	return 0;
	
}

/* - Description: Copies one string into a buffer until the string ends or length becomes 0
 * 
 * - Flags:		*string1	-> Pointer to the first string
 * 				*string2	-> Pointer to the second string
 * 				length		-> Maximum length to copy
 * - Notes: Until Null Or Length (UNOL)
 */
void strncpy_unol(char *destination, char *source, uint16_t length){
	
	while(*source && length){
		*destination++=*source++;
		length--;
	}
	*destination=0; //Add null char
	
}

/* - Description: Converts a number (up to uint32_t) into base10 formatted ascii
 * 
 * - Flags:		number		-> Number to be converted
 * 				*string2	-> Pointer where to store the resulting ascii string
 * 				minlength	-> Minimum characters of the ascii string. Read note.
 * - Notes:		Example of usage of minlength: with fixlength=3, and number=3, returned string will be "003"
 */
void inttostr(uint32_t number, char *destination, uint8_t fixlength){
	
	uint8_t digits,x,y;
	
	digits=countdigits(number);
	
	//Check if we want a fix length. 
	if(digits<fixlength){
		while(fixlength!=digits){
			*destination++=0x30;
			fixlength--;
		}
	}
	
	for(x=1;x<=digits;x++){
		y=number/power(10,(digits-x));
		*destination++=0x30+y;
		number-=(y*power(10,(digits-x)));
	}
	*destination=0;
	
}


/* - Description: Copies an Unicode formatted text into another variable converted to ASCII
 * 				  and ends it with null.
 * 
 * - Flags:		*destination		-> Pointer to destination var
 * 				*source				-> Pointer to source var
 * 				length				-> Length of characters to copy
 * - Notes: The first to bytes of source must indicate Unicode Byte Order: Big endian (0xff-0xfe) or Little endian (0xfe-0xff)
 */
void strlcpy_u(char *destination, uint8_t *source, uint16_t length){
	
	//Check Unicode byte order
	if(*source==0xff){
		//Big endian
		source+=2;
	}else{
		//Little endian
		source+=3;
	}
	while(--length>0){
		if(*source>0x7f){ 
			*destination=0x3f; //If not in ASCII range, put '?'
		}else{
			*destination=*source;
		}
		source+=2;
		destination++;
	}
	*destination=0x00; //End with null character
}

