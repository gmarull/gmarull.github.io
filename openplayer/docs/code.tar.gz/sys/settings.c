/*  openplayer firmware - openplayer, an open source portable music player
    Copyright (C) 2008  Gerard Marull Paretas - <gerardmarull[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/**************************************************************************
 * 
 * Settings module -> Version 1.0
 * 
 * File type: Source
 * File name: settings.c
 * 
 **************************************************************************/

#include <avr/io.h>
#include <avr/eeprom.h>
#include "sys/settings.h"
#include "sys/util.h"
#include "sys/interface.h"
#include "debug/usart.h"

/* - Description: Restores settings loaded in EEPROM
 * - Flags:	None
 */
void sett_init(){

	/* Load settings from EEPROM */
	efs_get_file_info(1, SETT_EFS_FILE_FORMAT, &openplayer.config_file);
	efs_read_file(&openplayer.config_file, (void*)sett_efs_first, 0, sett_efs_length);
	
	/* Load saved skin */
	sett_skins_load(openplayer.current_skin_number);
}

/* - Description: Saves all settings to EEPROM
 * - Flags:	None
 */
inline void sett_save_all(){
	
	efs_write_file(&openplayer.config_file, sett_efs_first, 0, sett_efs_length);
	
}

/* - Description: Saves one setting to EEPROM
 * - Flags:		*address 	-> The address of the setting
 * 				length 		-> Length of that setting in memory (1, 2... bytes)
 */
inline void sett_save_value(void *address, uint8_t length){
	
	efs_write_file(&openplayer.config_file, address, ((uint16_t)address-((uint16_t)sett_efs_first)), length);
	
}
