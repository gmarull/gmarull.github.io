/*  openplayer firmware - openplayer, an open source portable music player
    Copyright (C) 2008  Gerard Marull Paretas - <gerardmarull[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/**************************************************************************
 * 
 * Module to debug using USART - Version 1.0
 * 
 * File type: Source
 * File name: usart.c
 * 
 **************************************************************************/
 
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <stdlib.h>
#include <string.h>
#include "debug/usart.h"
#include "sys/util.h"

#ifdef OP_DEBUG
 /* - Description: Sends a byte through SPI
  * - Flags:	byte	-> byte that will be sent
  */
void usart_send(char data){
	
	while (!(UCSR1A & (1 << UDRE1))){}

	UDR1 = data; 
		
}

/* - Description: Sends a string located at PROGMEM through usart
 * - Flags: 	*data		-> Pointer to the string
 */
void usart_sendstring_P(char *data){
	
	uint8_t i;
	
	while((i=pgm_read_byte(data))){
		usart_send(i);
		data++;	
	}
		
}
/* - Description: Sends a string located at SRAM through usart
 * - Flags: 	*data		-> Pointer to the string
 */
void usart_sendstring(char *data){
		
		while(*data){
			usart_send(*data);
			data++;
		}
}

/* - Description: Sends a the value of the given var formatted in hexadecimal through usart
 * - Flags: 	hexnumber		-> Number that will be sent
 */
void usart_sendhex(uint8_t hexnumber){
	
	uint8_t high,low;
	
	//High nibble
	high=hexnumber>>4;
	high += '0';
	if(high > '9')
		high += 7;  //For characters a,b,c...
	
	//Low nibble
	low=hexnumber&0xF;
	low += '0';
	if(low > '9')
		low += 7;
		
	usart_send(high);
	usart_send(low);
	
}

/* - Description: Sends a the value of the given var formatted in binary through usart
 * - Flags: 	binnumber		-> Number that will be sent
 */
void usart_sendbin(uint8_t binnumber){
	
	uint8_t i;
	for(i=0; i<8; i++){
		usart_send(0x30+((binnumber&0x80)>>7));
		binnumber<<=1;
	}
		
}

/* - Description: Sends a the value of the given var formatted in base10 through usart
 * - Flags: 	binnumber		-> Number that will be sent
 */
void usart_senddec(uint32_t decnumber){
	
	uint8_t digits,x,y;
	
	digits=countdigits(decnumber);
	
	for(x=1;x<=digits;x++){
		y=decnumber/power(10,(digits-x));
		usart_send(0x30+y);
		decnumber-=(y*power(10,(digits-x)));
	}
	
}


/* - Description: Initializes USART
 * - Flags: 	ubrr		-> UBRR (used to determine baud rate) - see microcontroller datasheet
 */
void usart_init(uint16_t ubrr){
	
	UBRR1H = (uint8_t)(ubrr>>8);
	UBRR1L = (uint8_t)ubrr;

	//Set double speed
	UCSR1A = (1 << U2X1);

	//Usart receiver and transmitter & 8 data bits
	UCSR1B = (1 << RXEN1) | (1 << TXEN1) | (0 << UCSZ12);

	// Asynchronous, no parity, 8 data bits, 1 stop bit
	UCSR1C = (1 << UCSZ11) | (1 << UCSZ10); 
		
}

#endif
