/*  openplayer firmware - openplayer, an open source portable music player
    Copyright (C) 2008  Gerard Marull Paretas - <gerardmarull[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/**************************************************************************
 * 
 * English Language file - Version 1.0
 * 
 * File type: Header
 * File name: lang_en.h
 * Author of translation: Gerard Marull
 * 
 **************************************************************************/
#ifndef LANG_EN_H_
#define LANG_EN_H_

#include <avr/io.h>
#include <avr/pgmspace.h>
#include "sys/interface.h"

LANG en_0[]="Decoder initialization has failed!";
LANG en_1[]="SD card initialization has failed!";
LANG en_2[]="File system initialization has failed!";
LANG en_3[]="SD card does not contain 'OPENPLAYER' folder!";
LANG en_4[]="Music";
LANG en_5[]="Pictures";
LANG en_6[]="Extras";
LANG en_7[]="Settings";
LANG en_8[]="Quit";
LANG en_9[]="Games";
LANG en_10[]="Thermometer";
LANG en_11[]="TV Remote";
LANG en_12[]="Clock";
LANG en_13[]="Reboot";
LANG en_14[]="Sleep";
LANG en_15[]="No Name";
LANG en_16[]="No Artist";
LANG en_17[]="No Album";
LANG en_18[]="'IMAGES' folder does not exist!";
LANG en_19[]="This folder does not contain any picture!";
LANG en_20[]="English";
LANG en_21[]="Catalan";
LANG en_22[]="'MUSIC' folder does not exist!";
LANG en_23[]="Empty folder";
LANG en_24[]="of";
LANG en_25[]="Language";
LANG en_26[]="Backlight";
LANG en_27[]="Temperature:";
LANG en_28[]="Brightness:";
LANG en_29[]="Auto-off time:";
LANG en_30[]="Contrast";
LANG en_31[]="Please, switch Lock Key to sleep openplayer";
LANG en_32[]="Battery low! Please, lock key to shutdown openplayer";
LANG en_33[]="Skins";
LANG en_34[]="Select skin";
LANG en_35[]="Install skins";
//LANG en_[]="";

//Pointer table for each string
PGM_P PROGMEM lang_en[] = {
		en_0,  en_1,  en_2,  en_3,  en_4,  en_5,  en_6,  en_7,  en_8,  en_9,
		en_10, en_11, en_12, en_13, en_14, en_15, en_16, en_17, en_18, en_19,
		en_20, en_21, en_22, en_23, en_24, en_25, en_26, en_27, en_28, en_29,
		en_30, en_31, en_32, en_33, en_34, en_35
};


#endif /*LANG_EN_H_*/
