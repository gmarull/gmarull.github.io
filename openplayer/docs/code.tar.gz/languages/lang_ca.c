/*  openplayer firmware - openplayer, an open source portable music player
    Copyright (C) 2008  Gerard Marull Paretas - <gerardmarull[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
/**************************************************************************
 * 
 * Catalan Language file - Version 1.0
 * 
 * File type: Header
 * File name: lang_ca.h
 * Author of translation: Gerard Marull
 * 
 **************************************************************************/
 
#ifndef LANG_CA_H_
#define LANG_CA_H_

#include <avr/io.h>
#include <avr/pgmspace.h>
#include "sys/interface.h"

LANG ca_0[]="La inicialitzacio del descodificador ha fallat!";
LANG ca_1[]="La inicialitzacio de la SD ha fallat!";
LANG ca_2[]="La inicialitzacio del sistema de fitxers ha fallat!";
LANG ca_3[]="La SD no conte la carpeta 'OPENPLAYER'!";
LANG ca_4[]="Musica";
LANG ca_5[]="Imatges";
LANG ca_6[]="Extres";
LANG ca_7[]="Configuracio";
LANG ca_8[]="Sortir";
LANG ca_9[]="Jocs";
LANG ca_10[]="Termometre";
LANG ca_11[]="TV C. Remot";
LANG ca_12[]="Rellotge";
LANG ca_13[]="Reinicia";
LANG ca_14[]="Apagar";
LANG ca_15[]="Sense nom";
LANG ca_16[]="Sense autor";
LANG ca_17[]="Sense album";
LANG ca_18[]="La carpeta 'IMAGES' no existeix!";
LANG ca_19[]="Aquesta carpeta no conte cap imatge!";
LANG ca_20[]="Angles";
LANG ca_21[]="Catala";
LANG ca_22[]="La carpeta 'MUSIC' no existeix!";
LANG ca_23[]="Carpeta buida";
LANG ca_24[]="de";
LANG ca_25[]="Idioma";
LANG ca_26[]="Il.luminacio";
LANG ca_27[]="Temperatura:";
LANG ca_28[]="Intensitat:";
LANG ca_29[]="Auto-apagat:";
LANG ca_30[]="Contrast";
LANG ca_31[]="Bloqueja l'openplayer per apagar-lo";
LANG ca_32[]="Bateria baixa!";
LANG ca_33[]="Skins";
LANG ca_34[]="Sel. un skin";
LANG ca_35[]="Instal. skins";

//Main array containing pointers to each string
PGM_P PROGMEM lang_ca[] = {
		ca_0,  ca_1,  ca_2,  ca_3,  ca_4,  ca_5,  ca_6,  ca_7,  ca_8,  ca_9,
		ca_10, ca_11, ca_12, ca_13, ca_14, ca_15, ca_16, ca_17, ca_18, ca_19,
		ca_20, ca_21, ca_22, ca_23, ca_24, ca_25, ca_26, ca_27, ca_28, ca_29,
		ca_30, ca_31, ca_32, ca_33, ca_34, ca_35
};

#endif /*LANG_CA_H_*/
