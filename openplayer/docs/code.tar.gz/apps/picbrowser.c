/*  openplayer firmware - openplayer, an open source portable music player
    Copyright (C) 2008  Gerard Marull Paretas - <gerardmarull[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/**************************************************************************
 * 
 * Picture browser program - Version 1.0
 * 
 * File type: Source
 * File name: picbrowser.c
 * 
 **************************************************************************/

#include <avr/io.h>
#include <string.h>
#include "hardware.h"
#include "apps/picbrowser.h"
#include "sys/settings.h"
#include "sys/interface.h"
#include "sys/fat.h"
#include "sys/lcd.h"
#include "apps/menus.h"
#include "main.h"


//Global PicBrowser variables
uint16_t currentimg=1;
uint16_t imgnum;
struct file_formats picformats;

/* - Description: Loads picture browser
 * 
 * - Flags: none
 */
void picb_load(){
	
	//Init image browser
	if(fat_cd_dir("IMAGES")){
		//Clear first
		lcd_draw_rectangle(0, 18, 132, 114, openplayer.skin.bg);
		intf_message(lang(18),MSG_WARNING);
		while(1){
			if(check_keys()){
				intf_refresh_header();
				menus_load(current_menu.menu, current_menu.selected);
				return;
			}
		}
	}
	
	fat_formats_add(&picformats, "BMP");

	if((imgnum=fat_count_files(&picformats,0))){
		fat_get_file_info(currentimg, NULL, &picformats, 0, &fileinfo, FAT_GET_BY_ENTRY_NUM);
		picb_load_bmp_centered(&fileinfo);
	}else{
		//Clear first
		lcd_draw_rectangle(0, 18, 132, 114, openplayer.skin.bg);
		intf_message(lang(19),MSG_WARNING);
	}
	
	//Switch to picbrowser key handler
	change_task(picb_handler);
}

/* - Description: Handles keys
 * 
 * - Flags: None
 */
void picb_handler(){
	
	switch(check_keys()){
			
		case (1<<KEYS_CENTER):
			//Exit image browser
			change_task(picb_exit);
			break;
			
		case (1<<KEYS_LEFT):
			if(currentimg>1){
				fat_get_file_info(--currentimg, NULL, &picformats, 0, &fileinfo, FAT_GET_BY_ENTRY_NUM);
				picb_load_bmp_centered(&fileinfo);
			}
			break;
			
		case (1<<KEYS_RIGHT):
			if(currentimg<imgnum){
				fat_get_file_info(++currentimg, NULL, &picformats, 0, &fileinfo, FAT_GET_BY_ENTRY_NUM);
				picb_load_bmp_centered(&fileinfo);
			}
			break;
	}
	
}

/* - Description: Exits picture browser
 * 
 * - Flags: none
 */
void picb_exit(){
	
	fat_formats_clear(&picformats);
	fat_cd_dir("..");
	intf_refresh_header();
	menus_load(current_menu.menu, current_menu.selected);
	
}

/* - Description: Loads a BMP file in the middle of the screen
 * 
 * - Flags: 	*file -> file to be drawn
 */
void picb_load_bmp_centered(struct fat_fileentry *file){
	
	uint8_t sizex, sizey;
	lcd_clear(0x00);
	
	//Get BMP Sizes
	//TODO-> Avoid big BMP sizes
	fat_read_file(file,global_buffer,0x1a);
	sizex=*(uint8_t*)&global_buffer[18];
	sizey=*(uint8_t*)&global_buffer[22];
	file->pointer=0; //Restore file pointer
	
	lcd_loadbitmap(file,(131-sizex)/2,(131-sizey)/2);
	
}
