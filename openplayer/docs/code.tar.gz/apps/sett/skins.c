/*  openplayer firmware - openplayer, an open source portable music player
    Copyright (C) 2008  Gerard Marull Paretas - <gerardmarull[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/**************************************************************************
 * 
 * Skins manager -> Version 1.0
 * 
 * File type: Source
 * File name: skins.c
 * 
 * NOTES: MODULE NOT FINISHED! :-(
 * Perdoneu que a l'entrega del treball no estigui del tot acabat... 
 * 
 **************************************************************************/

#include <avr/io.h>
#include "sys/settings.h"
#include "sys/efs.h"
#include "sys/fat.h"
#include "sys/interface.h"
#include "apps/filebrowser.h"



/* - Description: Initializes application
 * 
 * - Flags: none
 */
void sett_skins_browser_init(){
	
	fat_formats_add(&filebrowser.formats, "SKN");
	filebrowser.attr_filter=ATTR_DIR;
		
	//Launch filebrowser task
	filebrowser_init(icon_skins, icon_fileskin, sett_skins_install);
	
}

void sett_skins_install(){
	
}


/* - Description:  Loads a skin
 *
 * - Flags: 	skin_number -> Skin number to be loaded
 */
void sett_skins_load(uint8_t skin_number){
	
	struct efs_file	file;
	
	efs_get_file_info(skin_number, SKINS_EFS_FILE_FORMAT, &file);
	efs_read_file(&file, &openplayer.skin.bg, 0, SKINS_EFS_FILE_SIZE);
	
	openplayer.current_skin_number=skin_number;
}
