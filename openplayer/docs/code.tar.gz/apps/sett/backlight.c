/*  openplayer firmware - openplayer, an open source portable music player
    Copyright (C) 2008  Gerard Marull Paretas - <gerardmarull[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/**************************************************************************
 * 
 * Settings module -> Adjust backlight intensity / auto light-off time - Version 1.0 (Prototyping)
 * 
 * File type: Source
 * File name: backlight.c
 * 
 **************************************************************************/

#include <avr/io.h>
#include "hardware.h"
#include "sys/settings.h"
#include "sys/util.h"
#include "sys/lcd.h"
#include "sys/interface.h"
#include "apps/menus.h"
#include "main.h"

/* - Description: Initializes application
 * 
 * - Flags: none
 */
void sett_backlight_init(){
	
	uint8_t i;
	
	/* Clear screen & draw top icon */
	lcd_draw_rectangle(0, 18, 132, 114, openplayer.skin.bg);
	intf_topicon_draw(icon_backlight);
	
	/* Draw interface */
	lcd_drawicon(icon_backlight, 58, 28, true);
	lcd_put_string(lang(28), 9, 45, openplayer.skin.txt, openplayer.skin.bg, 0);
	lcd_put_char('-', 9, 62, openplayer.skin.txt, openplayer.skin.bg, 0);
	lcd_put_char('+', 115, 62, openplayer.skin.txt, openplayer.skin.bg, 0);
	//Brightness bar
	for(i=0;i<openplayer.backlight;i++){
		lcd_draw_rectangle(20+12*(i), 62, 8, 14, openplayer.skin.btn_bg);
	}
	
	change_task(sett_backlight_handler);
	
}

/* - Description: Handles keys
 * 
 * - Flags: none
 */
void sett_backlight_handler(){
	
	switch(check_keys()){
		case (1<<KEYS_CENTER):
			sett_backlight_exit();
			break;
		case (1<<KEYS_LEFT):
			if(openplayer.backlight){
				//Clear current position
				openplayer.backlight--;
				lcd_draw_rectangle(20+12*openplayer.backlight, 62, 8, 14, openplayer.skin.bg);
				lcd_adjust_backlight(LCD_BACKLIGHT_MIN+openplayer.backlight*((255-LCD_BACKLIGHT_MIN)/8));
			}
			break;
		
		case (1<<KEYS_RIGHT):
			if(openplayer.backlight<8){
				//Increase bar
				lcd_draw_rectangle(20+12*openplayer.backlight, 62, 8, 14, openplayer.skin.btn_bg);
				openplayer.backlight++;
				lcd_adjust_backlight(LCD_BACKLIGHT_MIN+openplayer.backlight*((255-LCD_BACKLIGHT_MIN)/8));
			}
			break;
		
	}
	
}

void sett_backlight_exit(){
	
	/* Save current value and exit */
	sett_save_value(&openplayer.backlight, sizeof(openplayer.backlight));
	menus_load(current_menu.menu, current_menu.selected);
	
}
