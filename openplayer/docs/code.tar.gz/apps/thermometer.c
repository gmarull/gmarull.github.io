/*  openplayer firmware - openplayer, an open source portable music player
    Copyright (C) 2008  Gerard Marull Paretas - <gerardmarull[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/**************************************************************************
 * 
 * Thermometer module, using DS18B20 - Version 1.0
 * 
 * File type: Source
 * File name: thermometer.c
 * 
 **************************************************************************/

#include <avr/io.h>
#include <avr/pgmspace.h>
#include <stdio.h>
#include <string.h>
#include "hardware.h"
#include "apps/thermometer.h"
#include "sys/lcd.h"
#include "sys/interface.h"
#include "sys/util.h"
#include "apps/menus.h"
#include "main.h"

/* Global variables for thermometer module */
char temp_units[]="C F";
char temp_res[]=" 9 10 11 12";
uint16_t temp_res_decimals[4]={5, 25, 125, 625};


/* - Description: Sends a reset sequence to the thermometer line
 * - Flags: None
 */
uint8_t therm_reset(){
	
	uint8_t i;
	
	//Pull line low and wait for 480uS
	THERM_LOW();
	THERM_OUTPUT_MODE();
	delay_us(us(480));
	
	//Release line and wait for 70uS
	THERM_INPUT_MODE();
	delay_us(us(60));
	
	//Read&store line value and wait until completion of 480uS period
	i=(THERM_PIN & (1<<THERM_DQ));

	delay_us(us(420));
	
	return i;
	
}


/* - Description: Writes a bit to the thermometre line
 * - Flags:	bit	-> Bit to be written (0 or 1)
 */
void therm_write_bit(uint8_t bit){
	
	//Pull line low for 1uS
	THERM_LOW();
	THERM_OUTPUT_MODE();
	delay_us(us(1));
	
	//If we want to transmit 1, release the line (if not will keep low)
	if(bit) THERM_INPUT_MODE();
	
	//Wait for 60uS and release the line
	delay_us(us(60));
	THERM_INPUT_MODE();
	
}

/* - Description: Reads a bit from the thermometre line
 * - Flags:	None
 */
uint8_t therm_read_bit(){
	
	uint8_t bit=0;
	
	//Pull line low for 1uS
	THERM_LOW();
	THERM_OUTPUT_MODE();
	delay_us(us(1));
	
	//Release line and wait for 14uS
	THERM_INPUT_MODE();
	delay_us(us(14));
	
	//Read line value
	if(THERM_PIN&(1<<THERM_DQ)) bit=1;
	
	//Wait for 45uS to end and return read value
	delay_us(us(45));
	return bit;
	
}

/* - Description: Reads a byte from the thermometre line
 * - Flags:	None
 */
uint8_t therm_read_byte(){
	
	uint8_t i=8, n=0;
	
	while(i--){
		//Shift one position right and store read value
		n>>=1;
		n|=(therm_read_bit()<<7);
	}
	
	return n;
	
}

/* - Description: Writes a byte to the thermometre line
 * - Flags:	byte	-> Byte to be written
 */
void therm_write_byte(uint8_t byte){
	
	uint8_t i=8;
	
	while(i--){
		//Write actual bit and shift one position right to prepare the next one
		therm_write_bit(byte&1);
		byte>>=1;
	}
	
}

/* - Description: Changes the resolution of the thermometre to tje desired one
 * - Flags:	resolution	-> New resolution for the thermometre. Defines available at thermometer.h
 */
void therm_change_resolution(uint8_t resolution){

	/* Write Scratchpad */
	therm_reset();
	therm_write_byte(THERM_CMD_SKIPROM);
	therm_write_byte(THERM_CMD_WSCRATCHPAD);
	//Alarm triggers are not implemented, so put them to 0
	therm_write_byte(0);
	therm_write_byte(0);
	therm_write_byte((resolution<<5)|0x1f);
	
	/* Store written values to the EEPROM */
	therm_reset();
	therm_write_byte(THERM_CMD_SKIPROM);
	therm_write_byte(THERM_CMD_CPYSCRATCHPAD);
	
	thermometer.currentres=resolution;
	
}


/* - Description: Reads the current temperature stored by the thermometre.
 * - Flags:	*buffer			-> char pointer where to store the result. Should be at least 11-byte length ["+XX.XXXX C"+null]
 * 			need_conversion	-> true if a 'Convert T' command have to be sent first, false if not 
 */
void therm_read_temperature(char *buffer, bool need_conversion){
	
	uint16_t digit, decimal;
	uint8_t i;
	uint8_t temperature[2];
	char conversionstring[]="%+d.%00u C";
	
	/* Change the number of padding zeros */
	conversionstring[6]=0x31+thermometer.currentres;
	
	/* Send 'Convert T' command if needed */
	if(need_conversion==true){
		therm_reset();
		therm_write_byte(THERM_CMD_SKIPROM);
		therm_write_byte(THERM_CMD_CONVERTTEMP);
		
		//Wait until conversion is complete
		while(!therm_read_bit());
	}
	
	/* Read Scratchpad (only first 2 bytes) */
	therm_reset();
	therm_write_byte(THERM_CMD_SKIPROM);
	therm_write_byte(THERM_CMD_RSCRATCHPAD);
	
	temperature[0]=therm_read_byte();
	temperature[1]=therm_read_byte();
	therm_reset();
	
	/* Store temperature integer digits */
	digit=temperature[0]>>4;
	digit|=(temperature[1]&0x7)<<4;
	/* Store decimal digits */
	decimal=(temperature[0]&0xf)>>(3-thermometer.currentres);
	decimal*=temp_res_decimals[thermometer.currentres];
	/* If Fahrenheit, make conversion */
	if(thermometer.currentunit==THERM_UNITS_F){
		//Make some calculations... (avoid usage of float variables)
		digit=digit*9;
		decimal=decimal*9;
		i=decimal/power(10,(thermometer.currentres+1));
		digit+=i;
		decimal+=((digit%5)-i)*power(10,(thermometer.currentres+1));
		digit=(digit/5)+32;
		decimal/=5;
		//Character
		conversionstring[9]='F';
	}

	/* Format temperature into a string [+XX.XXXX C] */
	sprintf(buffer, conversionstring, digit, decimal);
	
}


/* - Description: Loads the thermometer interface
 * - Flags:	None
 */
void therm_load(){
	
	/* Set up variables */
	//Units to Celsius
	thermometer.currentunit=THERM_UNITS_C;
	//Selector to C/F
	thermometer.currentselector=0;
	//Read Scratchpad (recover stored resolution)
	therm_reset();
	therm_write_byte(THERM_CMD_SKIPROM);
	therm_write_byte(THERM_CMD_RSCRATCHPAD);
	therm_read_byte(); therm_read_byte();
	therm_read_byte(); therm_read_byte();
	thermometer.currentres=(therm_read_byte()>>5)&0x3;
	
	/* Clear screen & draw top icon */
	lcd_draw_rectangle(0, 18, 132, 114, openplayer.skin.bg);
	intf_topicon_draw(icon_thermometer);
	
	/* Draw text & icon */
	lcd_drawicon(icon_thermometer, 58, 28, true);
	lcd_put_string(lang(27), (131-strlen_P(lang(27))*FONT_WIDTH)/2, 50, openplayer.skin.txt, openplayer.skin.bg, 0);
	
	/* Draw options area */
	lcd_draw_rectangle(0, 94, 132, 38, openplayer.skin.tab_bg);
	//Units selector
	lcd_draw_rectangle(50, 97, 17, 14, openplayer.skin.btn_active);
	lcd_draw_rectangle(66, 97, 17, 14, openplayer.skin.bg);
	lcd_put_string(temp_units, 54, 97, openplayer.skin.txt, 0, (1<<TEXT_SOURCE)|(1<<TEXT_TRANSP));
	//Resolution selector
	lcd_draw_rectangle(18, 114, 97, 14, openplayer.skin.bg);
	lcd_draw_rectangle(18+24*(thermometer.currentres), 114, 25, 14, openplayer.skin.btn_dis);
	lcd_put_string(temp_res, 22, 114, openplayer.skin.txt, 0, (1<<TEXT_SOURCE)|(1<<TEXT_TRANSP));
	
	/* Enable thermometer in timer and add key handler */
	thermometer.running=THERM_RUNNING;
	change_task(therm_handler);
}


/* - Description: Handles keys pressed while inside thermometer program
 * - Flags:	None
 */
void therm_handler(){
	
	uint8_t pressed_keys;
	
	pressed_keys=check_keys();
	
	/* Exit from thermometer */
	if(pressed_keys==(1<<KEYS_CENTER)){
		thermometer.running=THERM_NOTRUNNING;
		menus_load(current_menu.menu, current_menu.selected);
		return;
		
	/* Change selector */
	}if(pressed_keys==(1<<KEYS_DOWN) || pressed_keys==(1<<KEYS_UP)){
	
		//Invert selector
		thermometer.currentselector=thermometer.currentselector^1;
		//Redraw Units selector
		lcd_draw_rectangle(50+(thermometer.currentunit*16), 97, 17, 14, (!thermometer.currentselector)?openplayer.skin.btn_active:openplayer.skin.btn_dis);
		lcd_put_char((thermometer.currentunit)?'F':'C', 54+(thermometer.currentunit*16), 97, openplayer.skin.txt, 0, (1<<TEXT_SOURCE)|(1<<TEXT_TRANSP));
		//Redraw Resolution selector
		lcd_draw_rectangle(18+(24*(thermometer.currentres)), 114, 25, 14,(thermometer.currentselector)?openplayer.skin.btn_active:openplayer.skin.btn_dis);
		lcd_put_string(&temp_res[thermometer.currentres*3], 22+(24*(thermometer.currentres)), 114, openplayer.skin.txt, 0, (1<<TEXT_SOURCE)|(1<<TEXT_TRANSP));
	
	/* Change current selector value */
	}else if(pressed_keys==(1<<KEYS_LEFT) || pressed_keys==(1<<KEYS_RIGHT)){
		
		//Units selector change
		if(thermometer.currentselector==THERM_CURSELECTOR_UNITS){
			thermometer.currentunit=thermometer.currentunit^1;
			lcd_draw_rectangle(50, 97, 17, 14, (!thermometer.currentunit)?openplayer.skin.btn_active:openplayer.skin.bg);
			lcd_draw_rectangle(66, 97, 17, 14, (thermometer.currentunit)?openplayer.skin.btn_active:openplayer.skin.bg);
			lcd_put_string(temp_units, 54, 97, openplayer.skin.txt, 0, (1<<TEXT_SOURCE)|(1<<TEXT_TRANSP));
		
		//Resolution selector change
		}else{
			//Stop thermometre
			thermometer.running=THERM_NOTRUNNING;
			
			//Clear current displayed temperature
			lcd_draw_rectangle(26, 68, 81, 25, openplayer.skin.bg);
			//Redraw current resolution to not selected
			lcd_draw_rectangle(18+(24*(thermometer.currentres)), 114, 25, 14,openplayer.skin.bg);
			lcd_put_string(&temp_res[thermometer.currentres*3], 22+(24*(thermometer.currentres)), 114, openplayer.skin.txt, openplayer.skin.bg, (1<<TEXT_SOURCE));
			//Change current resolution
			if(thermometer.currentres==THERM_RES_9BIT && pressed_keys==(1<<KEYS_LEFT)){
				therm_change_resolution(THERM_RES_12BIT);
			}else if(thermometer.currentres==THERM_RES_12BIT && pressed_keys==(1<<KEYS_RIGHT)){
				therm_change_resolution(THERM_RES_9BIT);
			}else{
				therm_change_resolution(thermometer.currentres+(pressed_keys==(1<<KEYS_LEFT)?(-1):1));
			}
			//Redraw the new resolution
			lcd_draw_rectangle(18+(24*(thermometer.currentres)), 114, 25, 14,openplayer.skin.btn_active);
			lcd_put_string(&temp_res[thermometer.currentres*3], 22+(24*(thermometer.currentres)), 114, openplayer.skin.txt, openplayer.skin.btn_active, (1<<TEXT_SOURCE)|(1<<TEXT_TRANSP));
			
			//Run thermometer again
			thermometer.running=THERM_NEEDTEMP;
			
		}
		
	}
	
}
