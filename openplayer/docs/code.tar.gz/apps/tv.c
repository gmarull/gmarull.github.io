/*  openplayer firmware - openplayer, an open source portable music player
    Copyright (C) 2008  Gerard Marull Paretas - <gerardmarull[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/**************************************************************************
 * 
 * TV Remote module - Version 1.0
 * 
 * File type: Source
 * File name: tv.c
 * 
 **************************************************************************/

#include <avr/io.h>
#include <avr/interrupt.h>
#include "hardware.h"
#include "apps/tv.h"
#include "sys/interface.h"
#include "sys/lcd.h"
#include "sys/util.h"
#include "apps/menus.h"
#include "main.h"

/* Global TV module variables */
struct tv_data{
	uint8_t toggle_bit;
	uint8_t current_protocol;
	uint8_t keypos_x;
	uint8_t keypos_y;
}tv;

/* Available protocols */
struct{
	void (*command_function)(uint8_t command);
	uint8_t commands[3][2];
}tv_protocols[]=
{
		//RC5 (Phillips)
		{
				tv_rc5_send_command, 
				{
						{TV_RC5_CMD_STANDBY, TV_RC5_CMD_MUTE},
						{TV_RC5_CMD_PROGPLUS, TV_RC5_CMD_PROGMIN},
						{TV_RC5_CMD_VOLPLUS, TV_RC5_CMD_VOLMIN}
				}
		}
};

/* - Description: Sends a TV command in RC5 protocol
 * 
 * - Flags: 	command -> command to be sent
 */
void tv_rc5_send_command(uint8_t command){
	
	uint8_t key_is_down=1;
	int8_t i;
	
	while(key_is_down){

		/* Start bits: 11 */
		TV_LOW();
		delay_us(us(889));
		TV_HIGH();
		delay_us(us(889));
	
		TV_LOW();
		delay_us(us(889));
		TV_HIGH();
		delay_us(us(889));
	
		/* Toggle bit: 0/1 */
		if(tv.toggle_bit){
			TV_LOW();
			delay_us(us(889));
			TV_HIGH();
			delay_us(us(889));
		}else{
			TV_HIGH();
			delay_us(us(889));
			TV_LOW();
			delay_us(us(889));
		}
			
		/* Address: 00000 (TV) */
		for(i=0;i<5;i++){
			TV_HIGH();
			delay_us(us(889));
			TV_LOW();
			delay_us(us(889));
		}
		
		/* Command: XXXXXX */
		for(i=5;i>=0;i--){
			if(command&(1<<i)){
				//1
				TV_LOW();
				delay_us(us(889));
				TV_HIGH();
				delay_us(us(889));
			}else{
				//0
				TV_HIGH();
				delay_us(us(889));
				TV_LOW();
				delay_us(us(889));
			}
		}
		
		/* Finish keyframe */
		TV_LOW();
		delay_us(us(65000));
		delay_us(us(24000));
		
		/* Save keys pressed */
		key_is_down=(~KEYS_PIN)&0x1f;

	}
	
	/* End of keypress, toggle command bit */
	tv.toggle_bit^=1;
}

void tv_init_timer(){
	
	/* Setup Timer1 to Output a ~38Khz clock signal */
	//CTC Mode, Toggle OC1A pin on compare match, select main clock source
	TCCR1A|=(1<<COM1A0)|(0<<COM1A1);
	TCCR1B|=(1<<CS10)|(1<<WGM12);
	//OCR1AH/L to 105, make ~74000 togglings per second
	OCR1AH=0;
	OCR1AL=105;
	
}
/* - Description: Loads TV interface
 * 
 * - Flags: 	none
 */
void tv_load(){
	
	/* Initialize timer */
	tv_init_timer();
	/* Clear screen & draw top icon */
	lcd_draw_rectangle(0, 18, 132, 114,0xff);
	intf_topicon_draw(icon_tv);
	
	/*Draw TV+Waves icon*/
	lcd_drawicon(icon_tv_waves, 54, 22, true);
	
	/* Make first key selected and select RC5 code */
	tv.current_protocol=TV_PROTOCOL_RC5;
	tv.keypos_x=0;
	tv.keypos_y=0;
	
	/*Draw the buttons*/
	//Standby
	lcd_draw_rectangle(22, 61, 25, 25, openplayer.skin.btn_bg);
	lcd_draw_rectangle(22, 82, 25, 4, openplayer.skin.btn_active);
	lcd_drawicon(icon_tv_off, 26, 65, true);
	//Mute
	lcd_draw_rectangle(22, 93, 25, 25, openplayer.skin.btn_bg);
	lcd_drawicon(icon_tv_mute, 26, 97, true);
	//Program +
	lcd_draw_rectangle(54, 61, 25, 25, openplayer.skin.btn_bg);
	lcd_drawicon(icon_tv_progplus, 58, 65, true);
	//Program -
	lcd_draw_rectangle(54, 93, 25, 25, openplayer.skin.btn_bg);
	lcd_drawicon(icon_tv_progmin, 58, 97, true);
	//Volume +
	lcd_draw_rectangle(86, 61, 25, 25, openplayer.skin.btn_bg);
	lcd_drawicon(icon_tv_volplus, 90, 65, true);
	//Volume -
	lcd_draw_rectangle(86, 93, 25, 25, openplayer.skin.btn_bg);
	lcd_drawicon(icon_tv_volmin, 90, 97, true);

	change_task(tv_handler);

}

/* - Description: Selects a key on the screen
 * 
 * - Flags: 	newx	-> Key X position
 * 				newy	-> Key Y position
 */
void tv_select_key(uint8_t newx, uint8_t newy){
	
	//Redraw current button
	lcd_draw_rectangle(22+32*tv.keypos_x, 82+32*tv.keypos_y, 25, 4, openplayer.skin.btn_bg);
	//Assign new key and redraw it
	tv.keypos_x=newx;
	tv.keypos_y=newy;
	lcd_draw_rectangle(22+32*tv.keypos_x, 82+32*tv.keypos_y, 25, 4, openplayer.skin.btn_active);
}

/* - Description: Handles keys
 * 
 * - Flags: 	none
 */
void tv_handler(){
	
	
	switch(check_keys()){
		
		case (1<<KEYS_CENTER):
			tv_protocols[tv.current_protocol].command_function(tv_protocols[tv.current_protocol].commands[tv.keypos_x][tv.keypos_y]);
			break;
		
		case (1<<KEYS_UP):
			tv_select_key(tv.keypos_x, tv.keypos_y^1);
			break;
			
		case (1<<KEYS_DOWN):
			tv_select_key(tv.keypos_x, tv.keypos_y^1);
			break;
		
		case (1<<KEYS_LEFT):
			change_task(tv_exit);
			break;
			
		case (1<<KEYS_RIGHT):
			tv_select_key((tv.keypos_x==2)?0:tv.keypos_x+1, tv.keypos_y);
			break;
	}
	
}

/* - Description: Exits TV application
 * 
 * - Flags: none
 */
void tv_exit(){
	
	/* Disable clock & reload menus */
	TCCR1B&=~(1<<CS10);
	menus_load(current_menu.menu, current_menu.selected);
	
}
