/*  openplayer firmware - openplayer, an open source portable music player
    Copyright (C) 2008  Gerard Marull Paretas - <gerardmarull[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/**************************************************************************
 * 
 * File browser program - Version 1.0
 * 
 * File type: Source
 * File name: filebrowser.c
 * 
 **************************************************************************/

#include <avr/io.h>
#include <string.h>
#include "hardware.h"
#include "sys/settings.h"
#include "sys/fat.h"
#include "sys/lcd.h"
#include "sys/interface.h"
#include "apps/filebrowser.h"
#include "apps/menus.h"
#include "main.h"

/* - Description: Initializes file browser
 * - Flags:		*topicon 	-> the icon shown in the top-left corner of the screen
 * 				*fileicon 	-> the icon for files
 * 				*fileaction -> function called when clicking on a file
 */
void filebrowser_init(const uint8_t *topicon, const uint8_t *fileicon, void (*fileaction)(void)){
	
	intf_topicon_draw(topicon);
	filebrowser.fileaction=fileaction;
	filebrowser.fileicon=fileicon;
	
	filebrowser_load(0);

	change_task(filebrowser_handler);
	
}

/* - Description: Sends a byte through SPI
 * - Flags:		reference 	->
 * 				selected 	-> Item selected
 */
void filebrowser_load(uint8_t selected){

	//Count folders first (only if are requested)
	if((filebrowser.attr_filter&ATTR_DIR)){
		filebrowser.folders=fat_count_files(0, ATTR_DIR);
	}else{
		filebrowser.folders=0;
	}
	//Count all files
	filebrowser.items=fat_count_files(&filebrowser.formats, filebrowser.attr_filter);
	
	if(filebrowser.folders > 1){
			filebrowser.folders-=2;
			filebrowser.items-=2;
	}
	
	filebrowser.selected=selected;
	filebrowser.reference=filebrowser.selected%5;
	
	if(!filebrowser.items){
		//The current directory is empty
		lcd_draw_rectangle(0,18,132,114,openplayer.skin.ls_bg); //Clear
		intf_message(lang(23),MSG_INFO);
	}else{
		filebrowser_refresh();
	}
	
}

/* - Description: Redraws file browser
 * - Flags:	none
 */
void filebrowser_refresh(){
	
	uint8_t lscurrentpage, scrolltopsize, index;
	int8_t n=0;
	
	index=filebrowser.selected-filebrowser.reference;
	
	//Draw scrollbar background
	lcd_draw_rectangle(126, 18, 6, 114, openplayer.skin.ls_scroll_bg);
	//Draw scrollbar top
	lscurrentpage=index/5;
	scrolltopsize=114/((filebrowser.items/5)+((filebrowser.items%5)?1:0));
	lcd_draw_rectangle(126, (scrolltopsize*lscurrentpage)+18, 6, scrolltopsize, openplayer.skin.ls_scroll_top);
		
	//Clear screen
	lcd_draw_rectangle(0, 18, 126, 114, openplayer.skin.ls_bg);
	
	//Obtain folders info (first)
	while(n<5 && (index < filebrowser.folders)){
		fat_get_file_info((index+3),browseritems[n].label,NULL,ATTR_DIR,&browseritems[n].fentry, 13|FAT_GET_BY_ENTRY_NUM|FAT_SAVE_FILE_NAME);
		n++; index++;
	}
	
	//Obtain files info (avoiding only folders)	
	while(n<5 && (index < filebrowser.items)){
		fat_get_file_info((index-filebrowser.folders+1),browseritems[n].label,&filebrowser.formats,(filebrowser.attr_filter&(~ATTR_DIR)),&browseritems[n].fentry, 13|FAT_GET_BY_ENTRY_NUM|FAT_SAVE_FILE_NAME);
		n++; index++;
	}
	
	/* Draw items */
	while(--n >= 0){
		
		/* Draw background and text */
		if(n==filebrowser.reference){
			//Draw selected item background
			lcd_draw_rectangle(0, (n*23)+18, 126, 24, openplayer.skin.ls_sel_bg);
			lcd_put_string(browseritems[n].label,22,(n*23)+22,openplayer.skin.ls_sel_txt, openplayer.skin.ls_sel_bg,(1<<TEXT_SOURCE)|(1<<TEXT_DOTS));	
		}else{
			lcd_put_string(browseritems[n].label,22,(n*23)+22,openplayer.skin.ls_txt,openplayer.skin.ls_bg,(1<<TEXT_SOURCE)|(1<<TEXT_DOTS));	
		}
		
		/* Draw file icon */
		if(browseritems[n].fentry.type==TYPEFOLDER){
			lcd_drawicon(icon_folder, 2, (n*23)+22,true);
		}else{
			lcd_drawicon(filebrowser.fileicon, 2, (n*23)+22,true);
		}
		
	}
	
}

/* - Description: Sends a byte through SPI
 * - Flags:		movement -> steps you want to move from current position, either + or - values
 */
void filebrowser_move(int8_t movement){
	
	
	//Check if we try to go 'outside' the list
	if((filebrowser.selected+movement > (filebrowser.items-1)) || (filebrowser.selected+movement < 0)){
		return;
	}
	
	if(filebrowser.reference+movement < 0){
		//Going up
		filebrowser.selected+=movement;
		filebrowser.reference=filebrowser.reference+(movement%5)+5;
		filebrowser_refresh();
	}else if(filebrowser.reference+movement > 4){
		//Going down
		filebrowser.selected+=movement;
		filebrowser.reference=filebrowser.reference+(movement%5)-5;
		filebrowser_refresh();
	}else{
		/* Only partial redraw needed */
		
		/* Redraw selected item as not selected */
		//Clear needed area
		lcd_draw_rectangle(0, (filebrowser.reference*23)+18, 126, 24, openplayer.skin.ls_bg);
		//Check which icon has to be drawn
		if(browseritems[filebrowser.reference].fentry.type==TYPEFOLDER){
			lcd_drawicon(icon_folder,2,(23*filebrowser.reference)+22,true);
		}else{
			lcd_drawicon(filebrowser.fileicon,2,(23*filebrowser.reference)+22,true);
		}
	
		lcd_put_string(browseritems[filebrowser.reference].label,22,(23*filebrowser.reference)+22,openplayer.skin.ls_txt,openplayer.skin.ls_bg,(1<<TEXT_SOURCE)|(1<<TEXT_DOTS));
		
		/* Update values */
		filebrowser.reference+=movement;
		filebrowser.selected+=movement;
		
		/* Draw the new selected item */
		lcd_draw_rectangle(0, (filebrowser.reference*23)+18, 126, 24, openplayer.skin.ls_sel_bg);
		if(browseritems[filebrowser.reference].fentry.type==TYPEFOLDER){
			lcd_drawicon(icon_folder,2,(23*filebrowser.reference)+22,true);
		}else{
			lcd_drawicon(filebrowser.fileicon,2,(23*filebrowser.reference)+22,true);
		}
		lcd_put_string(browseritems[filebrowser.reference].label,22,(23*filebrowser.reference)+22,openplayer.skin.ls_sel_txt,openplayer.skin.ls_sel_bg,(1<<TEXT_SOURCE)|(1<<TEXT_DOTS));	
	}
	
}

/* - Description: Handles keys
 * - Flags:	none
 */
void filebrowser_handler(){

		
		switch(check_keys()){
			
			case (1<<KEYS_LEFT):
				fat_cd_dir("..");
				//Check if we exit from root
				if(filebrowser.deeplevel==0){
					change_task(filebrowser_exit);
					break;
				}
				//If not just go back
				filebrowser.deeplevel--;
				filebrowser_load(0);
				break;
			
			case (1<<KEYS_UP):
				if(filebrowser.items){
					filebrowser_move(-1);
				}
				break;
			
			case (1<<KEYS_DOWN):
				if(filebrowser.items){
					filebrowser_move(1);
				}
				break;
			
			case (1<<KEYS_CENTER):
				if(filebrowser.items){
					//Check if we are over a folder or a file
					if(browseritems[filebrowser.reference].fentry.type==TYPEFILE){
						filebrowser.fileaction();
					}else{
						//This way avoids using fat_cd_dir, which is operated by name (stored folder label is not the entire length, could cause problems in folders with similar names!)
						fat_get_file_info(filebrowser.selected+3, NULL, NULL, ATTR_DIR, &fileinfo, FAT_GET_BY_ENTRY_NUM);
						partition.currentfolder=fileinfo.firstcluster;
						filebrowser.deeplevel++;
						filebrowser_load(0);
					}
				}
				break;
		}

}


/* - Description: Exits filebrowser and launches menus again
 * - Flags:	none
 */
void filebrowser_exit(){
	
	/* Clear rules */
	fat_formats_clear(&filebrowser.formats);
	/* Load last menu */
	menus_load(current_menu.menu, current_menu.selected);
	
}
