/*  openplayer firmware - openplayer, an open source portable music player
    Copyright (C) 2008  Gerard Marull Paretas - <gerardmarull[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/**************************************************************************
 * 
 * Interface menus module -> Version 1.0
 * 
 * File type: Source
 * File name: menus.c
 * 
 **************************************************************************/

#include <avr/io.h>
#include <avr/pgmspace.h>
#include <stdio.h>
#include <stdlib.h>
#include "hardware.h"
#include "apps/menus.h"
#include "sys/fat.h"
#include "sys/lcd.h"
#include "sys/interface.h"
#include "sys/util.h"
#include "sys/settings.h"
#include "apps/player.h"
#include "apps/thermometer.h"
#include "apps/tv.h"
#include "apps/picbrowser.h"
#include "apps/filebrowser.h"
#include "main.h"

/**********************************************/
/************** AVAILABLE MENUS ***************/
/**********************************************/

const menu_entry PROGMEM mainmenu[]=
{
		{icon_music, 4, change_task, player_load},
		{icon_pictures, 5, change_task, picb_load},
		{icon_extras, 6, menus_load_click, (void*)extrasmenu},
		{icon_settings, 7, menus_load_click, (void*)settingsmenu},
		{icon_quit, 8, menus_load_click, (void*)quitmenu},
		{icon_home, 0, NULL, NULL}
};

const menu_entry PROGMEM extrasmenu[]=
{
		//{icon_games, 9, NULL, NULL},
		{icon_thermometer, 10, change_task,	therm_load},
		{icon_tv, 11, change_task, tv_load},
		//{icon_clock, 12, NULL, NULL},
		{icon_extras, 0, NULL, (void*)mainmenu}
};

const menu_entry PROGMEM settingsmenu[]=
{
		{icon_languages, 25, menus_load_click, (void*)languagesmenu},
		{icon_backlight, 26, change_task, sett_backlight_init},
		//{icon_contrast, 30, change_task, NULL},
		//{icon_skins, 33, menus_load_click, (void*)skinsmenu},
		{icon_settings,	0, menus_load_click, (void*)mainmenu}
};

const menu_entry PROGMEM skinsmenu[]=
{
		{icon_skins_select, 34, change_task, sett_skins_browser_init},
		{icon_skins_add, 35, NULL, NULL},
		{icon_skins, 0, menus_load_click, (void*)settingsmenu}
};

const menu_entry PROGMEM languagesmenu[]=
{
		{icon_lang_en, 20, intf_set_current_language, (void*)lang_en},
		{icon_lang_ca, 21, intf_set_current_language, (void*)lang_ca},
		{icon_settings,	0, menus_load_click, (void*)settingsmenu}
};

const menu_entry PROGMEM quitmenu[]=
{
		{icon_reboot, 13, 0, NULL},
		{icon_sleep, 14, change_task, go_sleep},
		{icon_quit, 0, menus_load_click, (void*)mainmenu}
};


/********************************************************************/
/********************************************************************/
/********************************************************************/

/* - Description: Key handler
 * 
 * - Flags: none
 */
void menus_handler(){
	
	void (*actionfunction)(void *flags);
	
	switch(check_keys()){
		case (1<<KEYS_DOWN):
			menus_move(1);
			break;
			
		case (1<<KEYS_UP):
			menus_move(-1);
			break;
			
		case (1<<KEYS_LEFT):
			menus_load((void*)pgm_read_word(&(current_menu.menu+current_menu.items)->flags),0);
			break;
			
		case (1<<KEYS_CENTER):
			actionfunction=(void*)pgm_read_word(&(current_menu.menu+current_menu.selected)->actionfunction);
			actionfunction((void*)pgm_read_word(&(current_menu.menu+current_menu.selected)->flags));
			break;
	}

}

/* - Description: Loads a menu
 * 
 * - Flags: 	*menu -> menu to be loaded
 * NOTES: Only for menu items that must have a void(void*) function pointer
 */
inline void menus_load_click(void *menu){

	menus_load((menu_entry*)menu,0);
}


/* - Description: Redraws the current menu
 * 
 * - Flags: none
 */
void menus_refresh(){
	
	uint8_t i=0,lscurrentpage, scrolltopsize;
	const menu_entry *f;
	f=(current_menu.menu+current_menu.selected)-current_menu.reference;
	
	//Draw scrollbar background
	lcd_draw_rectangle(126, 18, 6, 114,openplayer.skin.ls_scroll_bg);
	//Draw scrollbar top
	lscurrentpage=(current_menu.selected-current_menu.reference)/5;
	scrolltopsize=114/((current_menu.items/5)+((current_menu.items%5)?1:0));
	lcd_draw_rectangle(126, (scrolltopsize*lscurrentpage)+18, 6, scrolltopsize, openplayer.skin.ls_scroll_top);
	
	//Clear screen
	lcd_draw_rectangle(0, 18, 126, 114, openplayer.skin.ls_bg);
	
	//Draw items
	while(pgm_read_byte(&f->text) && (i<5)){
		if(i==current_menu.reference){
			lcd_draw_rectangle(0, (i*23)+18, 126, 24,openplayer.skin.ls_sel_bg);
			lcd_put_string(lang(pgm_read_byte(&f->text)),22,(i*23)+22,openplayer.skin.ls_sel_txt,openplayer.skin.ls_sel_bg,(1<<TEXT_DOTS));	
		}else{
			lcd_put_string(lang(pgm_read_byte(&f->text)),22,(i*23)+22,openplayer.skin.ls_txt,openplayer.skin.ls_bg,(1<<TEXT_DOTS));	
		}
		lcd_drawicon((uint8_t*)pgm_read_word(&f->icon), 2, (i*23)+22,true);
		i++; f++;	
	}
	
}

/* - Description: Loads a menu
 * 
 * - Flags: 	*menu 		-> menu to be loaded
 * 				selected 	-> item that will appear as selected
 */
void menus_load(const menu_entry *menu, uint8_t selected){
	
	if(!menu) return;
	
	//Update with new values
	current_menu.menu=menu;
	current_menu.selected=selected;
	current_menu.reference=current_menu.selected%5;
	
	current_menu.items=0;
	//Count menu items
	while(pgm_read_byte(&menu->text)){
		current_menu.items++; menu++;	
	}
	
	intf_topicon_draw((uint8_t*)pgm_read_word(&menu->icon));
	
	//Refresh screen to load menu
	menus_refresh();
	
	change_task(menus_handler);
	
}

/* - Description: Moves to another place in the menu
 * 
 * - Flags: 	movement -> How many steps you want to move from current position (+or-)
 */
void menus_move(int8_t movement){
	
	const menu_entry *menu;
	//Check if we try to go 'outside' the list
	if((current_menu.selected+movement > (current_menu.items-1)) || (current_menu.selected+movement < 0)){
		return;
	}
	
	if(current_menu.reference+movement < 0){
		//Going up
		current_menu.selected+=movement;
		current_menu.reference=current_menu.reference+(movement%5)+5;
		menus_refresh();
	}else if(current_menu.reference+movement > 4){
		//Going down
		current_menu.selected+=movement;
		current_menu.reference=current_menu.reference+(movement%5)-5;
		menus_refresh();
	}else{
		/* Only partial redraw needed */
		menu=current_menu.menu+current_menu.selected;
		
		/* Redraw selected item as not selected */
		lcd_draw_rectangle(0, (current_menu.reference*23)+18, 126, 24, openplayer.skin.ls_bg);
		lcd_drawicon((uint8_t*)pgm_read_word(&menu->icon),2,(23*current_menu.reference)+22,true);
		lcd_put_string(lang(pgm_read_byte(&menu->text)),22,(23*current_menu.reference)+22, openplayer.skin.ls_txt, openplayer.skin.ls_bg, (1<<TEXT_DOTS));
		
		/* Update values */
		current_menu.reference+=movement;
		current_menu.selected+=movement;
		menu+=movement;
		
		/* Draw the new selected item */
		lcd_draw_rectangle(0, (current_menu.reference*23)+18, 126, 24, openplayer.skin.ls_sel_bg);
		lcd_drawicon((uint8_t*)pgm_read_word(&menu->icon),2,(23*current_menu.reference)+22,true);
		lcd_put_string(lang(pgm_read_byte(&menu->text)),22,(23*current_menu.reference)+22, openplayer.skin.ls_sel_txt, openplayer.skin.ls_sel_bg, (1<<TEXT_DOTS));	
	}
			
}
