/*  openplayer firmware - openplayer, an open source portable music player
    Copyright (C) 2008  Gerard Marull Paretas - <gerardmarull[at]gmail[dot]com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/**************************************************************************
 * 
 * Music browser/player module - Version 1.0
 * 
 * File type: Source
 * File name: player.c
 * 
 * 
 **************************************************************************/

#include <avr/io.h>
#include <stdio.h>
#include <string.h>
#include "hardware.h"
#include "apps/player.h"
#include "sys/settings.h"
#include "sys/interface.h"
#include "sys/fat.h"
#include "sys/lcd.h"
#include "sys/decoder.h"
#include "sys/sd.h"
#include "sys/util.h"
#include "apps/filebrowser.h"
#include "apps/menus.h"
#include "main.h"



//Progressbar color
#define PLAYER_PROG_COLOR 	0x9c
#define PLAYER_PROG_ZONE	0x0e

/********************************************************************/
/* MP3 values needed to calculate track length or to get information */
/********************************************************************/

//Layers
#define LAYER_I			0
#define LAYER_II		1
#define LAYER_III		2

//Channels
#define CHAN_STEREO		0
#define CHAN_JSTEREO	1
#define CHAN_DUAL		2
#define CHAN_MONO		3

//MPEG
#define MPEG_25			0
#define MPEG_2			2
#define MPEG_1			3

/* Bitrates for all MPEGs and Layers (Only valid for CBR) */
uint16_t PROGMEM bitrates[2][3][15]=
{
	//MPEG 1
	{
		{0,32,64,96,128,160,192,224,256,288,320,352,384,416,448},	//Layer I
		{0,32,48,56,64,80,96,112,128,160,192,224,256,320,384},		//Layer II
		{0,32,40,48,56,64,80,96,112,128,160,192,224,256,320} 		//Layer III
	},
	//MPEG 2 & 2.5
	{
		{0,32,48,56,64,80,96,112,128,144,160,176,192,224,256,},		//Layer I
		{0,8,16,24,32,40,48,56,64,80,96,112,128,144,160,},			//Layer II
		{0,8,16,24,32,40,48,56,64,80,96,112,128,144,160,}			//Layer III
	}
};

/* Samples per Frame */
uint16_t PROGMEM samples_per_frame[2][3]=
{
		{384, 1152, 1152}, 	//MPEG1
		{384, 1152, 576}	//MPEG2 && MPEG2.5
};

/* Samples per second */
uint16_t PROGMEM samples_per_sec[4][3]=
{
		{11025, 12000, 8000},	//MPEG 2.5
		{0 ,0 ,0},				//Reseverd-Not used
		{22050, 24000, 16000},	//MPEG 2
		{44100, 48000, 32000},	//MPEG1
};

/********************************************************************/
/********************************************************************/
/********************************************************************/

/* - Description: Inits the player and launches the file browser.
 * 
 * - Flags: 	None
 */
void player_load(){
	
	//Enter to music directory
	if(fat_cd_dir("MUSIC")){
			//Clear first
			lcd_draw_rectangle(0, 18, 132, 114, openplayer.skin.bg);
			intf_message(lang(22),MSG_WARNING);
			while(1){
				if(check_keys()){
					menus_load(current_menu.menu, current_menu.selected);
					return;
				}
			}
	}
	
	//Need to be initialized...
	player.trackposcount=16;
	player.currentvol=VOL_DEFAULT;
	
	//Add mp3 files and folders to be handled by the browser
	fat_formats_add(&filebrowser.formats, "MP3");
	filebrowser.attr_filter=ATTR_DIR;

	//Launch filebrowser task
	filebrowser_init(icon_music, icon_filemusic, player_play);

}



/* - Description: Launches the music player. Filebrowser task is changed to player_handler,
 * 				  but browser information is not lost, so when closing you'll return to the 
 * 				  same place where you were browsing.
 * 
 * - Flags: 	None
 */
void player_play(){

	//Clear screen
	lcd_draw_rectangle(0, 18, 132, 114, openplayer.skin.bg);
	
	//Check if we have a cover
	if(fat_get_file_info(0, "cover.bmp", NULL, 0, &player.currenttrack, FAT_GET_BY_NAME)==0){
		lcd_loadbitmap(&player.currenttrack, 4, 20);
	}else{
		lcd_draw_rectangle(4, 20, 48 ,48, 0xfe);
		lcd_drawicon(icon_warning, 20, 36, true);
	}
	
	player.numoftracks=filebrowser.items-filebrowser.folders;
	player.currenttracknum=filebrowser.selected-filebrowser.folders;

	//Draw black dots (decoration)
	lcd_drawicon(icon_blackdot,4,78,true);
	lcd_drawicon(icon_blackdot,4,93,true);
	
	//Draw track progress info zone background
	lcd_draw_rectangle(0, 106, 132, 26, openplayer.skin.tab_bg);
	
	player_change_track(player.currenttracknum+1);
	change_task(player_handler);
}



/* - Description: A task that will be run in every loop in order to check which
 * 				  keys are pressed while player (not file browser) is running.
 * 				  It evens is who sends music data to the decoder and updates track 
 * 				  times on the screen.
 * 
 * - Flags: 	None
 */
void player_handler(){
	
	uint16_t i;
	
	switch(check_keys()){
		case (1<<KEYS_DOWN):
			//Volume minus
			if((player.currentvol+VOL_CHANGE_CONST) > 254){
				player.currentvol = 254;	
			}else{
				player.currentvol += VOL_CHANGE_CONST;	
			}  
			dec_setvolume(player.currentvol, player.currentvol);
			break;
			
		case (1<<KEYS_UP):
			//Volume plus
			if((player.currentvol-VOL_CHANGE_CONST) < 0){
				player.currentvol = 0;	
			}else{
				player.currentvol -= VOL_CHANGE_CONST;	
			} 
			dec_setvolume(player.currentvol, player.currentvol);
			break;
			
		case (1<<KEYS_LEFT):
			//Previous track
			player_change_track(player.currenttracknum-1);
			break;
			
		case (1<<KEYS_RIGHT):
			//Next track
			player_change_track(player.currenttracknum+1);
			break;
		
		case (1<<KEYS_CENTER):
			change_task(player_exit);
			return;
			break;
	}
	
	//Send track data to the decoder
	player_send_audio();
	
	//Check if current time info has to be updated
	i=dec_read(DEC_DECTIME);
	if(i!=player.currenttrackinfo.time_decoded){
		player.currenttrackinfo.time_decoded=i;
		player.currenttrackinfo.time_remaining=player.currenttrackinfo.length-i;
		player_update_screen_times();
	}


}

/* - Description: Exits player
 * 
 * - Flags: 	None	
 */
void player_exit(){
	
	dec_nulls(2048);
	filebrowser_load(0);
	change_task(filebrowser_handler);
	
}

/* - Description: Sends audio data to the decoder and change to the next track if needed
 * 
 * - Flags: 	None	
 */
void player_send_audio(){
	
	static uint8_t *bufferp;
	uint8_t i;
	
	if(bit_is_set(DEC_PIN, DEC_DREQ)){

		if(player.trackposcount >= 16){
			//Wee need to read the next sector
			if(!fat_read_file(&player.currenttrack, global_buffer, SD_SECTOR_SIZE)){
				player_change_track(player.currenttracknum+1);
				return;
			}
			bufferp=global_buffer;
			player.trackposcount=0;
		}
		
		//Finally, send track data
		for(i=0; i<32; i++){
			dec_datawrite(*(bufferp+i));	
		}
		
		bufferp+=32;
		player.trackposcount++;
	}
		
}

/* - Description: Changes to the indicated track
 * 
 * - Flags: 	track -> The track you want to jump to.	
 */
void player_change_track(uint8_t track){
	
	char buffer[16];
	
	if(track > player.numoftracks || track < 1){
		//No more files to play, go back
		change_task(player_exit);
		return;
	}
	
	/* Update values and get new track information */
	dec_nulls(2048);
	player.trackposcount=16;
	player.currenttracknum=track;
	fat_get_file_info(player.currenttracknum, NULL, &filebrowser.formats, 0, &player.currenttrack, FAT_GET_BY_ENTRY_NUM);
	
	/*****************************/
	/* Redraw screen information */
	/*****************************/
	
	/* Draw track number (X of X) */
	sprintf(buffer," %u %S %u",player.currenttracknum, wlang(24), player.numoftracks);
	lcd_put_string(buffer,128-(strlen(buffer)*FONT_WIDTH),20,openplayer.skin.txt,openplayer.skin.bg,(1<<TEXT_SOURCE));

	/* Get and draw new ID3 tags */
	get_id3_tags(&player.currenttrack, 16, player.currenttrackinfo.id3.trackname, player.currenttrackinfo.id3.artist, player.currenttrackinfo.id3.album);
	//Clear area
	lcd_draw_rectangle(12, 75, 120, 31,openplayer.skin.bg);
	//Draw them
	snprintf(buffer,sizeof(buffer), "%s,%s", player.currenttrackinfo.id3.artist, player.currenttrackinfo.id3.album);
	lcd_put_string(buffer, 12, 75, openplayer.skin.txt,openplayer.skin.bg, (1<<TEXT_DOTS ) | (1<<TEXT_SOURCE));
	lcd_put_string(player.currenttrackinfo.id3.trackname, 12, 89, openplayer.skin.txt,openplayer.skin.bg, (1<<TEXT_DOTS ) | (1<<TEXT_SOURCE));
	
	/* Get other track information */
	player_get_track_info(&player.currenttrack, &player.currenttrackinfo);
	
	/* Update times and redraw progressbar area */
	dec_write(DEC_DECTIME, 0);
	player.currenttrackinfo.time_decoded=0;
	player.currenttrackinfo.time_remaining=player.currenttrackinfo.length;
	player.progbar_size=0;
	lcd_draw_rectangle(5, 122, 122, 6, openplayer.skin.tab_bg);
	
	/* Draw new time values */
	player_update_screen_times();

}


/* - Description: Gets track information (all variables located at a trackinfo struct).
 * 				  Can be used by any function, not strictly by the music player.
 * 
 * - Flags: 	*file 		 -> Pointer to the file where to look for the information
 * 				*trackinfo_p -> Pointer to the 'trackinfo' structure to fill.
 * 
 * - Developer notes: TODO -> Implement VBRI headers 
 */
void player_get_track_info(struct fat_fileentry *file, struct trackinfo *trackinfo_p){
	
	uint8_t buffer[56];
	uint8_t xingoffset,i;
	uint32_t headersize=0;

	/* Look for ID3 tag */
	fat_read_file(file,buffer,10);
	if(strncmp((char*)buffer,"ID3",3)==0){
		//Save ID3 header size (4 unsynch. bytes, big-endian) = 28bytes
		headersize=buffer[9];
		headersize|=((uint16_t)buffer[8]<<7);
		headersize|=((uint32_t)buffer[7]<<14);
		headersize|=((uint32_t)buffer[6]<<21);
	}
	
	/* Jump to the first header */
	fat_seek(file,file->pointer+headersize);
	fat_read_file(file,buffer,56);
	
	/* Fill some track information */
	trackinfo_p->mpeg=(buffer[1]>>3) & 0x3;
	
	if(trackinfo_p->mpeg==MPEG_1){
		i=0;
	}else{
		i=1;
	}
	
	trackinfo_p->layer=(3-((buffer[1]>>1) & 0x3));
	trackinfo_p->channel=buffer[3]>>6;
	trackinfo_p->samples_per_sec=pgm_read_word(&samples_per_sec[trackinfo_p->mpeg][((buffer[2]>>2)&0x3)]);
	trackinfo_p->samples_per_frame=pgm_read_word(&samples_per_frame[i][trackinfo_p->layer]);	
	
	/* Determine XING offset */
	if(trackinfo_p->mpeg==MPEG_1 && trackinfo_p->channel!=CHAN_MONO){
		xingoffset=36;
	}else if(trackinfo_p->mpeg==MPEG_2 && trackinfo_p->channel==CHAN_MONO){
		xingoffset=13;
	}else{
		xingoffset=21;
	}
	
	/* Check if XING header exists */
	if(strncmp((char*)&buffer[xingoffset], "Xing",4)==0 || strncmp((char*)&buffer[xingoffset], "Info",4)==0){
		//Store the number of frames
		trackinfo_p->frames=buffer[xingoffset+11];
		trackinfo_p->frames|=(uint16_t)buffer[xingoffset+10]<<8;
		trackinfo_p->frames|=(uint32_t)buffer[xingoffset+9]<<16;
		trackinfo_p->frames|=(uint32_t)buffer[xingoffset+8]<<24;
		
		//Store track length (in seconds)
		trackinfo_p->length=((uint32_t)trackinfo_p->frames*(uint32_t)trackinfo_p->samples_per_frame)/trackinfo_p->samples_per_sec;
		
		//Calculate track bitrate in kbps (average)
		trackinfo_p->bitrate=(uint16_t)((file->size-(headersize+10))/trackinfo_p->length)/125;
		
	}else{
		//Bitrate will be considered constant by now if XING header does not exist
		trackinfo_p->bitrate=pgm_read_word(&bitrates[i][trackinfo_p->layer][buffer[2]>>4]);
		trackinfo_p->length=(file->size-(headersize+10))/(trackinfo_p->bitrate*125);
	}
	
	//Restore file pointer to start.
	fat_seek(file, 0);
}


/* - Description: Update played and remaining time and song progress bar.
 * 
 * - Flags: 	None	
 */
void player_update_screen_times(){
	
	char buffer[7];
	int16_t scroll;
	
	//Current played time
	sprintf(buffer,"%u:%02u ",player.currenttrackinfo.time_decoded/60,player.currenttrackinfo.time_decoded%60);
	lcd_put_string(buffer, 4, 108, openplayer.skin.tab_txt,openplayer.skin.tab_bg, (1<<TEXT_SOURCE));
	
	//Remaining
	sprintf(buffer," %u:%02u",player.currenttrackinfo.time_remaining/60,player.currenttrackinfo.time_remaining%60);
	lcd_put_string(buffer, 128-(strlen(buffer)*FONT_WIDTH), 108, openplayer.skin.tab_txt,openplayer.skin.tab_bg, (1<<TEXT_SOURCE));
	
	//Draw scrollbar
	scroll=(121*(uint32_t)player.currenttrackinfo.time_decoded)/player.currenttrackinfo.length;
	//Avoid oversize stored (decoder sometimes gives problems...)
	if((scroll-player.progbar_size) < 0){
		scroll=0;
	}else{
		scroll-=player.progbar_size;
	}
	lcd_draw_rectangle(player.progbar_size+5, 122, scroll, 6, openplayer.skin.prog_bg);
	player.progbar_size+=scroll;
	
}



/* - Description: Gets ID3v2 Tags information of the given track. You can retrieve Artist, track name or Album name.
 * 				  Even supports Unicode formatted tags (it transforms them into ASCII).
 * 
 * - Flags:		*file		-> "struct fat_fileentry" pointer to the file where to look for
 * 				copylength	-> How many characters have to be stored from the ID3 tags
 * 				*artist		-> Pointer where to store artist name
 * 				*trackname	-> Pointer where to store track name
 * 				*album		-> Pointer where to store album name
 * - Notes: - If you don't need some of the fields, you can put a NULL pointer to the desired flags
 * 			- If any requested flag is unavailable, will be set with default language strings
 * 
 * - Developer notes: 	TODO-> Handle the two different UNICODE formats: with and without BOM word.
 * 						By now only with BOM is handled (i==1). Info: http://www.id3.org/id3v2.4.0-structure
 */
void get_id3_tags(struct fat_fileentry *file, uint8_t copylength, char *trackname, char *artist, char *album){
	
	uint32_t sfilepointer, headersize, tagheadersize;
	uint8_t id3buffer[50], remaining, readlength;
	char *fcopy;
	bool unicode;
	//Store current file pointer location to restore it when we end
	sfilepointer= file->pointer;
	//Put file at start location
	fat_seek(file,0);
	
	//Avoiding overflows
	if(copylength>sizeof(id3buffer)){
		copylength=sizeof(id3buffer);
	}
	
	//Which have we requested?
	if(trackname!=NULL) remaining=0x1;
	if(artist!=NULL) remaining|=0x2;
	if(album!=NULL) remaining|=0x4;
	
	//Read the header
	fat_read_file(file,id3buffer,10);
	if(strcmpcase((char*)id3buffer,"ID3",3)){
		//ID3v2 Information Available
		//Save header size (4 unsync. bytes big-endian) = 28bytes
		headersize=id3buffer[9];
		headersize|=((uint16_t)id3buffer[8]<<7);
		headersize|=((uint32_t)id3buffer[7]<<14);
		headersize|=((uint32_t)id3buffer[6]<<21);
			
		while(headersize && remaining){
			fat_read_file(file,id3buffer,11);
			
			if(!id3buffer[0]) break; //Exit, no more tags
			
			tagheadersize=id3buffer[7];
			tagheadersize|=((uint16_t)id3buffer[6]<<7);
			tagheadersize|=((uint32_t)id3buffer[5]<<14);
			tagheadersize|=((uint32_t)id3buffer[4]<<21);
			
			tagheadersize--; //We've already read first byte (indicator of ASCII/Unicode)
			
			
			//Search for trackname, artist or album tags
			if(strcmpcase((char*)id3buffer,"TIT2",4) && trackname!=NULL){
				//TRACK NAME
				fcopy=trackname;
				remaining&=~0x1; //Clear remaining
			}else if(strcmpcase((char*)id3buffer,"TPE1",4) && artist!=NULL){
				//ARTIST
				fcopy=artist;
				remaining&=~0x2; //Clear remaining
			}else if(strcmpcase((char*)id3buffer,"TALB",4) && album!=NULL){
				//ALBUM
				fcopy=album;
				remaining&=~0x4; //Clear remaining
			}else{
				//OTHERS
				fcopy=NULL;
			}
			
			//Store data if necessary
			if(fcopy){
				
				//Check if the content is stored in ascii/unicode
				if(id3buffer[10]==1 || id3buffer[10]==2){
					unicode=true;
				}else{
					unicode=false;
				}
				
				//Avoid overflows
				if(tagheadersize > sizeof(id3buffer)){
					readlength=sizeof(id3buffer);
				}else{
					readlength=tagheadersize;
				}
				
				fat_read_file(file,id3buffer,readlength);
				*(id3buffer+readlength)=0;
				if(unicode){
					//Unicode text
					strlcpy_u(fcopy,id3buffer,copylength);
				}else{
					//ASCII Text (ISO-8859-1)
					strncpy_unol(fcopy,(char*)id3buffer,copylength);
				}
				
			}else{
				readlength=0;
				//fat_seek(file,file->pointer+tagheadersize);
			}
			
			//We need to seek (if readlength is under tagheadersize)
			fat_seek(file,file->pointer+tagheadersize-readlength);
			headersize-=11+tagheadersize;
			
		}
			
	}
	
	//Check if all have been written, if not, fill with default ones
	if(bit_is_set(remaining,0)) strcpy_P(trackname,lang(15));
	if(bit_is_set(remaining,1)) strcpy_P(artist,lang(16));
	if(bit_is_set(remaining,2)) strcpy_P(album,lang(17));
	
	//Restore to saved file pointer
	fat_seek(file, sfilepointer);
	
}
